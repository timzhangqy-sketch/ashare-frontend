export type DashboardLoadState = 'normal' | 'warning' | 'loading' | 'empty' | 'error';

export type DashboardDataSource = 'mock' | 'real';

export type StatusTone = 'neutral' | 'positive' | 'warning' | 'danger' | 'info';

export type HealthStatus = 'healthy' | 'warning' | 'danger';

export interface RawDashboardTopOpportunity {
  ts_code: string;
  name: string;
  strategy_label: string;
  sector_label: string;
  score: number;
  hint: string;
}

export interface RawDashboardTodayChanges {
  new_signals: number;
  removed_signals: number;
  watchlist_delta: number;
  portfolio_delta: number;
  risk_alerts_delta: number;
  system_alerts_delta: number;
  summary_text: string;
}

export interface RawDashboardOpportunity {
  buy_signals_count: number;
  resonance_count: number;
  watchlist_candidates: number;
  strongest_strategy_label: string;
  hottest_sector_label: string;
  actionable_count: number;
  top_opportunities: RawDashboardTopOpportunity[];
}

export interface RawDashboardRisk {
  gate_blocked_count: number;
  high_risk_watchlist_count: number;
  high_risk_positions_count: number;
  new_risk_events_count: number;
  highest_risk_name: string;
  highest_risk_score: number;
  risk_hint: string;
}

export interface RawDashboardPortfolio {
  position_type: string;
  positions_count: number;
  total_market_value: number;
  cash_ratio: number;
  daily_pnl: number;
  daily_pnl_pct: number;
  cumulative_pnl_pct: number;
  concentration_top1: number;
  sell_signals_count: number;
  action_hint: string;
}

export interface RawDashboardSystemHealth {
  pipeline_status: string;
  latest_success_time: string;
  failed_steps_count: number;
  data_coverage_pct: number;
  dq_status: string;
  api_health_status: string;
  version_label: string;
  system_hint: string;
}

export interface RawDashboardSummaryPayload {
  trade_date: string;
  generated_at: string;
  version_snapshot: string;
  today_changes: RawDashboardTodayChanges;
  opportunity: RawDashboardOpportunity;
  risk: RawDashboardRisk;
  portfolio: RawDashboardPortfolio;
  system_health: RawDashboardSystemHealth;
}

export interface RawDashboardSummaryResponse extends RawDashboardSummaryPayload {
  data?: RawDashboardSummaryPayload | null;
}

export interface DashboardSummaryDto {
  tradeDate: string;
  generatedAt: string;
  versionSnapshot: string;
  todayChanges: TodayChangesDto;
  opportunity: OpportunitySummaryDto;
  risk: RiskSummaryDto;
  portfolio: PortfolioSummaryDto;
  systemHealth: SystemHealthSummaryDto;
}

export interface TodayChangesDto {
  newSignals: number;
  removedSignals: number;
  watchlistDelta: number;
  portfolioDelta: number;
  riskAlertsDelta: number;
  systemAlertsDelta: number;
  summaryText: string;
}

export interface OpportunitySummaryDto {
  buySignalsCount: number;
  resonanceCount: number;
  watchlistCandidates: number;
  strongestStrategyLabel: string;
  hottestSectorLabel: string;
  actionableCount: number;
  topOpportunities: TopOpportunityDto[];
}

export interface TopOpportunityDto {
  tsCode: string;
  name: string;
  strategyLabel: string;
  sectorLabel: string;
  score: number;
  hint: string;
}

export interface RiskSummaryDto {
  gateBlockedCount: number;
  highRiskWatchlistCount: number;
  highRiskPositionsCount: number;
  newRiskEventsCount: number;
  highestRiskName: string;
  highestRiskScore: number;
  riskHint: string;
}

export interface PortfolioSummaryDto {
  positionType: string;
  positionsCount: number;
  totalMarketValue: number;
  cashRatio: number;
  dailyPnl: number;
  dailyPnlPct: number;
  cumulativePnlPct: number;
  concentrationTop1: number;
  sellSignalsCount: number;
  actionHint: string;
}

export interface SystemHealthSummaryDto {
  pipelineStatus: HealthStatus;
  latestSuccessTime: string;
  failedStepsCount: number;
  dataCoveragePct: number;
  dqStatus: HealthStatus;
  apiHealthStatus: HealthStatus;
  versionLabel: string;
  systemHint: string;
}

export interface DashboardKpiVm {
  id: string;
  label: string;
  value: string;
  helperText: string;
  tone: StatusTone;
  href: string;
}

export interface DashboardMetricVm {
  id: string;
  label: string;
  value: string;
  helperText: string;
  tone: StatusTone;
}

export interface TodaySummaryViewModel {
  headline: string;
  summaryText: string;
  metrics: DashboardMetricVm[];
}

export interface OpportunityCardVm {
  id: string;
  name: string;
  strategyLabel: string;
  scoreLabel: string;
  helperText: string;
  tone: StatusTone;
  href: string;
}

export interface RiskEventVm {
  id: string;
  name: string;
  summary: string;
  scoreLabel: string;
  helperText: string;
  tone: StatusTone;
  href: string;
}

export interface DashboardSectionVm {
  title: string;
  summary: string;
  state: 'normal' | 'empty';
  metrics: DashboardMetricVm[];
}

export interface OpportunitySectionVm extends DashboardSectionVm {
  topOpportunities: OpportunityCardVm[];
}

export interface RiskSectionVm extends DashboardSectionVm {
  events: RiskEventVm[];
}

export interface PortfolioSectionVm extends DashboardSectionVm {
  actionHint: string;
}

export interface SystemIssueVm {
  id: string;
  name: string;
  summary: string;
  statusLabel: string;
  helperText: string;
  tone: StatusTone;
  href: string;
}

export interface SystemHealthSectionVm extends DashboardSectionVm {
  issues: SystemIssueVm[];
}

export interface DashboardViewModel {
  tradeDateText: string;
  generatedAtText: string;
  versionText: string;
  summaryText: string;
  kpis: DashboardKpiVm[];
  todaySummary: TodaySummaryViewModel;
  opportunity: OpportunitySectionVm;
  risk: RiskSectionVm;
  portfolio: PortfolioSectionVm;
  systemHealth: SystemHealthSectionVm;
}
