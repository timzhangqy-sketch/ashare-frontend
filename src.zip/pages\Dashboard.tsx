import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { getDashboardSummary } from '../api';
import {
  buildDashboardRuntimeSnapshot,
  isDashboardSummaryEmpty,
  mapDashboardSummaryToViewModel,
  mapRawDashboardResponseToDto,
} from '../adapters/dashboard';
import KpiCard from '../components/Dashboard/KpiCard';
import OpportunitySection from '../components/Dashboard/OpportunitySection';
import PortfolioSection from '../components/Dashboard/PortfolioSection';
import RiskSection from '../components/Dashboard/RiskSection';
import StatusState from '../components/Dashboard/StatusState';
import SystemHealthSection from '../components/Dashboard/SystemHealthSection';
import TodaySummarySection from '../components/Dashboard/TodaySummarySection';
import { getRouteMetaByKey } from '../config/routeMeta';
import { useDashboardRuntime } from '../context/DashboardRuntimeContext';
import { useDate } from '../context/DateContext';
import { fetchMockDashboardSummary } from '../mocks/dashboard';
import type {
  DashboardDataSource,
  DashboardLoadState,
  DashboardViewModel,
} from '../types/dashboard';

const dashboardMeta = getRouteMetaByKey('dashboard');
const mockStates: DashboardLoadState[] = ['normal', 'warning', 'loading', 'empty', 'error'];

function normalizeSource(value: string | null): DashboardDataSource {
  return value === 'mock' ? 'mock' : 'real';
}

function normalizeMockState(value: string | null): DashboardLoadState {
  return mockStates.includes(value as DashboardLoadState)
    ? (value as DashboardLoadState)
    : 'normal';
}

export default function Dashboard() {
  const [searchParams, setSearchParams] = useSearchParams();
  const source = normalizeSource(searchParams.get('source'));
  const mockState = normalizeMockState(searchParams.get('state'));
  const { selectedDate } = useDate();
  const { setSnapshot } = useDashboardRuntime();

  const [status, setStatus] = useState<'loading' | 'empty' | 'error' | 'normal'>('loading');
  const [viewModel, setViewModel] = useState<DashboardViewModel | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [retrySeed, setRetrySeed] = useState(0);

  useEffect(() => {
    let cancelled = false;

    setStatus('loading');
    setViewModel(null);
    setErrorMessage('');
    setSnapshot(null);

    if (source === 'mock') {
      if (mockState === 'loading') {
        return () => {
          cancelled = true;
          setSnapshot(null);
        };
      }

      fetchMockDashboardSummary(mockState)
        .then(dto => {
          if (cancelled) return;
          setViewModel(mapDashboardSummaryToViewModel(dto));
          setStatus(mockState === 'empty' || isDashboardSummaryEmpty(dto) ? 'empty' : 'normal');
          setSnapshot(buildDashboardRuntimeSnapshot(dto, 'mock'));
        })
        .catch(error => {
          if (cancelled) return;
          setStatus('error');
          setErrorMessage(
            error instanceof Error ? `Mock 数据源失败：${error.message}` : 'Mock 数据源失败。',
          );
        });

      return () => {
        cancelled = true;
        setSnapshot(null);
      };
    }

    getDashboardSummary(selectedDate)
      .then(raw => {
        if (cancelled) return;
        const dto = mapRawDashboardResponseToDto(raw);
        setViewModel(mapDashboardSummaryToViewModel(dto));
        setStatus(isDashboardSummaryEmpty(dto) ? 'empty' : 'normal');
        setSnapshot(buildDashboardRuntimeSnapshot(dto, 'real'));
      })
      .catch(error => {
        if (cancelled) return;
        setStatus('error');
        setErrorMessage(
          error instanceof Error
            ? `真实接口 /api/dashboard/summary 失败：${error.message}`
            : '真实接口 /api/dashboard/summary 失败。',
        );
      });

    return () => {
      cancelled = true;
      setSnapshot(null);
    };
  }, [mockState, retrySeed, selectedDate, setSnapshot, source]);

  const sourceLabel = source === 'real' ? '真实接口' : 'Mock 演示';
  const topLevelStatusText = useMemo(() => {
    if (status === 'loading') return '加载中';
    if (status === 'empty') return '空态';
    if (status === 'error') return '异常态';
    if (source === 'mock' && mockState === 'warning') return '预警态';
    return '正常态';
  }, [mockState, source, status]);

  const handleSourceChange = (nextSource: DashboardDataSource) => {
    const nextParams = new URLSearchParams(searchParams);
    nextParams.set('source', nextSource);
    if (nextSource === 'real') {
      nextParams.delete('state');
    }
    setSearchParams(nextParams);
  };

  const handleMockStateChange = (nextState: DashboardLoadState) => {
    const nextParams = new URLSearchParams(searchParams);
    nextParams.set('source', 'mock');
    if (nextState === 'normal') {
      nextParams.delete('state');
    } else {
      nextParams.set('state', nextState);
    }
    setSearchParams(nextParams);
  };

  const handleRetry = () => {
    setRetrySeed(seed => seed + 1);
  };

  return (
    <div className="dashboard-page" data-testid="dashboard-page">
      <section className="dashboard-hero card">
        <div className="dashboard-hero-copy">
          <div className="page-title">
            {dashboardMeta.title}
            <span className="page-badge badge-blue">Round 4 Real Summary</span>
          </div>
          <p className="page-desc">{dashboardMeta.description}</p>
          <p className="dashboard-hero-note">
            当前默认走真实 summary。页面继续只消费 adapter 产出的 ViewModel，
            mock 仍保留给验收和回归测试使用。
          </p>
        </div>
        <div className="dashboard-hero-actions">
          <Link className="btn-primary dashboard-link-btn" to="/signals">
            前往信号域
          </Link>
          <Link className="btn-secondary dashboard-link-btn" to="/portfolio">
            前往组合域
          </Link>
        </div>
      </section>

      <section className="card dashboard-state-toolbar">
        <div className="dashboard-state-copy">
          <div className="card-title">数据源与状态</div>
          <div className="c-muted">
            当前数据源：{sourceLabel}。状态：{topLevelStatusText}。真实源按请求结果进入
            normal / loading / empty / error；mock 源保留 state 演示入口。
          </div>
        </div>
        <div className="dashboard-state-actions">
          <button
            className={`btn-secondary dashboard-state-btn${source === 'real' ? ' active' : ''}`}
            onClick={() => handleSourceChange('real')}
            type="button"
          >
            source=real
          </button>
          <button
            className={`btn-secondary dashboard-state-btn${source === 'mock' ? ' active' : ''}`}
            onClick={() => handleSourceChange('mock')}
            type="button"
          >
            source=mock
          </button>
          {source === 'mock'
            ? mockStates.map(item => (
                <button
                  key={item}
                  className={`btn-secondary dashboard-state-btn${mockState === item ? ' active' : ''}`}
                  onClick={() => handleMockStateChange(item)}
                  type="button"
                >
                  state={item}
                </button>
              ))
            : null}
        </div>
      </section>

      {status === 'error' ? (
        <section className="card">
          <div className="dashboard-module-body">
            <StatusState
              type="error"
              title={source === 'real' ? '真实接口加载失败' : 'Mock 数据源加载失败'}
              description={errorMessage || '当前无法生成仪表盘摘要。'}
              actionLabel="重新加载"
              onAction={handleRetry}
            />
          </div>
        </section>
      ) : null}

      <TodaySummarySection data={viewModel?.todaySummary} onRetry={handleRetry} status={status} />

      <section className="dashboard-kpi-grid">
        {status === 'loading'
          ? Array.from({ length: 9 }).map((_, index) => (
              <div key={index} className="dashboard-kpi-skeleton" />
            ))
          : viewModel?.kpis.map(item => <KpiCard item={item} key={item.id} />)}
      </section>

      <section className="dashboard-section-grid">
        <OpportunitySection data={viewModel?.opportunity} onRetry={handleRetry} status={status} />
        <RiskSection data={viewModel?.risk} onRetry={handleRetry} status={status} />
        <PortfolioSection data={viewModel?.portfolio} onRetry={handleRetry} status={status} />
        <SystemHealthSection data={viewModel?.systemHealth} onRetry={handleRetry} status={status} />
      </section>

      <section className="card dashboard-footer-strip">
        <div className="dashboard-footer-item">
          <span className="dashboard-footer-label">数据源</span>
          <span className="dashboard-footer-value">{sourceLabel}</span>
        </div>
        <div className="dashboard-footer-item">
          <span className="dashboard-footer-label">交易日 / 更新时间</span>
          <span className="dashboard-footer-value">
            {viewModel ? `${viewModel.tradeDateText} / ${viewModel.generatedAtText}` : '--'}
          </span>
        </div>
        <div className="dashboard-footer-item">
          <span className="dashboard-footer-label">版本标签</span>
          <span className="dashboard-footer-value">{viewModel?.versionText ?? '--'}</span>
        </div>
      </section>
    </div>
  );
}
