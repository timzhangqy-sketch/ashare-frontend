import { Outlet } from 'react-router-dom';
import ContextPanelSlot from './ContextPanelSlot';
import Sidebar from './Sidebar';
import TopBar from './TopBar';

export default function Layout() {
  return (
    <div className="layout">
      <Sidebar />
      <div className="main-area">
        <TopBar />
        <div className="workspace-shell">
          <main className="content">
            <Outlet />
          </main>
          <ContextPanelSlot />
        </div>
        <footer className="page-footer">
          A股前端工作台
        </footer>
      </div>
    </div>
  );
}
