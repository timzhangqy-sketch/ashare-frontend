import type { RiskContextModel } from '../../types/risk';

interface RiskContextAction {
  key: string;
  label: string;
  enabled: boolean;
  note: string;
  href: string | null;
}

interface RiskContextPanelProps {
  context: RiskContextModel | null;
  actions: RiskContextAction[];
  onAction: (action: RiskContextAction) => void;
  noFocusTitle: string;
  noFocusText: string;
}

export default function RiskContextPanel({
  context,
  actions,
  onAction,
  noFocusTitle,
  noFocusText,
}: RiskContextPanelProps) {
  return (
    <section className="card risk-context-card">
      <div className="card-header">
        <span className="card-title">当前工作上下文</span>
        <span className="c-muted" style={{ fontSize: 12 }}>
          {context ? '围绕当前选中股票查看风控结论、分数摘要和下一步建议。' : '从左侧列表选择一只股票后，这里会显示对应的风控上下文。'}
        </span>
      </div>
      <div className="risk-context-body">
        {context ? (
          <>
            <div className="risk-context-title">{context.title}</div>
            <div className="risk-context-code">{context.tsCode}</div>
            <div className="risk-context-status">{context.sourceDomainLabel}</div>

            <div className="risk-context-section">
              <div className="risk-context-section-title">股票身份</div>
              <div className="risk-context-grid">
                <div>
                  <div className="risk-context-label">当前来源</div>
                  <div className="risk-context-value">{context.sourceLabel}</div>
                </div>
                <div>
                  <div className="risk-context-label">来源策略</div>
                  <div className="risk-context-value">{context.sourceStrategyLabel}</div>
                </div>
              </div>
            </div>

            <div className="risk-context-section">
              <div className="risk-context-section-title">Gate 结论</div>
              <div className="risk-context-list">
                {context.gateConclusion.map(item => (
                  <div key={item.label} className="risk-context-list-row">
                    <span className="risk-context-label">{item.label}</span>
                    <span className="risk-context-list-value">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="risk-context-section">
              <div className="risk-context-section-title">分数摘要</div>
              <div className="risk-context-list">
                {context.scoreSummary.map(item => (
                  <div key={item.label} className="risk-context-list-row">
                    <span className="risk-context-label">{item.label}</span>
                    <span className="risk-context-list-value">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="risk-context-section">
              <div className="risk-context-section-title">可执行仓位说明</div>
              <div className="risk-context-list">
                {context.positionSummary.map(item => (
                  <div key={item.label} className="risk-context-list-row">
                    <span className="risk-context-label">{item.label}</span>
                    <span className="risk-context-list-value">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="risk-context-section">
              <div className="risk-context-section-title">下一步动作</div>
              <div className="risk-context-list">
                <div className="risk-context-list-row">
                  <span className="risk-context-label">交易结论</span>
                  <span className="risk-context-list-value">{context.tradeAllowedLabel}</span>
                </div>
                <div className="risk-context-list-row">
                  <span className="risk-context-label">推荐下一步</span>
                  <span className="risk-context-list-value">{context.recommendedNextStep}</span>
                </div>
              </div>
              <div className="risk-context-actions">
                {actions.map(action => (
                  <button
                    key={action.key}
                    type="button"
                    className={`risk-context-action${action.enabled ? '' : ' is-disabled'}`}
                    onClick={() => onAction(action)}
                    disabled={!action.enabled}
                    title={action.note}
                  >
                    {action.label}
                  </button>
                ))}
              </div>
            </div>
          </>
        ) : (
          <div className="risk-context-empty">
            <div className="risk-empty-title">{noFocusTitle}</div>
            <div className="risk-empty-text">{noFocusText}</div>
          </div>
        )}
      </div>
    </section>
  );
}
