import { useLocation } from 'react-router-dom';
import { useContextPanel } from '../../context/ContextPanelContext';
import { getRouteMeta } from '../../config/routeMeta';
import GlobalContextPanel from '../ContextPanel/GlobalContextPanel';

function buildDefaultCopy(pathname: string, title: string) {
  if (pathname.startsWith('/portfolio')) {
    return {
      kicker: '当前工作上下文',
      title: '持仓中心',
      copy: '围绕当前选中记录查看来源、持仓信息与退出判断。',
    };
  }

  return {
    kicker: '工作上下文',
    title,
    copy: '当前工作域可在这里承接选中对象、来源链路与后续详情块。',
  };
}

export default function ContextPanelSlot() {
  const { pathname } = useLocation();
  const { panel } = useContextPanel();

  if (pathname.startsWith('/risk') || pathname.startsWith('/research') || pathname.startsWith('/execution') || pathname.startsWith('/system')) {
    return null;
  }

  if (panel.isOpen) {
    return <GlobalContextPanel panel={panel} />;
  }

  const meta = getRouteMeta(pathname);
  const content = buildDefaultCopy(pathname, meta.title);

  return (
    <aside className="context-panel-slot" aria-label="工作上下文侧栏">
      <div className="context-panel-card" data-testid="context-panel-empty">
        <div className="context-panel-kicker">{content.kicker}</div>
        <div className="context-panel-title">{content.title}</div>
        <p className="context-panel-copy">{content.copy}</p>
        <div className="context-panel-meta">
          <span className="context-panel-tag">当前路径</span>
          <span>{meta.path}</span>
        </div>
      </div>
    </aside>
  );
}
