import type { KlineItem, RiskApiItem, StockDetailResp } from '../api';
import {
  fetchStockContext,
  fetchStockContextKline,
  fetchStockContextLifecycle,
  fetchStockContextRisk,
  type StockContextLifecycleResp,
} from '../api/contextPanel';
import type {
  ContextPanelLoadStatus,
  ContextPanelState,
  ContextPanelTag,
  StockContextKlineData,
  StockContextLifecycleData,
  StockContextMainData,
  StockContextPanelPayload,
  StockContextRiskData,
  StockContextViewModel,
} from '../types/contextPanel';

function sourceLabel(sourcePage: ContextPanelState['sourcePage']) {
  if (sourcePage === 'signals') return '来自 Signals';
  if (sourcePage === 'watchlist') return '来自观察池';
  if (sourcePage === 'portfolio') return '来自持仓中心';
  if (sourcePage === 'risk') return '来自风控中心';
  if (sourcePage === 'research') return '来自研究中心';
  if (sourcePage === 'execution') return '来自模拟执行';
  if (sourcePage === 'dashboard') return '来自 Dashboard';
  return '直接进入';
}

function toSignedPercent(value: number | null | undefined) {
  if (value == null) return '--';
  return `${value > 0 ? '+' : ''}${value.toFixed(2)}%`;
}

function normalizeMain(detail: StockDetailResp | null, payload: StockContextPanelPayload, tsCode: string): StockContextMainData | null {
  if (!detail && !payload.tsCode) return null;
  return {
    tsCode,
    name: detail?.name ?? payload.name ?? payload.title ?? tsCode,
    industry: detail?.industry ?? null,
    close: detail?.close ?? null,
    pctChg: detail?.pct_chg ?? null,
    turnoverRate: detail?.turnover_rate ?? null,
    amountYi: detail?.amount_yi ?? null,
    inWatchlist: detail?.in_watchlist ?? false,
    sourceStrategy: payload.sourceStrategy ?? detail?.watchlist_strategy ?? null,
    buySignal: detail?.watchlist_buy_signal ?? null,
    sellSignal: detail?.watchlist_sell_signal ?? null,
  };
}

function normalizeKline(items: KlineItem[] | null): StockContextKlineData | null {
  if (!items || !items.length) return null;
  const latest = items[items.length - 1];
  return {
    latestDate: latest.date,
    latestClose: latest.close,
    latestOpen: latest.open,
    latestHigh: latest.high,
    latestLow: latest.low,
    lastFiveCloses: items.slice(-5).map(item => item.close),
  };
}

function normalizeRisk(risk: RiskApiItem | null): StockContextRiskData | null {
  if (!risk) return null;
  return {
    tradeAllowed: risk.trade_allowed ?? null,
    riskLevel: risk.risk_level ?? null,
    riskScoreTotal: risk.risk_score_total ?? null,
    blockReason: risk.block_reason ?? null,
    blockSource: risk.block_source ?? null,
    capMultiplier: risk.position_cap_multiplier_final ?? null,
  };
}

function normalizeLifecycle(
  lifecycle: StockContextLifecycleResp | null,
  detail: StockDetailResp | null,
): StockContextLifecycleData | null {
  const entryDate = lifecycle?.entry_date ?? detail?.watchlist_entry_date ?? null;
  const poolDay = lifecycle?.pool_day ?? detail?.watchlist_pool_day ?? null;
  const gainSinceEntry = lifecycle?.gain_since_entry ?? detail?.watchlist_gain_since_entry ?? null;
  const positionStatus = lifecycle?.position_status ?? (detail?.in_watchlist ? 'in_watchlist' : null);
  const lifecycleLabel = lifecycle?.lifecycle_label ?? (detail?.in_watchlist ? '观察中' : '未进入生命周期');

  if (!entryDate && poolDay == null && gainSinceEntry == null && !positionStatus && !lifecycleLabel) {
    return null;
  }

  return {
    lifecycleLabel,
    entryDate,
    poolDay,
    gainSinceEntry,
    positionStatus,
  };
}

function mergeTags(payload: StockContextPanelPayload, main: StockContextMainData | null, risk: StockContextRiskData | null): ContextPanelTag[] {
  const tags: ContextPanelTag[] = [];
  if (payload.sourceStrategy) tags.push({ label: payload.sourceStrategy, tone: 'strategy' });
  if (main?.buySignal) tags.push({ label: `买点 ${main.buySignal}`, tone: 'state' });
  if (main?.sellSignal) tags.push({ label: `卖点 ${main.sellSignal}`, tone: 'risk' });
  if (main?.inWatchlist) tags.push({ label: '观察池', tone: 'source' });
  if (risk?.tradeAllowed != null) tags.push({ label: risk.tradeAllowed ? '允许执行' : '限制执行', tone: risk.tradeAllowed ? 'state' : 'risk' });
  return [...tags, ...(payload.tags ?? [])];
}

function buildSummaryItems(
  payload: StockContextPanelPayload,
  main: StockContextMainData | null,
  risk: StockContextRiskData | null,
  lifecycle: StockContextLifecycleData | null,
) {
  if (payload.summaryItems?.length) return payload.summaryItems;
  return [
    { label: '来源策略', value: main?.sourceStrategy ?? '--' },
    { label: '最新涨跌', value: toSignedPercent(main?.pctChg) },
    { label: '风险结论', value: risk?.tradeAllowed == null ? '--' : risk.tradeAllowed ? '允许执行' : '限制执行' },
    { label: '生命周期', value: lifecycle?.lifecycleLabel ?? '--' },
  ];
}

function sectionState<T>(data: T | null, error: unknown): { status: ContextPanelLoadStatus; note: string } {
  if (data) return { status: 'ready', note: '已展示当前可用信息' };
  if (error) return { status: 'partial', note: '部分信息暂未返回，已保留可用内容' };
  return { status: 'empty', note: '当前没有可展示信息' };
}

export async function loadStockContextViewModel(
  panel: ContextPanelState,
  tradeDate: string,
): Promise<StockContextViewModel> {
  const payload = ((panel.payload ?? {}) as StockContextPanelPayload) || {};
  const tsCode = payload.tsCode ?? panel.tsCode ?? panel.focus ?? panel.entityKey ?? '';

  const [mainResult, klineResult, riskResult, lifecycleResult] = await Promise.allSettled([
    fetchStockContext(tsCode, tradeDate),
    fetchStockContextKline(tsCode),
    fetchStockContextRisk(tsCode, tradeDate),
    fetchStockContextLifecycle(tsCode, tradeDate),
  ]);

  const detail = mainResult.status === 'fulfilled' ? mainResult.value : null;
  const kline = klineResult.status === 'fulfilled' ? normalizeKline(klineResult.value) : null;
  const risk = riskResult.status === 'fulfilled' ? normalizeRisk(riskResult.value) : null;
  const lifecycle = lifecycleResult.status === 'fulfilled' ? normalizeLifecycle(lifecycleResult.value, detail) : null;
  const main = normalizeMain(detail, payload, tsCode);

  const hasAnyData = Boolean(main || kline || risk || lifecycle);
  const hasAllData = Boolean(main && kline && risk && lifecycle);
  const status: ContextPanelLoadStatus = hasAllData ? 'ready' : hasAnyData ? 'partial' : 'error';

  return {
    status,
    statusText: status === 'ready' ? '信息已完整加载' : status === 'partial' ? '部分信息已加载' : '当前仅保留最小上下文',
    title: main?.name ?? payload.name ?? payload.title ?? tsCode,
    tsCode,
    sourceLabel: sourceLabel(panel.sourcePage),
    sourceStrategy: main?.sourceStrategy ?? payload.sourceStrategy ?? null,
    tags: mergeTags(payload, main, risk),
    summaryItems: buildSummaryItems(payload, main, risk, lifecycle),
    actions: payload.actions ?? [],
    main,
    kline: {
      ...sectionState(kline, klineResult.status === 'rejected' ? klineResult.reason : null),
      data: kline,
    },
    risk: {
      ...sectionState(risk, riskResult.status === 'rejected' ? riskResult.reason : null),
      data: risk,
    },
    lifecycle: {
      ...sectionState(lifecycle, lifecycleResult.status === 'rejected' ? lifecycleResult.reason : null),
      data: lifecycle,
    },
  };
}
