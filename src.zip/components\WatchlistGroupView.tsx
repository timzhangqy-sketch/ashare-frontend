import { CrossTags } from './CrossTags';
import WatchlistActionMenu from './WatchlistActionMenu';
import WatchlistStatusBadge from './WatchlistStatusBadge';
import type { WatchlistActionVm, WatchlistGroupVm, WatchlistRowVm } from '../types/watchlist';

function formatSignedPercent(value: number | null | undefined, decimal = false): string {
  if (value == null) return '--';
  const parsed = decimal ? value * 100 : value;
  return `${parsed > 0 ? '+' : ''}${parsed.toFixed(2)}%`;
}

export default function WatchlistGroupView({
  groups,
  selectedCode,
  onSelect,
  onAction,
}: {
  groups: WatchlistGroupVm[];
  selectedCode: string | null;
  onSelect: (row: WatchlistRowVm) => void;
  onAction: (row: WatchlistRowVm, action: WatchlistActionVm) => void;
}) {
  return (
    <div className="watchlist-group-view">
      {groups.map(group => (
        <section key={group.key} className="watchlist-group-card">
          <div className="watchlist-group-head">
            <div>
              <div className="watchlist-group-title">{group.label}</div>
              <div className="watchlist-group-helper">{group.helper}</div>
            </div>
            <div className="watchlist-group-count">{group.count}</div>
          </div>
          {group.rows.length === 0 ? (
            <div className="watchlist-group-empty">当前分组暂无股票。</div>
          ) : (
            <div className="watchlist-group-table">
              {group.rows.map(row => (
                <div
                  key={row.id}
                  className={`watchlist-group-row${selectedCode === row.tsCode ? ' selected' : ''}`}
                  data-watchlist-row={row.id}
                  onClick={() => onSelect(row)}
                >
                  <div className="watchlist-group-main">
                    <div className="watchlist-group-stock">
                      <div className="watchlist-cell-title">
                        {row.name}
                        <CrossTags tsCode={row.tsCode} currentStrategy={row.strategy} />
                      </div>
                      <div className="watchlist-inline-meta">{row.tsCode}</div>
                    </div>
                    <div className="watchlist-group-meta">
                      <WatchlistStatusBadge status={row.lifecycleStatus} />
                      <span className="watchlist-mini-pill active">{row.strategy}</span>
                      {row.inPortfolio ? <span className="watchlist-mini-pill active">已移交</span> : null}
                    </div>
                    <div className="watchlist-group-snapshot">
                      <span>{formatSignedPercent(row.latestPctChg)}</span>
                      <span>{formatSignedPercent(row.gainSinceEntry, true)}</span>
                    </div>
                  </div>
                  <div className="watchlist-group-actions" onClick={event => event.stopPropagation()}>
                    <WatchlistActionMenu actions={row.availableActions} onAction={action => onAction(row, action)} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      ))}
    </div>
  );
}
