interface RiskHeaderProps {
  title: string;
  description: string;
  tradeDate: string;
  generatedAtText: string;
  sourceLabel: string;
  focusLabel: string;
  scopeLabel: string;
}

export default function RiskHeader({
  title,
  description,
  tradeDate,
  generatedAtText,
  sourceLabel,
  focusLabel,
  scopeLabel,
}: RiskHeaderProps) {
  return (
    <section className="card risk-hero">
      <div>
        <div className="risk-kicker">风控中心工作台</div>
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="risk-flags">
          <span className="risk-mini-pill active">{sourceLabel}</span>
          <span className="risk-mini-pill">{focusLabel}</span>
          <span className="risk-mini-pill">{scopeLabel}</span>
        </div>
      </div>

      <div className="risk-hero-side">
        <div className="risk-kicker">交易日</div>
        <div className="risk-date">{tradeDate}</div>
        <div className="risk-sub">{generatedAtText}</div>
      </div>
    </section>
  );
}
