import axios from 'axios';
import type { RawDashboardSummaryResponse } from '../types/dashboard';

// In dev, Vite proxies /api → backend (see vite.config.ts), so baseURL is '' (relative).
// In production, set VITE_API_BASE_URL if the frontend and backend are on different origins.
const api = axios.create({
  baseURL: (import.meta.env.VITE_API_BASE_URL as string) || '',
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.response.use(
  res => res,
  err => {
    console.error('[API Error]', err.response?.status, err.message);
    return Promise.reject(err);
  },
);

// ── Types ────────────────────────────────────────────────────────────────

export interface IgniteItem {
  rank:          number;
  ts_code:       string;
  name:          string;
  ignite_score:  number;
  s_candidate:   number;  // VR量比 sub-score
  s_turn:        number;  // 换手率 sub-score
  s_ret20:       number;  // 20日收益 sub-score
  s_rs:          number;  // RS强度 sub-score
  s_ma5:         number;  // MA5斜率 sub-score
  vr:            number;  // actual VR value
  turnover_rate: number;
  close:         number;
  pct_chg:       number;
  amount_yi:     number;  // 成交额(亿)
}

export interface ContinuationItem {
  ts_code:       string;
  name:          string;
  cont_score:    number;
  pool_day:      number;
  buy_signal:    string | null;  // 'PULLBACK' | 'REHEAT' | null
  turnover_rate: number;
  vr:            number;
}

export interface PoolItem {
  ts_code:       string;
  name:          string;
  entry_rank:    number;
  entry_score:   number;
  turnover_rate: number;
  pct_chg:       number;
  amount_yi:     number;
  vol_wan:       number;  // 成交量(万手)
}

export interface Retoc2Item {
  ts_code:       string;
  name:          string;
  rank:          number;
  grade:         string;        // 'A' | 'B'
  total_bars_10: number;        // 10日bar数
  cnt_bars:      number;        // 当日bar数
  ret10_pct:     number | null; // 10日收益%
  turnover_rate: number | null;
  pct_chg:       number | null; // 今日涨幅%
  close:         number | null;
  ma20:          number | null;
  amount_yi:     number | null; // 成交额(亿)
}

export interface PipelineStepResp {
  step:        string;
  status:      'ok' | 'warn' | 'fail';
  duration_ms: number;
  message:     string;
  started_at:  string;  // ISO datetime or "HH:MM" string
}

// ── Response normalizer ───────────────────────────────────────────────────
// All list endpoints return { date: string, data: T[] } or a bare T[].
// This helper unwraps either shape and always returns a safe array.
function toArray<T>(raw: unknown): T[] {
  if (Array.isArray(raw)) return raw as T[];
  if (raw && typeof raw === 'object') {
    const obj = raw as Record<string, unknown>;
    if (Array.isArray(obj.data))  return obj.data  as T[];
    if (Array.isArray(obj.steps)) return obj.steps as T[];
    if (Array.isArray(obj.items)) return obj.items as T[];
  }
  return [];
}

// ── API functions ─────────────────────────────────────────────────────────

export async function fetchIgnite(date: string): Promise<IgniteItem[]> {
  const res = await api.get(`/api/ignite/v2/${date}`);
  return toArray<IgniteItem>(res.data);
}

export async function fetchContinuation(date: string): Promise<ContinuationItem[]> {
  const res = await api.get(`/api/continuation/v2/${date}`);
  return toArray<ContinuationItem>(res.data);
}

export async function fetchPool(date: string): Promise<PoolItem[]> {
  const res = await api.get(`/api/pool/${date}`);
  return toArray<PoolItem>(res.data);
}

export async function fetchRetoc2(date: string): Promise<Retoc2Item[]> {
  const res = await api.get(`/api/retoc2/${date}`);
  return toArray<Retoc2Item>(res.data);
}

export async function fetchPipeline(date: string): Promise<PipelineStepResp[]> {
  const res = await api.get(`/api/pipeline/${date}`);
  return toArray<PipelineStepResp>(res.data);
}

export async function fetchTradeDates(): Promise<string[]> {
  const res = await api.get<{ dates: string[] }>('/api/trade-dates');
  return res.data.dates;
}

export interface PatternT2up9Item {
  ts_code:         string;
  name:            string;
  ret_t2:          number;  // decimal, e.g. 0.095 = 9.5%
  ret_t1:          number;
  ret_t0:          number;
  ret_2d:          number;
  in_pool:         boolean;
  in_continuation: boolean;
}

export interface PatternGreen10Item {
  ts_code:         string;
  name:            string;
  green_days_10d:  number;
  red_days_10d:    number;
  flat_days_10d:   number;
  in_pool:         boolean;
  in_continuation: boolean;
}

export async function fetchPatternT2up9(date: string): Promise<PatternT2up9Item[]> {
  const res = await api.get(`/api/pattern/t2up9/${date}`);
  return toArray<PatternT2up9Item>(res.data);
}

export async function fetchPatternGreen10(date: string): Promise<PatternGreen10Item[]> {
  const res = await api.get(`/api/pattern/green10/${date}`);
  return toArray<PatternGreen10Item>(res.data);
}

// ── Portfolio ─────────────────────────────────────────────────────────────

export interface PortfolioItem {
  id:                  number;
  ts_code:             string;
  name:                string;
  source_strategy:     string;
  open_date:           string;
  open_price:          number;
  shares:              number;
  cost_amount:         number | null;
  latest_close:        number | null;
  market_value:        number | null;
  unrealized_pnl:      number | null;
  unrealized_pnl_pct:  number | null;
  hold_days:           number | null;
  action_signal:       string | null;
  signal_reason:       string | null;
  close_date:          string | null;
  close_price:         number | null;
  realized_pnl:        number | null;
  realized_pnl_pct:    number | null;
  status:              string;
  today_pnl:           number | null;
  today_pnl_pct:       number | null;
}

export interface PortfolioResponse {
  data:          PortfolioItem[];
  total_cost:    number;
  total_value:   number;
  total_pnl:     number;
  total_pnl_pct: number;
  count:         number;
}

export interface PortfolioAddPayload {
  ts_code:         string;
  name:            string;
  open_price:      number;
  shares:          number;
  open_date:       string;
  source_strategy: string;
}

export interface TransactionItem {
  id:              number;
  ts_code:         string;
  trade_date:      string;
  trade_type:      string;
  price:           number;
  shares:          number;
  amount:          number;
  trigger_source:  string | null;
  notes:           string | null;
}

export async function fetchPortfolio(status = 'open'): Promise<PortfolioResponse> {
  const res = await api.get('/api/portfolio', { params: { status } });
  const raw = res.data;
  return {
    data:          toArray<PortfolioItem>(raw),
    total_cost:    raw.total_cost    ?? 0,
    total_value:   raw.total_value   ?? 0,
    total_pnl:     raw.total_pnl     ?? 0,
    total_pnl_pct: raw.total_pnl_pct ?? 0,
    count:         raw.count         ?? 0,
  };
}

export async function addPortfolio(payload: PortfolioAddPayload): Promise<void> {
  await api.post('/api/portfolio/add', payload);
}

export async function closePortfolio(id: number, close_price: number): Promise<void> {
  const close_date = new Date().toISOString().split('T')[0];
  await api.post(`/api/portfolio/${id}/close`, { close_price, close_date });
}

export async function addPosition(id: number, price: number, shares: number, date: string): Promise<void> {
  await api.post(`/api/portfolio/${id}/add_position`, { price, shares, date });
}

export async function fetchTransactions(portfolio_id: number): Promise<TransactionItem[]> {
  const res = await api.get(`/api/portfolio/transactions/${portfolio_id}`);
  return toArray<TransactionItem>(res.data);
}

// ── Vol Surge ─────────────────────────────────────────────────────────────

export interface VolSurgeItem {
  ts_code:       string;
  name:          string;
  entry_rank:    number;
  close:         number;
  vr_t0:         number;  // 今日量比
  vr_t1:         number;
  vr_t2:         number;
  avg_vr3:       number;  // 3日均量比
  turnover_rate: number;
  amount_yi:     number;  // 成交额(亿)
  ret5:          number;  // 5日涨幅, decimal e.g. 0.05 = 5%
  ret20:         number;  // 20日涨幅
  ma20:          number;
}

export async function fetchVolSurge(date: string): Promise<VolSurgeItem[]> {
  const res = await api.get(`/api/vol_surge/${date}`);
  return toArray<VolSurgeItem>(res.data);
}

// ── Watchlist ─────────────────────────────────────────────────────────────

export interface WatchlistItem {
  ts_code:          string;
  name:             string;
  strategy:         string;   // e.g. 'VOL_SURGE' | 'RETOC2' | 'PATTERN_T2UP9' | 'PATTERN_GREEN10'
  entry_date:       string;   // YYYY-MM-DD
  pool_day:         number;
  latest_pct_chg:   number;   // today's pct change (%)
  gain_since_entry: number;   // cumulative gain since entry (%)
  buy_signal:       string | null;
  sell_signal:      string | null;
}

export async function fetchWatchlist(): Promise<WatchlistItem[]> {
  const res = await api.get('/api/watchlist');
  return toArray<WatchlistItem>(res.data);
}

// ── Stock Detail ──────────────────────────────────────────────────────────

export interface FinancialYear {
  year:             number;
  revenue_yi:       number | null;
  total_profit_yi:  number | null;
  net_income_yi:    number | null;
}

export interface StockDetailResp {
  ts_code:       string;
  name:          string;
  industry:      string | null;
  is_st:         boolean;
  list_date:     string | null;
  market_cap_yi: number | null;
  pe_ttm:        number | null;
  pb:            number | null;
  turnover_rate: number | null;
  close:         number | null;
  open:          number | null;
  high:          number | null;
  low:           number | null;
  pct_chg:       number | null;
  amount_yi:     number | null;
  ma5:           number | null;
  ma10:          number | null;
  ma20:          number | null;
  vr:            number | null;
  above_ma20_days: number;
  in_watchlist:  boolean;
  watchlist_strategy?:         string;
  watchlist_entry_date?:       string;
  watchlist_entry_price?:      number;
  watchlist_pool_day?:         number;
  watchlist_gain_since_entry?: number;
  watchlist_max_gain?:         number;
  watchlist_buy_signal?:       string | null;
  watchlist_sell_signal?:      string | null;
  financials: FinancialYear[];
  error?: string;
}

export async function fetchStockDetail(ts_code: string, date: string): Promise<StockDetailResp> {
  const res = await api.get(`/api/stock_detail/${ts_code}/${date}`);
  return res.data as StockDetailResp;
}

// ── AI Analysis ───────────────────────────────────────────────────────────

export interface AIAnalysisResp {
  bull_factors: string[];
  bear_factors: string[];
  advice:       '买入' | '持有' | '卖出';
  confidence:   number;
  stop_loss:    string;
  target:       string;
  error?:       string;
}

export async function fetchAIAnalysis(ts_code: string, date: string): Promise<AIAnalysisResp> {
  const res = await api.get(`/api/ai_analysis/${ts_code}/${date}`);
  return res.data as AIAnalysisResp;
}

// ── Backtest ──────────────────────────────────────────────────────────────

export interface BacktestSummaryItem {
  strategy:       string;
  sample_t5:      number;
  sample_t10:     number;
  sample_t20:     number;
  avg_ret_t5:     number | null;
  avg_ret_t10:    number | null;
  avg_ret_t20:    number | null;
  win_rate_t5:    number | null;
  win_rate_t10:   number | null;
  win_rate_t20:   number | null;
  median_ret_t5:  number | null;
  median_ret_t10: number | null;
  median_ret_t20: number | null;
}

export interface BacktestDetailItem {
  ts_code:     string;
  name:        string;
  strategy:    string;
  entry_date:  string;
  entry_price: number;
  ret_t5:      number | null;
  ret_t10:     number | null;
  ret_t20:     number | null;
  result_t5:   'win' | 'loss' | 'pending';
}

export async function fetchBacktestSummary(): Promise<BacktestSummaryItem[]> {
  const res = await api.get('/api/backtest/summary');
  return toArray<BacktestSummaryItem>(res.data);
}

export async function fetchBacktestDetail(strategy: string, limit = 200): Promise<BacktestDetailItem[]> {
  const res = await api.get('/api/backtest/detail', { params: { strategy, limit } });
  return toArray<BacktestDetailItem>(res.data);
}

export interface ResearchFactorIcItem {
  factor_name: string;
  horizon: 'T1' | 'T3' | 'T5' | 'T10' | 'T20';
  ic: number;
  icir: number;
  bucket: string;
  corr_placeholder?: string | null;
}

export interface ResearchAttributionItem {
  group_type: 'strategy' | 'market' | 'style';
  group_key: string;
  sample_n: number;
  avg_return: number;
  win_rate: number;
  drawdown: number;
}

export interface ResearchResonanceItem {
  strategy_combo: string;
  cross_strategy_count: number;
  sample_n: number;
  avg_return: number;
  win_rate: number;
  excess_return: number;
}

async function tryResearchGet<T>(paths: string[], params?: Record<string, string | number | undefined>): Promise<T> {
  let lastError: unknown;
  for (const path of paths) {
    try {
      const res = await api.get(path, { params });
      return res.data as T;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError;
}

export async function fetchResearchFactorIc(
  strategy?: string,
): Promise<ResearchFactorIcItem[]> {
  const raw = await tryResearchGet<unknown>(
    ['/api/research/factor_ic', '/api/research/factor-ic', '/api/factor_ic', '/api/factor/ic'],
    { strategy },
  );
  return toArray<ResearchFactorIcItem>(raw);
}

export async function fetchResearchAttribution(
  strategy?: string,
): Promise<ResearchAttributionItem[]> {
  const raw = await tryResearchGet<unknown>(
    ['/api/research/strategy_attribution', '/api/research/attribution', '/api/attribution'],
    { strategy },
  );
  return toArray<ResearchAttributionItem>(raw);
}

export async function fetchResearchResonance(
  strategy?: string,
): Promise<ResearchResonanceItem[]> {
  const raw = await tryResearchGet<unknown>(
    ['/api/research/resonance_analysis', '/api/research/resonance', '/api/resonance'],
    { strategy },
  );
  return toArray<ResearchResonanceItem>(raw);
}

// ── K-line ─────────────────────────────────────────────────────────────────

export interface KlineItem {
  date:   string;
  open:   number;
  high:   number;
  low:    number;
  close:  number;
  volume: number;
  ma5:    number | null;
  ma10:   number | null;
  ma20:   number | null;
}

export async function fetchKline(tsCode: string, days = 60): Promise<KlineItem[]> {
  const res = await api.get(`/api/kline/${tsCode}`, { params: { days } });
  return toArray<KlineItem>(res.data);
}

// ── Cross-strategy ─────────────────────────────────────────────────────────

export async function fetchCrossStrategies(): Promise<Record<string, string[]>> {
  const res = await api.get('/api/watchlist/cross_strategies');
  return (res.data?.data ?? {}) as Record<string, string[]>;
}

export interface RiskApiItem {
  ts_code: string;
  name?: string | null;
  trade_date?: string | null;
  source_domain?: 'watchlist' | 'portfolio' | null;
  source_strategy?: string | null;
  in_watchlist?: boolean | null;
  in_portfolio?: boolean | null;
  trade_allowed?: boolean | null;
  block_reason?: string | null;
  block_source?: string | null;
  risk_score_total?: number | null;
  risk_score_financial?: number | null;
  risk_score_market?: number | null;
  risk_score_event?: number | null;
  risk_score_compliance?: number | null;
  cap_financial?: number | null;
  cap_market?: number | null;
  cap_event?: number | null;
  cap_compliance?: number | null;
  position_cap_multiplier_final?: number | null;
  risk_level?: string | null;
  detail_json?: Record<string, unknown> | null;
}

export interface SimOrderApiItem {
  id?: string | number | null;
  order_id?: string | number | null;
  ts_code?: string | null;
  name?: string | null;
  source_domain?: string | null;
  source_strategy?: string | null;
  order_type?: string | null;
  side?: string | null;
  qty?: number | null;
  shares?: number | null;
  price?: number | null;
  submit_time?: string | null;
  trade_date?: string | null;
  status?: string | null;
  fill_status?: string | null;
  trade_allowed?: boolean | null;
  block_reason?: string | null;
  block_source?: string | null;
  risk_level?: string | null;
  position_cap_multiplier_final?: number | null;
  related_fill_ids?: Array<string | number> | null;
  related_position_id?: string | number | null;
}

export interface SimPositionApiItem {
  id?: string | number | null;
  position_id?: string | number | null;
  ts_code?: string | null;
  name?: string | null;
  source_domain?: string | null;
  source_strategy?: string | null;
  trade_date?: string | null;
  entry_time?: string | null;
  entry_price?: number | null;
  shares?: number | null;
  market_value?: number | null;
  unrealized_pnl?: number | null;
  unrealized_pnl_pct?: number | null;
  status?: string | null;
  trade_allowed?: boolean | null;
  block_reason?: string | null;
  block_source?: string | null;
  risk_level?: string | null;
  position_cap_multiplier_final?: number | null;
  related_order_id?: string | number | null;
  related_fill_ids?: Array<string | number> | null;
}

export interface SimFillApiItem {
  id?: string | number | null;
  fill_id?: string | number | null;
  order_id?: string | number | null;
  position_id?: string | number | null;
  ts_code?: string | null;
  name?: string | null;
  source_domain?: string | null;
  source_strategy?: string | null;
  trade_date?: string | null;
  side?: string | null;
  fill_time?: string | null;
  fill_price?: number | null;
  fill_qty?: number | null;
  fill_status?: string | null;
  order_status?: string | null;
  trade_allowed?: boolean | null;
  block_reason?: string | null;
  block_source?: string | null;
  risk_level?: string | null;
  position_cap_multiplier_final?: number | null;
}

async function tryRiskGet<T>(paths: string[], params?: Record<string, string | undefined>): Promise<T> {
  let lastError: unknown;
  for (const path of paths) {
    try {
      const res = await api.get(path, { params });
      return res.data as T;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError;
}

async function tryExecutionGet<T>(
  paths: string[],
  params?: Record<string, string | number | undefined>,
): Promise<T> {
  let lastError: unknown;
  for (const path of paths) {
    try {
      const res = await api.get(path, { params });
      return res.data as T;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError;
}

export async function fetchSimOrders(tradeDate?: string, strategy?: string): Promise<SimOrderApiItem[]> {
  const raw = await tryExecutionGet<unknown>(
    ['/api/sim/orders', '/api/execution/orders', '/api/sim_orders'],
    { trade_date: tradeDate, strategy },
  );
  return toArray<SimOrderApiItem>(raw);
}

export async function fetchSimPositions(tradeDate?: string, strategy?: string): Promise<SimPositionApiItem[]> {
  const raw = await tryExecutionGet<unknown>(
    ['/api/sim/positions', '/api/execution/positions', '/api/sim_positions'],
    { trade_date: tradeDate, strategy },
  );
  return toArray<SimPositionApiItem>(raw);
}

export async function fetchSimFills(tradeDate?: string, strategy?: string): Promise<SimFillApiItem[]> {
  const raw = await tryExecutionGet<unknown>(
    ['/api/sim/fills', '/api/execution/fills', '/api/sim/trades', '/api/execution/trades'],
    { trade_date: tradeDate, strategy },
  );
  return toArray<SimFillApiItem>(raw);
}

export async function fetchExecutionChecks(
  tradeDate?: string,
  strategy?: string,
): Promise<RiskApiItem[]> {
  const raw = await tryExecutionGet<unknown>(
    ['/api/execution/constraints', '/api/sim/constraints', '/api/execution/checks', '/api/sim/checks'],
    { trade_date: tradeDate, strategy },
  );
  return toArray<RiskApiItem>(raw);
}

export async function fetchRiskGateBlocks(tradeDate?: string, scope?: 'all' | 'watchlist' | 'portfolio'): Promise<RiskApiItem[]> {
  const raw = await tryRiskGet<unknown>(
    ['/api/risk/gate_blocks', '/api/risk/gates', '/api/risk/gate-blocks'],
    { trade_date: tradeDate, scope },
  );
  return toArray<RiskApiItem>(raw);
}

export async function fetchRiskTopScores(tradeDate?: string, scope?: 'all' | 'watchlist' | 'portfolio'): Promise<RiskApiItem[]> {
  const raw = await tryRiskGet<unknown>(
    ['/api/risk/top_scores', '/api/risk/top-scores'],
    { trade_date: tradeDate, scope },
  );
  return toArray<RiskApiItem>(raw);
}

export async function fetchRiskDetail(tsCode: string, tradeDate: string): Promise<RiskApiItem | null> {
  const raw = await tryRiskGet<unknown>(
    [`/api/risk/${tsCode}/${tradeDate}`, `/api/risk/detail/${tsCode}/${tradeDate}`],
  );
  if (!raw || typeof raw !== 'object') return null;
  const payload = raw as Record<string, unknown>;
  if (payload.data && typeof payload.data === 'object') return payload.data as unknown as RiskApiItem;
  return payload as unknown as RiskApiItem;
}

export async function getDashboardSummary(tradeDate?: string): Promise<RawDashboardSummaryResponse> {
  const res = await api.get('/api/dashboard/summary', {
    params: tradeDate ? { trade_date: tradeDate } : undefined,
  });
  return (res.data ?? {}) as RawDashboardSummaryResponse;
}

export default api;
