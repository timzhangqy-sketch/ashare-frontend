import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { buildPortfolioContext, loadPortfolioWorkspace } from '../modules/portfolio/adapter';
import { useContextPanel } from '../context/ContextPanelContext';
import type {
  PortfolioActionShellVm,
  PortfolioClosedRowVm,
  PortfolioContextLinkVm,
  PortfolioOpenRowVm,
  PortfolioTabKey,
  PortfolioTransactionRowVm,
} from '../modules/portfolio/types';
import { useDate } from '../context/DateContext';
import { useApiData } from '../hooks/useApiData';
import type { StockContextPanelPayload } from '../types/contextPanel';
import { buildResearchHref } from '../utils/researchHandoff';

type FeedbackTone = 'info' | 'success' | 'warning';

interface FeedbackState {
  tone: FeedbackTone;
  message: string;
}

function normalizeTab(value: string | null): PortfolioTabKey {
  if (value === 'closed' || value === 'transactions') return value;
  return 'open';
}

function normalizeSection(value: string | null): 'open' | 'closed' | null {
  if (value === 'open' || value === 'closed') return value;
  return null;
}

function formatMoney(value: number | null | undefined): string {
  if (value == null) return '--';
  return `${value >= 0 ? '+' : ''}${value.toFixed(2)}`;
}

function formatPercent(value: number | null | undefined): string {
  if (value == null) return '--';
  return `${value >= 0 ? '+' : ''}${(value * 100).toFixed(2)}%`;
}

function buildQueryFlags(searchParams: URLSearchParams, activeTab: PortfolioTabKey): string[] {
  const source = searchParams.get('source');
  const focus = searchParams.get('focus');
  const sourceLabel =
    source === 'dashboard' ? '来自 Dashboard'
    : source === 'signals' ? '来自 Signals'
    : source === 'watchlist' ? '来自观察池'
    : '直接进入';
  const tabLabel =
    activeTab === 'open' ? '当前持仓'
    : activeTab === 'closed' ? '已平仓'
    : '交易流水';

  return [
    `来源：${sourceLabel}`,
    `聚焦：${focus ?? '无'}`,
    `当前页签：${tabLabel}`,
  ];
}

function buildSourceLink(row: PortfolioOpenRowVm | PortfolioClosedRowVm): string | null {
  if (!row.sourceStrategy) return null;
  if (row.sourceStrategy.includes('VOL') || row.sourceStrategy.includes('IGNITE')) {
    return `/dashboard?source=portfolio&focus=${encodeURIComponent(row.tsCode)}&strategy=${encodeURIComponent(row.sourceStrategy)}`;
  }
  if (row.sourceStrategy.includes('RETOC2')) {
    return `/retoc2?source=portfolio&focus=${encodeURIComponent(row.tsCode)}&strategy=${encodeURIComponent(row.sourceStrategy)}`;
  }
  if (row.sourceStrategy.includes('PATTERN')) {
    return `/pattern?source=portfolio&focus=${encodeURIComponent(row.tsCode)}&strategy=${encodeURIComponent(row.sourceStrategy)}`;
  }
  return null;
}

function findOpenRow(rows: PortfolioOpenRowVm[], focus: string | null, portfolioId: string | null): PortfolioOpenRowVm | null {
  if (portfolioId) {
    const byId = rows.find(row => String(row.id) === portfolioId);
    if (byId) return byId;
  }
  if (focus) {
    const byFocus = rows.find(row => row.tsCode === focus || String(row.id) === focus);
    if (byFocus) return byFocus;
  }
  return rows[0] ?? null;
}

function findClosedRow(rows: PortfolioClosedRowVm[], focus: string | null, portfolioId: string | null): PortfolioClosedRowVm | null {
  if (portfolioId) {
    const byId = rows.find(row => String(row.id) === portfolioId);
    if (byId) return byId;
  }
  if (focus) {
    const byFocus = rows.find(row => row.tsCode === focus || String(row.id) === focus);
    if (byFocus) return byFocus;
  }
  return rows[0] ?? null;
}

function buildPortfolioContextPanelPayload(
  row: PortfolioOpenRowVm | PortfolioClosedRowVm,
  context: ReturnType<typeof buildPortfolioContext>,
  activeTab: PortfolioTabKey,
  tradeDate: string,
): StockContextPanelPayload {
  const sourceHref = buildSourceLink(row);
  const watchlistHref = row.fromWatchlist
    ? `/watchlist?source=portfolio&focus=${encodeURIComponent(row.tsCode)}&strategy=${encodeURIComponent(row.sourceStrategy)}`
    : null;
  const transactionHref = `/portfolio?tab=transactions&source=portfolio&focus=${encodeURIComponent(row.tsCode)}&portfolioId=${encodeURIComponent(String(row.id))}&relatedTsCode=${encodeURIComponent(row.tsCode)}&section=${row.status}`;

  const tags = [
    { label: row.statusLabel, tone: 'state' as const },
    { label: row.sourceStrategyLabel, tone: 'strategy' as const },
    { label: row.fromWatchlist ? '来自观察池' : '直接入组合', tone: 'source' as const },
  ];

  if (row.actionLabel) {
    tags.push({ label: row.actionLabel, tone: 'state' as const });
  }

  const summaryItems = [
    { label: '持仓状态', value: row.statusLabel },
    { label: '来源策略', value: row.sourceStrategyLabel },
    { label: '建仓日期', value: row.openDate },
    { label: '持有天数', value: row.holdDays != null ? `${row.holdDays} 天` : '--' },
    { label: '最新盈亏', value: formatMoney(row.todayPnl) },
    { label: row.status === 'closed' ? '已实现收益' : '浮动收益', value: row.status === 'closed' ? formatMoney((row as PortfolioClosedRowVm).realizedPnl) : formatMoney(row.unrealizedPnl) },
    { label: '动作建议', value: row.exitSuggestion },
    { label: '当前信号', value: row.actionLabel },
  ];

  return {
    title: row.name,
    name: row.name,
    tsCode: row.tsCode,
    sourceStrategy: row.sourceStrategy,
    subtitle: row.statusLabel,
    summary: context?.transactionSummary ?? row.exitSuggestion,
    tags,
    summaryItems,
    actions: [
      {
        label: '查看研究',
        href: buildResearchHref({
          source: 'portfolio',
          focus: row.tsCode,
          strategy: row.sourceStrategy,
          tradeDate,
          detailRoute: row.sourceStrategy ? 'backtest' : null,
          detailKey: row.sourceStrategy,
        }),
        note: '围绕当前持仓来源策略继续做研究验证。',
      },
      {
        label: '查看风控',
        href: `/risk?tab=breakdown&source=portfolio&focus=${encodeURIComponent(row.tsCode)}&scope=portfolio`,
        note: '跳转到风控中心查看当前持仓风险。',
      },
      {
        label: '去模拟执行',
        href: `/execution?tab=positions&source=portfolio&focus=${encodeURIComponent(row.tsCode)}${row.sourceStrategy ? `&strategy=${encodeURIComponent(row.sourceStrategy)}` : ''}`,
        note: '继续承接加仓、减仓与平仓相关动作。',
      },
      {
        label: '查看来源策略',
        href: sourceHref ?? undefined,
        disabled: !sourceHref,
        note: sourceHref ? '继续查看来源策略页面。' : '当前没有稳定可跳转的来源页。',
      },
      {
        label: '查看观察池',
        href: watchlistHref ?? undefined,
        disabled: !watchlistHref,
        note: watchlistHref ? '回到观察池查看当前对象。' : '当前记录没有观察池来源。',
      },
      {
        label: '查看交易流水',
        href: transactionHref,
        note: activeTab === 'transactions' ? '当前已经位于交易流水视图。' : '切换到交易流水视图查看关联成交。',
      },
    ],
  };
}

export default function Portfolio() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { selectedDate } = useDate();
  const { openPanel, closePanel } = useContextPanel();
  const activeTab = normalizeTab(searchParams.get('tab'));
  const sourceQuery = searchParams.get('source');
  const focus = searchParams.get('focus');
  const portfolioId = searchParams.get('portfolioId');
  const relatedTsCode = searchParams.get('relatedTsCode');
  const section = normalizeSection(searchParams.get('section'));
  const fallbackRef = useRef<string | null>(null);

  const { data, loading, error, refetch } = useApiData(
    () => loadPortfolioWorkspace(selectedDate),
    [selectedDate],
  );

  const [selectedOpenId, setSelectedOpenId] = useState<number | null>(null);
  const [selectedClosedId, setSelectedClosedId] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<FeedbackState | null>(null);

  const openRows = data?.openRows ?? [];
  const closedRows = data?.closedRows ?? [];

  useEffect(() => {
    if (loading) return;

    const preferredOpen = findOpenRow(openRows, focus, portfolioId);
    const preferredClosed = findClosedRow(closedRows, focus, portfolioId);
    const portfolioIdMiss =
      portfolioId != null
      && !openRows.some(row => String(row.id) === portfolioId)
      && !closedRows.some(row => String(row.id) === portfolioId);

    if (activeTab === 'open') {
      if (preferredOpen) {
        setSelectedOpenId(preferredOpen.id);
        if (portfolioIdMiss && fallbackRef.current !== `open:pid:${portfolioId}`) {
          fallbackRef.current = `open:pid:${portfolioId}`;
          setFeedback({ tone: 'warning', message: `未命中组合记录 ${portfolioId}，已回退到当前持仓首条记录。` });
          return;
        }
        if (focus && preferredOpen.tsCode !== focus && String(preferredOpen.id) !== focus && fallbackRef.current !== `open:${focus}`) {
          fallbackRef.current = `open:${focus}`;
          setFeedback({ tone: 'warning', message: `未命中 ${focus}，已回退到当前持仓首条记录。` });
        }
      } else {
        setSelectedOpenId(null);
      }
    }

    if (activeTab === 'closed') {
      if (preferredClosed) {
        setSelectedClosedId(preferredClosed.id);
        if (portfolioIdMiss && fallbackRef.current !== `closed:pid:${portfolioId}`) {
          fallbackRef.current = `closed:pid:${portfolioId}`;
          setFeedback({ tone: 'warning', message: `未命中组合记录 ${portfolioId}，已回退到已平仓首条记录。` });
          return;
        }
        if (focus && preferredClosed.tsCode !== focus && String(preferredClosed.id) !== focus && fallbackRef.current !== `closed:${focus}`) {
          fallbackRef.current = `closed:${focus}`;
          setFeedback({ tone: 'warning', message: `未命中 ${focus}，已回退到已平仓首条记录。` });
        }
      } else {
        setSelectedClosedId(null);
      }
    }

    if (activeTab === 'transactions') {
      if (portfolioIdMiss && fallbackRef.current !== `transactions:pid:${portfolioId}`) {
        fallbackRef.current = `transactions:pid:${portfolioId}`;
        setFeedback({ tone: 'warning', message: `未命中组合记录 ${portfolioId}，已展示当前可用的交易流水。` });
        return;
      }
      if (focus && !preferredOpen && !preferredClosed && fallbackRef.current !== `transactions:${focus}`) {
        fallbackRef.current = `transactions:${focus}`;
        setFeedback({ tone: 'warning', message: `未命中 ${focus}，已展示当前可用的交易流水。` });
      }
    }
  }, [activeTab, closedRows, focus, loading, openRows, portfolioId]);

  const activeOpenRow = openRows.find(row => row.id === selectedOpenId) ?? findOpenRow(openRows, focus, portfolioId);
  const activeClosedRow = closedRows.find(row => row.id === selectedClosedId) ?? findClosedRow(closedRows, focus, portfolioId);

  const activeRow = useMemo(() => {
    if (activeTab === 'open') return activeOpenRow;
    if (activeTab === 'closed') return activeClosedRow;
    if (section === 'closed') return activeClosedRow;
    if (section === 'open') return activeOpenRow;
    return activeOpenRow ?? activeClosedRow;
  }, [activeClosedRow, activeOpenRow, activeTab, section]);

  const activeContext = useMemo(() => buildPortfolioContext(activeRow ?? null, sourceQuery), [activeRow, sourceQuery]);
  const summary = data?.summary[activeTab];

  const transactionRows = useMemo(() => {
    if (!data) return [];

    const scopedRow =
      (portfolioId ? openRows.find(row => String(row.id) === portfolioId) : null)
      ?? (portfolioId ? closedRows.find(row => String(row.id) === portfolioId) : null)
      ?? activeRow
      ?? null;

    let rows = scopedRow?.relatedTransactions ?? data.transactions.rows;
    if (relatedTsCode) {
      const filtered = rows.filter(row => row.tsCode === relatedTsCode);
      if (filtered.length > 0) rows = filtered;
    }
    return rows;
  }, [activeRow, closedRows, data, openRows, portfolioId, relatedTsCode]);

  const setParams = (mutator: (next: URLSearchParams) => void, replace = true) => {
    const next = new URLSearchParams(searchParams);
    mutator(next);
    setSearchParams(next, { replace });
  };

  const syncTab = (tab: PortfolioTabKey) => {
    setParams(next => {
      if (tab === 'open') next.delete('tab');
      else next.set('tab', tab);
      if (tab !== 'transactions') {
        next.delete('relatedTsCode');
      }
    });
  };

  const selectOpenRow = (row: PortfolioOpenRowVm) => {
    setSelectedOpenId(row.id);
    setParams(next => {
      next.set('focus', row.tsCode);
      next.set('portfolioId', String(row.id));
      next.set('section', 'open');
    });
  };

  const selectClosedRow = (row: PortfolioClosedRowVm) => {
    setSelectedClosedId(row.id);
    setParams(next => {
      next.set('focus', row.tsCode);
      next.set('portfolioId', String(row.id));
      next.set('section', 'closed');
    });
  };

  const selectTransactionRow = (row: PortfolioTransactionRowVm) => {
    setParams(next => {
      next.set('focus', row.tsCode);
      next.set('portfolioId', String(row.portfolioId));
      next.set('relatedTsCode', row.tsCode);
    });
  };

  const handleActionShell = (action: PortfolioActionShellVm) => {
    const subject = activeContext?.title ?? '当前记录';
    const tone: FeedbackTone = action.key === 'add' ? 'info' : 'warning';
    if (!activeRow) return;
    if (activeRow.status === 'closed') {
      setFeedback({
        tone: 'info',
        message: `${subject} 已平仓，${action.label}仅保留状态说明，本轮不开放执行。`,
      });
      return;
    }
    navigate(`/execution?tab=positions&source=portfolio&focus=${encodeURIComponent(activeRow.tsCode)}${activeRow.sourceStrategy ? `&strategy=${encodeURIComponent(activeRow.sourceStrategy)}` : ''}`);
    setFeedback({
      tone,
      message: `${subject}：已跳到模拟执行，继续承接${action.label}相关的仓位、成交与执行约束。`,
    });
  };

  const handleRelatedLink = (link: PortfolioContextLinkVm) => {
    if (!activeRow) return;

    if (link.key === 'source') {
      const href = buildSourceLink(activeRow);
      if (!href) {
        setFeedback({ tone: 'warning', message: `${activeRow.name} 暂无可稳定跳转的来源页，已保留来源策略信息供当前判断使用。` });
        return;
      }
      navigate(href);
      return;
    }

    if (link.key === 'watchlist') {
      if (!activeRow.fromWatchlist) {
        setFeedback({ tone: 'info', message: `${activeRow.name} 当前没有观察池关联记录。` });
        return;
      }
      navigate(`/watchlist?source=portfolio&focus=${encodeURIComponent(activeRow.tsCode)}&strategy=${encodeURIComponent(activeRow.sourceStrategy)}`);
      return;
    }

    setParams(next => {
      next.set('tab', 'transactions');
      next.set('focus', activeRow.tsCode);
      next.set('portfolioId', String(activeRow.id));
      next.set('relatedTsCode', activeRow.tsCode);
      next.set('section', activeRow.status);
    });
    setFeedback({ tone: 'info', message: `${activeRow.name} 的关联交易流水已切换到交易流水页签。` });
  };

  const queryFlags = useMemo(() => buildQueryFlags(searchParams, activeTab), [searchParams, activeTab]);

  useEffect(() => {
    if (!activeRow || !activeContext) {
      closePanel();
      return;
    }

    openPanel({
      entityType: 'stock',
      entityKey: activeRow.tsCode,
      sourcePage: 'portfolio',
      focus: activeRow.tsCode,
      activeTab: activeTab === 'transactions' ? `transactions:${section ?? activeRow.status}` : activeTab,
      payloadVersion: 'v1',
      payload: buildPortfolioContextPanelPayload(activeRow, activeContext, activeTab, selectedDate),
    });
  }, [activeRow, activeContext, activeTab, section, openPanel, closePanel, selectedDate]);

  useEffect(() => () => closePanel(), [closePanel]);

  return (
    <div className="portfolio-page" data-testid="portfolio-page">
      <section className="portfolio-hero card">
        <div>
          <div className="page-title">
            持仓中心
            <span className="page-badge badge-gold">组合工作域</span>
          </div>
          <p className="page-desc">承接当前持仓、退出判断和交易流水，作为组合管理的主工作页。</p>
          <div className="portfolio-flags">
            {queryFlags.map(flag => <span key={flag} className="portfolio-mini-pill">{flag}</span>)}
          </div>
        </div>
        <div className="portfolio-hero-side">
          <div className="portfolio-kicker">交易日</div>
          <div className="portfolio-date">{data?.tradeDate ?? selectedDate}</div>
          <div className="portfolio-sub">{data?.generatedAtText ?? '正在整理组合工作域数据。'}</div>
        </div>
      </section>

      {activeContext ? (
        <section className="card" style={{ padding: '12px 16px' }}>
          <div className="portfolio-context-link-list">
            <button
              type="button"
              className="portfolio-context-link"
              onClick={() => navigate(buildResearchHref({
                source: 'portfolio',
                focus: activeContext.code,
                strategy: activeRow?.sourceStrategy ?? activeContext.sourceStrategyLabel,
                tradeDate: selectedDate,
                detailRoute: activeRow?.sourceStrategy ? 'backtest' : null,
                detailKey: activeRow?.sourceStrategy ?? null,
              }))}
            >
              <span>查看研究</span>
              <span className="portfolio-inline-meta">围绕当前持仓来源策略继续做研究验证。</span>
            </button>
            <button
              type="button"
              className="portfolio-context-link"
              onClick={() => navigate(`/execution?tab=positions&source=portfolio&focus=${encodeURIComponent(activeContext.code)}${activeRow?.sourceStrategy ? `&strategy=${encodeURIComponent(activeRow.sourceStrategy)}` : ''}`)}
            >
              <span>去模拟执行</span>
              <span className="portfolio-inline-meta">围绕当前持仓跳到模拟执行，继续查看仓位、成交与执行约束。</span>
            </button>
          </div>
        </section>
      ) : null}

      {feedback ? (
        <section className={`card portfolio-feedback portfolio-feedback-${feedback.tone}`}>
          <div className="portfolio-feedback-text">{feedback.message}</div>
          <button type="button" className="portfolio-feedback-close" onClick={() => setFeedback(null)}>知道了</button>
        </section>
      ) : null}

      <section className="card">
        <div className="card-header">
          <span className="card-title">{summary?.title ?? '组合概览'}</span>
          <span className="c-muted portfolio-card-desc">{summary?.description ?? '查看当前组合状态与退出关注。'}</span>
        </div>
        <div className="portfolio-summary-strip">
          {(summary?.metrics ?? []).map(metric => (
            <div key={metric.label} className="stat-card portfolio-summary-card">
              <div className="stat-label">{metric.label}</div>
              <div className="stat-value portfolio-summary-value">{metric.value}</div>
              <div className="stat-sub">{metric.helper}</div>
            </div>
          ))}
        </div>
      </section>

      <div className="page-tabs portfolio-tabs">
        {(['open', 'closed', 'transactions'] as PortfolioTabKey[]).map(tab => (
          <button
            key={tab}
            className={`page-tab-btn${activeTab === tab ? ' active' : ''}`}
            onClick={() => syncTab(tab)}
            type="button"
          >
            {data?.tabs[tab].label ?? tab}
          </button>
        ))}
      </div>

      <div className="portfolio-layout">
        <div className="portfolio-main">
          <section className="card">
            <div className="card-header">
              <span className="card-title">{data?.tabs[activeTab].title ?? '持仓中心'}</span>
              <span className="c-muted portfolio-card-desc">
                {data?.tabs[activeTab].description ?? '查看组合相关数据。'}
              </span>
            </div>

            {loading ? (
              <div className="portfolio-loading-state">
                <div className="spinner" />
                <span>正在加载持仓中心...</span>
              </div>
            ) : null}

            {!loading && error ? (
              <div className="page-error">
                <div className="page-error-msg">持仓中心加载失败</div>
                <div className="page-error-detail">{error}</div>
                <button className="retry-btn" onClick={refetch}>重新加载</button>
              </div>
            ) : null}

            {!loading && !error && activeTab === 'open' ? (
              <div className="portfolio-table-shell">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>股票</th>
                      <th>来源策略</th>
                      <th className="center">建仓日期</th>
                      <th className="right">持仓天数</th>
                      <th className="right">最新价</th>
                      <th className="right">今日盈亏</th>
                      <th className="right">浮动盈亏</th>
                      <th className="center">操作建议</th>
                    </tr>
                  </thead>
                  <tbody>
                    {openRows.length === 0 ? (
                      <tr className="portfolio-table-empty-row">
                        <td colSpan={8}>
                          <div className="portfolio-empty-state">
                            <div className="portfolio-empty-title">{data?.tabs.open.emptyTitle}</div>
                            <div className="portfolio-empty-text">{data?.tabs.open.emptyText}</div>
                          </div>
                        </td>
                      </tr>
                    ) : openRows.map(row => (
                      <tr
                        key={row.id}
                        className={activeOpenRow?.id === row.id ? 'portfolio-table-row selected' : 'portfolio-table-row'}
                        onClick={() => selectOpenRow(row)}
                      >
                        <td>
                          <div className="portfolio-cell-title">{row.name}</div>
                          <div className="portfolio-inline-meta">{row.tsCode}</div>
                        </td>
                        <td>
                          <div>{row.sourceStrategyLabel}</div>
                          <div className="portfolio-inline-meta">{row.sourceHint}</div>
                        </td>
                        <td className="center">{row.openDate}</td>
                        <td className="right">{row.holdDays ?? '--'}</td>
                        <td className="right">{row.latestClose?.toFixed(2) ?? '--'}</td>
                        <td className="right">{formatMoney(row.todayPnl)}</td>
                        <td className="right">
                          <div>{formatMoney(row.unrealizedPnl)}</div>
                          <div className="portfolio-inline-meta">{formatPercent(row.unrealizedPnlPct)}</div>
                        </td>
                        <td className="center">
                          <span className={`portfolio-signal-badge ${row.rawActionSignal && row.rawActionSignal !== 'HOLD' ? 'warning' : ''}`}>
                            {row.actionLabel}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : null}

            {!loading && !error && activeTab === 'closed' ? (
              <div className="portfolio-table-shell">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>股票</th>
                      <th>来源策略</th>
                      <th className="center">建仓日期</th>
                      <th className="center">平仓日期</th>
                      <th className="right">持仓天数</th>
                      <th className="right">已实现盈亏</th>
                      <th>平仓原因</th>
                    </tr>
                  </thead>
                  <tbody>
                    {closedRows.length === 0 ? (
                      <tr className="portfolio-table-empty-row">
                        <td colSpan={7}>
                          <div className="portfolio-empty-state">
                            <div className="portfolio-empty-title">{data?.tabs.closed.emptyTitle}</div>
                            <div className="portfolio-empty-text">{data?.tabs.closed.emptyText}</div>
                          </div>
                        </td>
                      </tr>
                    ) : closedRows.map(row => (
                      <tr
                        key={row.id}
                        className={activeClosedRow?.id === row.id ? 'portfolio-table-row selected' : 'portfolio-table-row'}
                        onClick={() => selectClosedRow(row)}
                      >
                        <td>
                          <div className="portfolio-cell-title">{row.name}</div>
                          <div className="portfolio-inline-meta">{row.tsCode}</div>
                        </td>
                        <td>
                          <div>{row.sourceStrategyLabel}</div>
                          <div className="portfolio-inline-meta">{row.sourceHint}</div>
                        </td>
                        <td className="center">{row.openDate}</td>
                        <td className="center">{row.closeDate ?? '--'}</td>
                        <td className="right">{row.holdDays ?? '--'}</td>
                        <td className="right">
                          <div>{formatMoney(row.realizedPnl)}</div>
                          <div className="portfolio-inline-meta">{formatPercent(row.realizedPnlPct)}</div>
                        </td>
                        <td>{row.exitReason}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : null}

            {!loading && !error && activeTab === 'transactions' ? (
              <div className="portfolio-table-shell">
                <div className="portfolio-transactions-intro">{data?.transactions.relatedLabel}</div>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>日期</th>
                      <th>股票</th>
                      <th>类型</th>
                      <th className="right">价格</th>
                      <th className="right">数量</th>
                      <th className="right">金额</th>
                      <th>触发来源</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactionRows.length === 0 ? (
                      <tr className="portfolio-table-empty-row">
                        <td colSpan={7}>
                          <div className="portfolio-empty-state">
                            <div className="portfolio-empty-title">{data?.transactions.emptyTitle}</div>
                            <div className="portfolio-empty-text">{data?.transactions.emptyText}</div>
                          </div>
                        </td>
                      </tr>
                    ) : transactionRows.map(row => {
                      const isSelected =
                        (portfolioId && String(row.portfolioId) === portfolioId)
                        || (relatedTsCode && row.tsCode === relatedTsCode);
                      return (
                        <tr key={row.id} className={isSelected ? 'portfolio-table-row selected' : 'portfolio-table-row'} onClick={() => selectTransactionRow(row)}>
                          <td>{row.tradeDate}</td>
                          <td>
                            <div className="portfolio-cell-title">{row.tsCode}</div>
                            <div className="portfolio-inline-meta">组合记录 #{row.portfolioId}</div>
                          </td>
                          <td>{row.tradeTypeLabel}</td>
                          <td className="right">{row.price.toFixed(2)}</td>
                          <td className="right">{row.shares}</td>
                          <td className="right">{row.amount.toFixed(2)}</td>
                          <td>
                            <div>{row.triggerSourceLabel}</div>
                            <div className="portfolio-inline-meta">{row.notes ?? '无附加说明'}</div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : null}
          </section>
        </div>

        <aside className="portfolio-context">
          <section className="card portfolio-context-card">
            <div className="card-header">
              <span className="card-title">当前工作上下文</span>
              <span className="c-muted portfolio-card-desc">
                {activeContext ? '围绕当前选中记录查看来源、持仓与退出判断。' : '选中一条记录后，这里会同步展示组合上下文。'}
              </span>
            </div>
            <div className="portfolio-context-body">
              {activeContext ? (
                <>
                  <div className="portfolio-context-title">{activeContext.title}</div>
                  <div className="portfolio-context-code">{activeContext.code}</div>
                  <div className="portfolio-context-status">{activeContext.statusLabel}</div>

                  <div className="portfolio-context-section">
                    <div className="portfolio-context-grid">
                      <div>
                        <div className="portfolio-context-label">来源策略</div>
                        <div className="portfolio-context-value">{activeContext.sourceStrategyLabel}</div>
                      </div>
                      <div>
                        <div className="portfolio-context-label">来源观察池</div>
                        <div className="portfolio-context-value">{activeContext.sourceHint}</div>
                      </div>
                      <div>
                        <div className="portfolio-context-label">{activeContext.sourceQueryLabel}</div>
                        <div className="portfolio-context-value">{activeContext.sourceQueryValue}</div>
                      </div>
                    </div>
                  </div>

                  <div className="portfolio-context-section">
                    <div className="portfolio-context-section-title">持仓信息</div>
                    <div className="portfolio-context-grid">
                      {activeContext.holdingFacts.map(item => (
                        <div key={item.label}>
                          <div className="portfolio-context-label">{item.label}</div>
                          <div className="portfolio-context-value">{item.value}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="portfolio-context-section">
                    <div className="portfolio-context-section-title">退出判断</div>
                    <div className="portfolio-context-list">
                      {activeContext.judgementFacts.map(item => (
                        <div key={item.label} className="portfolio-context-list-row">
                          <span className="portfolio-context-label">{item.label}</span>
                          <span className="portfolio-context-list-value">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="portfolio-context-section">
                    <div className="portfolio-context-section-title">关联入口</div>
                    <div className="portfolio-context-link-list">
                      {activeContext.relatedLinks.map(link => (
                        <button
                          key={link.key}
                          type="button"
                          className={`portfolio-context-link${link.enabled ? '' : ' is-disabled'}`}
                          onClick={() => handleRelatedLink(link)}
                        >
                          <span>{link.label}</span>
                          <span className="portfolio-inline-meta">{link.note}</span>
                        </button>
                      ))}
                      <button
                        type="button"
                        className="portfolio-context-link"
                        onClick={() => navigate(`/risk?tab=breakdown&source=portfolio&focus=${encodeURIComponent(activeContext.code)}&scope=portfolio`)}
                      >
                        <span>查看风控</span>
                        <span className="portfolio-inline-meta">跳到风控中心，查看当前持仓的闸门、评分与拆解</span>
                      </button>
                    </div>
                  </div>

                  <div className="portfolio-context-section">
                    <div className="portfolio-context-section-title">轻动作入口</div>
                    <div className="portfolio-action-shells">
                      {activeContext.actionShells.map(action => (
                        <button
                          key={action.key}
                          type="button"
                          className={`portfolio-action-shell ${action.tone}${action.enabled ? '' : ' is-disabled'}`}
                          onClick={() => handleActionShell(action)}
                        >
                          <span>{action.label}</span>
                          <span className="portfolio-inline-meta">{action.note}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="portfolio-context-section">
                    <div className="portfolio-context-section-title">交易流水</div>
                    <div className="portfolio-context-empty">{activeContext.transactionSummary}</div>
                  </div>
                </>
              ) : (
                <div className="portfolio-context-empty">
                  选中一条持仓、平仓或交易流水记录后，这里会展示组合来源、持仓信息、退出判断和轻动作入口。
                </div>
              )}
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
}
