import { useMemo } from 'react';
import { getMockDetail } from '../utils/score';
import { useApiData } from '../hooks/useApiData';
import { fetchWatchlist, type WatchlistItem } from '../api';
import type { StockDetail } from '../types/stock';
import { CrossTags } from './CrossTags';

const SIGNAL_CFG: Record<string, { color: string; bg: string; border: string }> = {
  PULLBACK:  { color: '#00B96B', bg: 'rgba(0,185,107,.25)',  border: 'rgba(0,185,107,.5)'  },
  REHEAT:    { color: '#f5a623', bg: 'rgba(245,166,35,.25)', border: 'rgba(245,166,35,.5)' },
  BREAKOUT:  { color: '#4fa3ff', bg: 'rgba(64,150,255,.25)', border: 'rgba(64,150,255,.5)' },
  VOL_BREAK: { color: '#36cfc9', bg: 'rgba(54,207,201,.25)', border: 'rgba(54,207,201,.5)' },
  SELL:      { color: '#FF4D4F', bg: 'rgba(255,77,79,.22)',  border: 'rgba(255,77,79,.45)' },
};
const DEFAULT_SIG = { color: '#94A3B8', bg: 'rgba(148,163,184,.15)', border: 'rgba(148,163,184,.3)' };

function SignalBadge({ label }: { label: string | null }) {
  if (!label) return <span className="c-muted">—</span>;
  const cfg = SIGNAL_CFG[label] ?? DEFAULT_SIG;
  return (
    <span style={{
      fontSize: 11, fontWeight: 600, padding: '2px 9px', borderRadius: 10,
      background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.border}`,
    }}>
      {label}
    </span>
  );
}

function PctCell({ v, isDecimal = false }: { v: number; isDecimal?: boolean }) {
  const n     = isDecimal ? (v ?? 0) * 100 : (v ?? 0);
  const color = n > 0 ? 'var(--red)' : n < 0 ? 'var(--green)' : 'var(--text-muted)';
  return (
    <td className="right" style={{ color, fontWeight: 600 }}>
      {n > 0 ? '+' : ''}{n.toFixed(2)}%
    </td>
  );
}

interface Props {
  strategy: string | string[];
  onOpen:   (s: StockDetail) => void;
  onBuy?:   (s: StockDetail) => void;
}

function makeDetail(s: WatchlistItem): StockDetail {
  return getMockDetail(s.ts_code, s.name, [s.strategy], 0, s.latest_pct_chg);
}

export default function WatchlistTab({ strategy, onOpen, onBuy }: Props) {
  const { data, loading, error, refetch } = useApiData(
    () => fetchWatchlist(),
    [],
  );

  const allItems = data ?? [];

  const items = useMemo(() => {
    if (!allItems.length) return [];
    if (Array.isArray(strategy)) {
      return allItems.filter(s => strategy.includes(s.strategy));
    }
    return allItems.filter(s => s.strategy === strategy);
  }, [allItems, strategy]);

  const buyCount  = items.filter(s => s.buy_signal).length;
  const sellCount = items.filter(s => s.sell_signal).length;

  return (
    <div>
      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">本策略在池数量</div>
          <div className={`stat-value c-cyan${loading ? ' loading' : ''}`}>
            {loading ? '—' : items.length}
          </div>
          <div className="stat-sub">累计入池未退出</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">今日有买点信号</div>
          <div className={`stat-value c-red${loading ? ' loading' : ''}`}>
            {loading ? '—' : buyCount}
          </div>
          <div className="stat-sub">可关注操作</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">有卖出信号</div>
          <div className={`stat-value c-green${loading ? ' loading' : ''}`}>
            {loading ? '—' : sellCount}
          </div>
          <div className="stat-sub">注意风控</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">数据来源</div>
          <div className="stat-value" style={{ fontSize: 14, color: 'var(--text-muted)', paddingTop: 4 }}>
            ashare_watchlist
          </div>
          <div className="stat-sub">GET /api/watchlist</div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <span className="card-title">持续观察池</span>
          <span className="c-muted" style={{ fontSize: 12 }}>点击行查看详情 · 点击买入直接开仓</span>
        </div>

        {loading && <div className="page-loading"><div className="spinner" />加载中…</div>}
        {!loading && error && (
          <div className="page-error">
            <div className="page-error-msg">数据加载失败</div>
            <div className="page-error-detail">{error}</div>
            <button className="retry-btn" onClick={refetch}>重试</button>
          </div>
        )}
        {!loading && !error && items.length === 0 && (
          <div className="empty-state">
            <div className="empty-icon">📭</div>
            <div className="empty-text">暂无观察标的</div>
          </div>
        )}
        {!loading && !error && items.length > 0 && (
          <table className="data-table">
            <thead>
              <tr>
                <th>代码</th>
                <th>名称</th>
                <th>策略</th>
                <th className="center">入池日期</th>
                <th className="right">在池天数</th>
                <th className="right">最新涨幅</th>
                <th className="right">累计涨幅</th>
                <th className="center">买点信号</th>
                <th className="center">卖出信号</th>
                <th className="center">操作</th>
              </tr>
            </thead>
            <tbody>
              {items.map((s: WatchlistItem) => {
                const detail = makeDetail(s);
                return (
                  <tr key={`${s.ts_code}-${s.strategy}`} onClick={() => onOpen(detail)}>
                    <td className="c-sec">{s.ts_code}</td>
                    <td style={{ fontWeight: 500 }}>
                      {s.name}<CrossTags tsCode={s.ts_code} currentStrategy={s.strategy} />
                    </td>
                    <td>
                      <span style={{
                        fontSize: 11, color: 'var(--text-secondary)',
                        background: 'var(--bg-item)', borderRadius: 4, padding: '2px 8px',
                        border: '1px solid var(--bg-item-border)',
                      }}>
                        {s.strategy}
                      </span>
                    </td>
                    <td className="center" style={{ fontSize: 12, color: '#94A3B8' }}>{s.entry_date}</td>
                    <td className="right">
                      <span style={{ color: s.pool_day >= 5 ? 'var(--gold)' : '#F1F5F9', fontWeight: 600 }}>
                        {s.pool_day} 天
                      </span>
                    </td>
                    {/* latest_pct_chg is already in % (e.g. 1.5988 = 1.60%) */}
                    <PctCell v={s.latest_pct_chg} />
                    {/* gain_since_entry is a decimal (e.g. 0.0534 = 5.34%) */}
                    <PctCell v={s.gain_since_entry} isDecimal />
                    <td className="center"><SignalBadge label={s.buy_signal} /></td>
                    <td className="center"><SignalBadge label={s.sell_signal} /></td>
                    <td className="center" onClick={e => e.stopPropagation()}>
                      <button
                        onClick={() => (onBuy ?? onOpen)(detail)}
                        style={{
                          background: '#FF4D4F', border: '1px solid rgba(255,77,79,.6)',
                          borderRadius: 4, color: '#fff', fontSize: 11, fontWeight: 700,
                          padding: '2px 10px', cursor: 'pointer', lineHeight: 1.6,
                        }}
                      >
                        买入
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
