import { createContext, useContext, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type { StatusTone } from '../types/dashboard';

export interface DashboardRuntimeSnapshot {
  source: 'mock' | 'real';
  tradeDate: string;
  generatedAt: string;
  systemStatusLabel: string;
  systemTone: StatusTone;
  versionText: string;
}

interface DashboardRuntimeContextValue {
  snapshot: DashboardRuntimeSnapshot | null;
  setSnapshot: (snapshot: DashboardRuntimeSnapshot | null) => void;
}

const DashboardRuntimeContext = createContext<DashboardRuntimeContextValue | null>(null);

export function DashboardRuntimeProvider({ children }: { children: ReactNode }) {
  const [snapshot, setSnapshot] = useState<DashboardRuntimeSnapshot | null>(null);

  const value = useMemo(
    () => ({ snapshot, setSnapshot }),
    [snapshot],
  );

  return (
    <DashboardRuntimeContext.Provider value={value}>
      {children}
    </DashboardRuntimeContext.Provider>
  );
}

export function useDashboardRuntime() {
  const context = useContext(DashboardRuntimeContext);
  if (!context) {
    throw new Error('useDashboardRuntime must be used within <DashboardRuntimeProvider>');
  }
  return context;
}
