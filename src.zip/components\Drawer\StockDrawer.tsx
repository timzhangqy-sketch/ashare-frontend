import { useEffect, useState } from 'react';
import type { StockDetail } from '../../types/stock';
import { addPortfolio, fetchStockDetail, fetchAIAnalysis, type StockDetailResp, type AIAnalysisResp, type FinancialYear } from '../../api';
import { useDate } from '../../context/DateContext';
import KlineChart from './KlineChart';
import { MultiStrategyBadge } from '../CrossTags';

const CloseIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
    strokeLinecap="round" strokeLinejoin="round" width="15" height="15">
    <line x1="18" y1="6" x2="6"  y2="18"/>
    <line x1="6"  y1="6" x2="18" y2="18"/>
  </svg>
);

/* ── Deterministic seed from stock code ── */
function seed(code: string, offset = 0): number {
  let h = offset * 7919;
  for (const c of code) h = ((h << 5) - h + c.charCodeAt(0)) & 0x7fffffff;
  return Math.abs(h);
}

/* ── Mock data generators ── */
function getRiskData(code: string) {
  const s = seed(code);
  const pledgePct = (s % 40) + 8;
  const hasRisk   = s % 7 === 0;
  const hasInvest = s % 11 === 0;
  const riskLevel = (hasRisk || hasInvest || pledgePct > 40)
    ? 'high' : s % 4 === 0 ? 'mid' : 'low';
  return {
    stRisk:        hasRisk   ? 'ST预警' : '正常',
    investigation: hasInvest ? '立案中'  : '无',
    pledgeRatio:   `${pledgePct}%`,
    auditOpinion:  s % 6 === 0 ? '保留意见' : '标准无保留',
    riskLevel:     riskLevel as 'low' | 'mid' | 'high',
  };
}

const BULL_POOL = [
  '量能持续放大，资金持续净流入',
  'MA5上穿MA10，短期趋势向好',
  '换手率处于健康活跃区间（10%~25%）',
  'RS强度指数持续领先沪深300',
  '20日均线多头排列，趋势上行',
  '板块轮动资金关注度显著提升',
];
const BEAR_POOL = [
  '大盘短期承压，注意系统性风险',
  '高位出现量价背离信号',
  '短期获利盘积压较重',
  'MACD顶背离信号已出现',
];

function getAIData(code: string): AIAnalysisResp {
  const s      = seed(code);
  const bullCnt = 2 + (s % 3);
  const bearCnt = 1 + (s % 2);
  const advIdx  = s % 5 === 0 ? 2 : s % 3 === 0 ? 0 : 1;
  return {
    bull_factors: Array.from({ length: bullCnt }, (_, i) => BULL_POOL[(s + i) % BULL_POOL.length]),
    bear_factors: Array.from({ length: bearCnt }, (_, i) => BEAR_POOL[(s + i) % BEAR_POOL.length]),
    advice:       ['买入', '持有', '卖出'][advIdx] as '买入' | '持有' | '卖出',
    confidence:   58 + (s % 37),
    stop_loss:    `${4 + (s % 8)}.${s % 10}`,
    target:       `${8 + (s % 12)}.${(s + 3) % 10}`,
  };
}

/* ── Config ── */
const RISK_CFG = {
  low:  { label: '低风险', color: '#00B96B', bg: 'rgba(0,185,107,.15)',   border: 'rgba(0,185,107,.35)'   },
  mid:  { label: '中风险', color: '#f5a623', bg: 'rgba(245,166,35,.15)',  border: 'rgba(245,166,35,.35)'  },
  high: { label: '高风险', color: '#FF4D4F', bg: 'rgba(255,77,79,.15)',   border: 'rgba(255,77,79,.35)'   },
};

const ADVICE_CFG = {
  买入: { color: '#FF4D4F', bg: 'rgba(255,77,79,.22)',  border: 'rgba(255,77,79,.45)'  },
  持有: { color: '#f5a623', bg: 'rgba(245,166,35,.22)', border: 'rgba(245,166,35,.45)' },
  卖出: { color: '#00B96B', bg: 'rgba(0,185,107,.22)',  border: 'rgba(0,185,107,.45)'  },
};

/* ── Sub-components ── */

function ConfidenceBar({ value }: { value: number }) {
  const color = value >= 80 ? '#00B96B' : value >= 60 ? '#f5a623' : '#FF4D4F';
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: 12 }}>
        <span style={{ color: 'var(--text-secondary)' }}>AI 信心评分</span>
        <span style={{ color, fontWeight: 700 }}>{value} / 100</span>
      </div>
      <div style={{ height: 4, background: 'var(--border)', borderRadius: 3 }}>
        <div style={{
          width: `${value}%`, height: '100%', background: color,
          borderRadius: 3, boxShadow: `0 0 6px ${color}50`,
          transition: 'width 0.55s cubic-bezier(0.4,0,0.2,1)',
        }} />
      </div>
    </div>
  );
}

/* Flat grid item — label above, value below, no box border */
function GridItem({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 3, lineHeight: 1 }}>{label}</div>
      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', lineHeight: 1.3 }}>{children}</div>
    </div>
  );
}

/* Flat vol-price item — label + larger value, no box border */
function VPItem({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div>
      <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 3, lineHeight: 1 }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 700, fontVariantNumeric: 'tabular-nums',
        color: color ?? 'var(--text-primary)', lineHeight: 1.3 }}>
        {value}
      </div>
    </div>
  );
}

/* ── Props ── */
interface Props {
  stock:             StockDetail | null;
  onClose:           () => void;
  autoOpenBuyForm?:  boolean;
}

/* ── VR → stars helper ── */
function vrToStars(vr: number): number {
  if (vr >= 3)   return 5;
  if (vr >= 2)   return 4;
  if (vr >= 1.5) return 3;
  if (vr >= 1.2) return 2;
  return 1;
}

/* ── Signal badge (buy/sell) ── */
const SIG_COLOR: Record<string, { color: string; bg: string; border: string }> = {
  PULLBACK:    { color: '#00B96B', bg: 'rgba(0,185,107,.22)',  border: 'rgba(0,185,107,.45)'  },
  REHEAT:      { color: '#f5a623', bg: 'rgba(245,166,35,.22)', border: 'rgba(245,166,35,.45)' },
  BREAKOUT:    { color: '#4fa3ff', bg: 'rgba(64,150,255,.22)', border: 'rgba(64,150,255,.45)' },
  VOL_BREAK:   { color: '#36cfc9', bg: 'rgba(54,207,201,.22)', border: 'rgba(54,207,201,.45)' },
  VOL_CONFIRM: { color: '#36cfc9', bg: 'rgba(54,207,201,.22)', border: 'rgba(54,207,201,.45)' },
  SELL:        { color: '#FF4D4F', bg: 'rgba(255,77,79,.22)',  border: 'rgba(255,77,79,.45)'  },
};
const SIG_DEFAULT = { color: '#94A3B8', bg: 'rgba(148,163,184,.15)', border: 'rgba(148,163,184,.3)' };

function SignalChip({ label }: { label: string | null | undefined }) {
  if (!label) return <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>无</span>;
  const cfg = SIG_COLOR[label] ?? SIG_DEFAULT;
  return (
    <span style={{
      fontSize: 11, fontWeight: 600, padding: '2px 9px', borderRadius: 10,
      background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.border}`,
    }}>{label}</span>
  );
}

export default function StockDrawer({ stock, onClose, autoOpenBuyForm = false }: Props) {
  const { selectedDate } = useDate();
  const open = !!stock;

  /* ── Real API detail ── */
  const [detail,        setDetail]        = useState<StockDetailResp | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  useEffect(() => {
    if (!stock) { setDetail(null); return; }
    let cancelled = false;
    setDetailLoading(true);
    setDetail(null);
    fetchStockDetail(stock.code, selectedDate)
      .then(d  => { if (!cancelled) { setDetail(d); setDetailLoading(false); } })
      .catch(() => { if (!cancelled) setDetailLoading(false); });
    return () => { cancelled = true; };
  }, [stock?.code, selectedDate]); // eslint-disable-line react-hooks/exhaustive-deps

  /* ── AI analysis ── */
  const [aiData,    setAiData]    = useState<AIAnalysisResp | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    if (!stock) { setAiData(null); return; }
    let cancelled = false;
    setAiLoading(true);
    setAiData(null);
    fetchAIAnalysis(stock.code, selectedDate)
      .then(d  => { if (!cancelled) { setAiData(d.error ? null : d); setAiLoading(false); } })
      .catch(() => { if (!cancelled) setAiLoading(false); });
    return () => { cancelled = true; };
  }, [stock?.code, selectedDate]); // eslint-disable-line react-hooks/exhaustive-deps

  /* ── Buy form state ── */
  const [showBuyForm, setShowBuyForm] = useState(false);
  const [buyPrice,    setBuyPrice]    = useState('');
  const [buyShares,   setBuyShares]   = useState('100');
  const [buyDate,     setBuyDate]     = useState(() => new Date().toISOString().split('T')[0]);
  const [buying,      setBuying]      = useState(false);
  const [buySuccess,  setBuySuccess]  = useState(false);
  const [buyError,    setBuyError]    = useState('');

  useEffect(() => {
    setShowBuyForm(autoOpenBuyForm);
    setBuySuccess(false);
    setBuyError('');
    setBuyPrice(stock ? (stock.close ?? 0).toFixed(2) : '');
    setBuyShares('100');
    setBuyDate(new Date().toISOString().split('T')[0]);
  }, [stock?.code, autoOpenBuyForm]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (detail?.close != null) {
      setBuyPrice(prev => {
        const stockClose = (stock?.close ?? 0).toFixed(2);
        return prev === stockClose || prev === '' ? detail.close!.toFixed(2) : prev;
      });
    }
  }, [detail?.close]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, onClose]);

  const buyAmount = (parseFloat(buyPrice) || 0) * (parseInt(buyShares) || 0);

  async function handleBuy() {
    if (!stock) return;
    const price  = parseFloat(buyPrice);
    const shares = parseInt(buyShares);
    if (isNaN(price) || price <= 0 || isNaN(shares) || shares <= 0) {
      setBuyError('请填写有效的价格和数量');
      return;
    }
    setBuying(true);
    setBuyError('');
    try {
      await addPortfolio({
        ts_code:         stock.code,
        name:            stock.name,
        open_price:      price,
        shares,
        open_date:       buyDate,
        source_strategy: stock.lists[0] ?? '手动录入',
      });
      setShowBuyForm(false);
      setBuySuccess(true);
      setTimeout(() => setBuySuccess(false), 3000);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : '提交失败，请重试';
      setBuyError(msg);
    } finally {
      setBuying(false);
    }
  }

  /* Derived data */
  const risk      = stock ? getRiskData(stock.code)  : null;
  const mockAi    = stock ? getAIData(stock.code)    : null;
  const ai        = aiData ?? mockAi;
  const riskCfg   = risk ? RISK_CFG[risk.riskLevel] : null;
  const adviceCfg = ai   ? ADVICE_CFG[ai.advice]    : null;

  const realClose  = detail?.close   ?? stock?.close     ?? 0;
  const changePct  = detail?.pct_chg ?? stock?.changePct ?? 0;
  const pctColor   = changePct > 0 ? '#FF4D4F' : changePct < 0 ? '#00B96B' : '#94A3B8';

  const realMa5      = detail?.ma5           ?? null;
  const realMa10     = detail?.ma10          ?? null;
  const realMa20     = detail?.ma20          ?? null;
  const realVr       = detail?.vr            ?? null;
  const realTurnover = detail?.turnover_rate ?? null;
  const realAmount   = detail?.amount_yi     ?? null;

  const inWatchlist  = detail?.in_watchlist ?? false;
  const aboveMa20    = detail?.above_ma20_days ?? 0;
  const ma20Status   = aboveMa20 > 0 ? `站上MA20 ${aboveMa20}天` : '运行于MA20下方';

  return (
    <>
      <div className={`drawer-overlay${open ? ' open' : ''}`} onClick={onClose} />
      <div className={`drawer${open ? ' open' : ''}`}>
        {stock && risk && ai && riskCfg && adviceCfg && (
          <div key={stock.code} style={{ display: 'flex', flexDirection: 'column', minHeight: '100%' }}>

            {/* ── Success toast ── */}
            {buySuccess && (
              <div style={{
                position: 'sticky', top: 0, zIndex: 10,
                background: 'rgba(0,185,107,.15)', border: '1px solid rgba(0,185,107,.4)',
                color: '#00B96B', padding: '10px 20px', fontSize: 13, fontWeight: 600,
                display: 'flex', alignItems: 'center', gap: 8,
                animation: 'toast-in 0.2s ease',
              }}>
                ✅ 已加入持仓
              </div>
            )}

            {/* ── Header ── */}
            <div className="drawer-header">
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 19, fontWeight: 700, color: 'var(--text-primary)' }}>
                  {stock.name}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 5, flexWrap: 'wrap' }}>
                  <span style={{ fontSize: 12, color: 'var(--text-muted)', fontVariantNumeric: 'tabular-nums' }}>
                    {stock.code}
                  </span>
                  {stock.lists.map(l => (
                    <span key={l} style={{
                      fontSize: 10, fontWeight: 600, padding: '1px 7px', borderRadius: 10,
                      background: 'rgba(255,77,79,.22)', color: '#FF4D4F',
                      border: '1px solid rgba(255,77,79,.4)',
                    }}>
                      {l}
                    </span>
                  ))}
                  <MultiStrategyBadge tsCode={stock.code} />
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, flexShrink: 0 }}>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 21, fontWeight: 700, fontVariantNumeric: 'tabular-nums',
                    lineHeight: 1.2, color: 'var(--text-primary)' }}>
                    {detailLoading ? '—' : realClose.toFixed(2)}
                  </div>
                  <div style={{ color: pctColor, fontSize: 13, marginTop: 2, fontWeight: 600 }}>
                    {detailLoading ? '—' : `${changePct > 0 ? '+' : ''}${changePct.toFixed(2)}%`}
                  </div>
                </div>
                <button
                  onClick={() => { setShowBuyForm(b => !b); setBuySuccess(false); setBuyError(''); }}
                  style={{
                    background: showBuyForm ? 'rgba(255,77,79,.3)' : '#FF4D4F',
                    border: '1px solid rgba(255,77,79,.6)',
                    borderRadius: 6, color: '#fff', fontSize: 13, fontWeight: 700,
                    padding: '5px 14px', cursor: 'pointer', transition: 'all 0.12s',
                    flexShrink: 0, marginTop: 2,
                  }}
                >
                  {showBuyForm ? '收起' : '买入'}
                </button>
                <button className="drawer-close-btn" onClick={onClose} title="关闭 (Esc)">
                  <CloseIcon />
                </button>
              </div>
            </div>

            {/* ── Buy form ── */}
            {showBuyForm && (
              <div style={{
                padding: '14px 20px',
                background: 'var(--buy-form-bg)',
                borderBottom: '1px solid var(--border)',
              }}>
                <div className="drawer-section-title" style={{ marginBottom: 12 }}>💰 买入操作</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">买入价格（元）</label>
                    <input className="form-input" type="number" step="0.01" min="0"
                      value={buyPrice} onChange={e => setBuyPrice(e.target.value)} />
                  </div>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">买入数量（股）</label>
                    <input className="form-input" type="number" step="100" min="100"
                      value={buyShares} onChange={e => setBuyShares(e.target.value)} />
                  </div>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">预计金额</label>
                    <input className="form-input" readOnly
                      value={`¥ ${buyAmount.toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                      style={{ color: '#f5a623', cursor: 'default', fontWeight: 600 }} />
                  </div>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">策略来源</label>
                    <input className="form-input" readOnly value={stock.lists[0] ?? '手动录入'}
                      style={{ color: 'var(--text-muted)', cursor: 'default' }} />
                  </div>
                  <div className="form-group" style={{ marginBottom: 0, gridColumn: '1 / -1' }}>
                    <label className="form-label">买入日期</label>
                    <input className="form-input" type="date"
                      value={buyDate} onChange={e => setBuyDate(e.target.value)}
                      style={{ width: 180 }} />
                  </div>
                </div>
                {buyError && (
                  <div style={{ marginTop: 10, fontSize: 12, color: '#FF4D4F' }}>{buyError}</div>
                )}
                <div style={{ display: 'flex', gap: 10, marginTop: 14, justifyContent: 'flex-end' }}>
                  <button className="btn-secondary" onClick={() => setShowBuyForm(false)}>取消</button>
                  <button
                    className="btn-primary" onClick={handleBuy} disabled={buying}
                    style={{ opacity: buying ? 0.6 : 1, cursor: buying ? 'not-allowed' : 'pointer' }}
                  >
                    {buying ? '提交中…' : '确认买入'}
                  </button>
                </div>
              </div>
            )}

            {/* ── Scrollable body ── */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 24px', display: 'flex', flexDirection: 'column', gap: 12 }}>

              {/* ① K线图 */}
              <KlineChart tsCode={stock.code} />

              {/* ② 风险扫描 */}
              <div>
                <div className="drawer-section-title">🛡️ 风险扫描</div>
                <div className="drawer-card">
                  {detailLoading ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--text-muted)', padding: '4px 0' }}>
                      <div className="spinner" style={{ width: 14, height: 14 }} />加载中…
                    </div>
                  ) : (
                    <>
                      {/* ST Risk — real data */}
                      <div className="drawer-flat-row">
                        <span className="drawer-flat-label">ST 风险</span>
                        {detail ? (
                          detail.is_st
                            ? <span style={{ fontSize: 12, fontWeight: 700, color: '#FF4D4F' }}>⚠ ST</span>
                            : <span style={{ fontSize: 12, fontWeight: 600, color: '#00B96B' }}>正常</span>
                        ) : (
                          <span style={{ fontSize: 12, fontWeight: 600, color: risk.stRisk !== '正常' ? '#FF4D4F' : 'var(--text-primary)' }}>
                            {risk.stRisk}
                          </span>
                        )}
                      </div>
                      {([
                        { label: '立案调查', value: risk.investigation, alert: risk.investigation !== '无' },
                        { label: '质押比例', value: risk.pledgeRatio,   alert: parseInt(risk.pledgeRatio) > 40 },
                        { label: '审计意见', value: risk.auditOpinion,  alert: risk.auditOpinion !== '标准无保留' },
                      ] as const).map(item => (
                        <div key={item.label} className="drawer-flat-row">
                          <span className="drawer-flat-label">
                            {item.label}
                            <span style={{ fontSize: 9, color: 'var(--text-muted)', marginLeft: 4 }}>(数据待接入)</span>
                          </span>
                          <span style={{ fontSize: 12, fontWeight: 600, color: item.alert ? '#FF4D4F' : 'var(--text-primary)' }}>
                            {item.value}
                          </span>
                        </div>
                      ))}
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, paddingTop: 8, marginTop: 4, borderTop: '1px solid var(--drawer-row-divider)' }}>
                        <span className="drawer-flat-label">综合风险等级</span>
                        <span style={{
                          fontSize: 12, fontWeight: 700, padding: '2px 14px', borderRadius: 10,
                          background: riskCfg.bg, color: riskCfg.color, border: `1px solid ${riskCfg.border}`,
                        }}>
                          {riskCfg.label}
                        </span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* ② AI 综合分析 */}
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                  <span className="drawer-section-title" style={{ marginBottom: 0 }}>🤖 AI 综合分析</span>
                  {aiLoading && <div className="spinner" style={{ width: 13, height: 13 }} />}
                  {!aiLoading && aiData && (
                    <span style={{ fontSize: 10, background: 'rgba(54,207,201,.15)',
                      border: '1px solid rgba(54,207,201,.3)', color: '#36cfc9',
                      padding: '1px 7px', borderRadius: 8, fontWeight: 600 }}>
                      Claude AI
                    </span>
                  )}
                </div>

                {aiLoading && (
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', padding: '6px 0 10px' }}>
                    正在调用 Claude AI 分析中，请稍候…
                  </div>
                )}

                {!aiLoading && ai && adviceCfg && (
                  <div className="drawer-card" style={{ background: 'var(--drawer-ai-bg)', borderColor: 'var(--drawer-ai-border)', padding: 0, overflow: 'hidden' }}>
                    {/* Bull / Bear columns with dashed divider */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', padding: '14px 14px 12px' }}>
                      <div style={{ paddingRight: 12, borderRight: '1px dashed var(--drawer-ai-border)' }}>
                        <div style={{ fontSize: 11, color: '#FF4D4F', fontWeight: 700, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 4 }}>
                          <span>▲</span> 看多因素
                        </div>
                        {ai.bull_factors.map((f, i) => (
                          <div key={i} style={{ fontSize: 12, color: 'var(--text-primary)', lineHeight: 1.65, display: 'flex', gap: 5, marginBottom: 2 }}>
                            <span style={{ color: '#FF4D4F', flexShrink: 0 }}>·</span>{f}
                          </div>
                        ))}
                      </div>
                      <div style={{ paddingLeft: 12 }}>
                        <div style={{ fontSize: 11, color: '#00B96B', fontWeight: 700, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 4 }}>
                          <span>▼</span> 看空因素
                        </div>
                        {ai.bear_factors.map((f, i) => (
                          <div key={i} style={{ fontSize: 12, color: 'var(--text-primary)', lineHeight: 1.65, display: 'flex', gap: 5, marginBottom: 2 }}>
                            <span style={{ color: '#00B96B', flexShrink: 0 }}>·</span>{f}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Footer bar */}
                    <div style={{
                      background: 'var(--drawer-ai-footer)',
                      borderTop: '1px solid var(--drawer-ai-border)',
                      padding: '10px 14px',
                      display: 'flex', flexDirection: 'column', gap: 8,
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                        <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>操作建议</span>
                        <span style={{
                          fontSize: 13, fontWeight: 700, padding: '2px 14px', borderRadius: 10,
                          background: adviceCfg.bg, color: adviceCfg.color, border: `1px solid ${adviceCfg.border}`,
                        }}>
                          {ai.advice}
                        </span>
                        <div style={{ marginLeft: 'auto', display: 'flex', gap: 14 }}>
                          <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                            止损 <span style={{ color: '#00B96B', fontWeight: 600 }}>-{ai.stop_loss}%</span>
                          </span>
                          <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                            目标 <span style={{ color: '#FF4D4F', fontWeight: 600 }}>+{ai.target}%</span>
                          </span>
                        </div>
                      </div>
                      <ConfidenceBar value={ai.confidence} />
                    </div>
                  </div>
                )}
              </div>

              {/* ③ 策略信号 */}
              <div>
                <div className="drawer-section-title">📡 策略信号</div>
                <div className="drawer-card">
                  {detailLoading ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--text-muted)', padding: '4px 0' }}>
                      <div className="spinner" style={{ width: 14, height: 14 }} />加载中…
                    </div>
                  ) : (
                    <>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 12 }}>
                        <GridItem label="策略来源">
                          {detail?.watchlist_strategy ?? stock.lists[0] ?? '—'}
                        </GridItem>
                        <GridItem label="买点信号">
                          <SignalChip label={detail?.watchlist_buy_signal} />
                        </GridItem>
                        <GridItem label="卖出信号">
                          <SignalChip label={detail?.watchlist_sell_signal} />
                        </GridItem>
                        <GridItem label="入池天数">
                          {inWatchlist ? `${detail!.watchlist_pool_day} 天` : '未入观察池'}
                        </GridItem>
                        <GridItem label="量比">
                          <span style={{ color: '#f5a623' }}>
                            {realVr != null ? `${realVr.toFixed(2)}x` : '—'}
                          </span>
                        </GridItem>
                        <GridItem label="信号强度">
                          <span style={{ color: '#f5a623', fontSize: 14 }}>
                            {'★'.repeat(realVr != null ? vrToStars(realVr) : 2)}
                            {'☆'.repeat(5 - (realVr != null ? vrToStars(realVr) : 2))}
                          </span>
                        </GridItem>
                      </div>
                      <div style={{ fontSize: 12, color: 'var(--text-secondary)', display: 'flex', flexWrap: 'wrap', gap: '3px 16px', paddingTop: 10, borderTop: '1px solid var(--drawer-row-divider)' }}>
                        <span>均线位置：<span style={{ color: '#36cfc9', fontWeight: 600 }}>{ma20Status}</span></span>
                        {inWatchlist && detail?.watchlist_gain_since_entry != null && (
                          <span>
                            累计涨幅：
                            <span style={{ color: detail.watchlist_gain_since_entry >= 0 ? '#FF4D4F' : '#00B96B', fontWeight: 600 }}>
                              {detail.watchlist_gain_since_entry >= 0 ? '+' : ''}
                              {(detail.watchlist_gain_since_entry * 100).toFixed(2)}%
                            </span>
                          </span>
                        )}
                        {inWatchlist && detail?.watchlist_max_gain != null && (
                          <span>
                            最高收益：<span style={{ color: '#FF4D4F', fontWeight: 600 }}>+{(detail.watchlist_max_gain * 100).toFixed(2)}%</span>
                          </span>
                        )}
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* ④ 财务数据 */}
              {detail && (
                <div>
                  <div className="drawer-section-title">📊 财务数据</div>
                  <div className="drawer-card" style={{ padding: 0, overflow: 'hidden' }}>
                    {detail.financials.length === 0 ? (
                      <div style={{ fontSize: 12, color: 'var(--text-muted)', padding: '12px 14px' }}>暂无财务数据</div>
                    ) : (
                      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                        <thead>
                          <tr style={{ color: 'var(--text-secondary)', borderBottom: '1px solid var(--border)' }}>
                            <th style={{ textAlign: 'left',  padding: '8px 14px', fontWeight: 600, background: 'var(--bg-item)' }}>年份</th>
                            <th style={{ textAlign: 'right', padding: '8px 14px', fontWeight: 600, background: 'var(--bg-item)' }}>营收(亿)</th>
                            <th style={{ textAlign: 'right', padding: '8px 14px', fontWeight: 600, background: 'var(--bg-item)' }}>利润总额(亿)</th>
                            <th style={{ textAlign: 'right', padding: '8px 14px', fontWeight: 600, background: 'var(--bg-item)' }}>净利润(亿)</th>
                          </tr>
                        </thead>
                        <tbody>
                          {detail.financials.map((f: FinancialYear) => (
                            <tr key={f.year} style={{ borderBottom: '1px solid var(--drawer-row-divider)' }}>
                              <td style={{ padding: '7px 14px', color: 'var(--text-secondary)', fontWeight: 600 }}>{f.year}</td>
                              <td style={{ padding: '7px 14px', textAlign: 'right', color: 'var(--text-primary)', fontVariantNumeric: 'tabular-nums' }}>
                                {f.revenue_yi != null ? f.revenue_yi.toFixed(2) : '—'}
                              </td>
                              <td style={{ padding: '7px 14px', textAlign: 'right', fontVariantNumeric: 'tabular-nums',
                                color: f.total_profit_yi != null && f.total_profit_yi < 0 ? '#FF4D4F' : 'var(--text-primary)' }}>
                                {f.total_profit_yi != null ? f.total_profit_yi.toFixed(2) : '—'}
                              </td>
                              <td style={{ padding: '7px 14px', textAlign: 'right', fontVariantNumeric: 'tabular-nums',
                                color: f.net_income_yi != null && f.net_income_yi < 0 ? '#FF4D4F' : 'var(--text-primary)' }}>
                                {f.net_income_yi != null ? f.net_income_yi.toFixed(2) : '—'}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </div>
              )}

              {/* ⑤ 量价数据 */}
              <div>
                <div className="drawer-section-title">📈 量价数据</div>
                <div className="drawer-card">
                  {detailLoading ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--text-muted)', padding: '4px 0' }}>
                      <div className="spinner" style={{ width: 14, height: 14 }} />加载中…
                    </div>
                  ) : (
                    <>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 14 }}>
                        <VPItem label="MA5"        value={realMa5  != null ? realMa5.toFixed(2)  : '—'} color="#FF4D4F" />
                        <VPItem label="MA10"       value={realMa10 != null ? realMa10.toFixed(2) : '—'} />
                        <VPItem label="MA20"       value={realMa20 != null ? realMa20.toFixed(2) : '—'} />
                        <VPItem label="VR 量比"    value={realVr   != null ? `${realVr.toFixed(2)}x` : '—'} color="#f5a623" />
                        <VPItem label="换手率"     value={realTurnover != null ? `${realTurnover.toFixed(2)}%` : '—'} />
                        <VPItem label="成交额(亿)" value={realAmount   != null ? realAmount.toFixed(2) : '—'} />
                        <VPItem label="今日涨幅"
                          value={`${changePct > 0 ? '+' : ''}${changePct.toFixed(2)}%`}
                          color={pctColor} />
                        <VPItem label="收盘价" value={realClose.toFixed(2)} />
                      </div>
                      {detail && (
                        <div style={{ paddingTop: 14, borderTop: '1px solid var(--drawer-row-divider)', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
                          <VPItem label="今开"     value={detail.open  != null ? detail.open.toFixed(2)  : '—'} />
                          <VPItem label="最高"     value={detail.high  != null ? detail.high.toFixed(2)  : '—'} color="#FF4D4F" />
                          <VPItem label="最低"     value={detail.low   != null ? detail.low.toFixed(2)   : '—'} color="#00B96B" />
                          <VPItem label="市值(亿)" value={detail.market_cap_yi != null ? detail.market_cap_yi.toFixed(1) : '—'} />
                          <VPItem label="PE(TTM)"  value={detail.pe_ttm != null ? detail.pe_ttm.toFixed(1) : '亏损'}
                            color={detail.pe_ttm == null ? '#f5a623' : undefined} />
                          <VPItem label="PB"       value={detail.pb != null ? detail.pb.toFixed(2) : '—'} />
                          <VPItem label="行业"     value={detail.industry ?? '—'} />
                          <VPItem label="上市日"   value={detail.list_date ?? '—'} />
                        </div>
                      )}
                    </>
                  )}
                </div>
              </div>

            </div>
          </div>
        )}
      </div>
    </>
  );
}
