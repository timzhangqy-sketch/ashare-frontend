export function getStrategyDisplayName(value: string | null | undefined): string {
  if (!value) return '';
  const upper = value.toUpperCase();

  if (upper.includes('IGNITION') || upper.includes('STRICT3') || upper.includes('IGNITE') || upper.includes('VOL_SURGE') || upper.includes('VOL')) {
    return '能量蓄势';
  }
  if (upper.includes('RETOC2')) {
    return '异动策略';
  }
  if (upper.includes('PATTERN')) {
    return '形态策略';
  }
  return value;
}

export function getRouteDisplayName(value: string | null | undefined): string {
  if (!value) return '';
  const lower = value.toLowerCase();

  if (lower === 'holdings') return '持仓中心';
  if (lower === 'backtest') return '回测中心';
  return value;
}
