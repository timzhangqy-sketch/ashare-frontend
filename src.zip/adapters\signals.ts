import {
  fetchCrossStrategies,
  fetchPatternGreen10,
  fetchPatternT2up9,
  fetchPortfolio,
  fetchRetoc2,
  fetchVolSurge,
  fetchWatchlist,
  getDashboardSummary,
  type PatternGreen10Item,
  type PatternT2up9Item,
  type PortfolioItem,
  type Retoc2Item,
  type VolSurgeItem,
  type WatchlistItem,
} from '../api';
import { mapRawDashboardResponseToDto } from './dashboard';
import { getStrategyDisplayName } from '../utils/displayNames';
import type {
  SignalsBuyRowVm,
  SignalsBuyTabVm,
  SignalsDataOrigin,
  SignalsFilterVm,
  SignalsFlowRowVm,
  SignalsFlowTabVm,
  SignalsMetricVm,
  SignalsResonanceRowVm,
  SignalsResonanceTabVm,
  SignalsSellRowVm,
  SignalsSellTabVm,
  SignalsSourceNoteVm,
  SignalsTabBaseVm,
  SignalsWorkspaceVm,
} from '../types/signals';

interface LoadResult<T> {
  data: T;
  failed: boolean;
  warning?: string;
}

interface SignalsWorkspaceSources {
  dashboard: ReturnType<typeof mapRawDashboardResponseToDto> | null;
  watchlist: WatchlistItem[];
  portfolio: PortfolioItem[];
  crossMap: Record<string, string[]>;
  volSurge: VolSurgeItem[];
  retoc2: Retoc2Item[];
  patternT2up9: PatternT2up9Item[];
  patternGreen10: PatternGreen10Item[];
  warnings: string[];
}

interface MarketSnapshot {
  name: string;
  close: number | null;
  pctChg: number | null;
  turnoverRate: number | null;
}

const strategyLabelMap: Record<string, string> = {
  VOL_SURGE: '能量蓄势',
  RETOC2: '异动策略',
  PATTERN_T2UP9: '形态策略',
  PATTERN_GREEN10: '形态策略',
};

function toLabel(strategy: string): string {
  return getStrategyDisplayName(strategy) || strategyLabelMap[strategy] || strategy;
}

async function settle<T>(label: string, loader: () => Promise<T>, fallback: T): Promise<LoadResult<T>> {
  try {
    return { data: await loader(), failed: false };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'unknown error';
    return {
      data: fallback,
      failed: true,
      warning: `${label} 加载失败，当前使用空结果兼容：${message}`,
    };
  }
}

async function loadSources(tradeDate: string): Promise<SignalsWorkspaceSources> {
  const [
    dashboardResult,
    watchlistResult,
    portfolioResult,
    crossResult,
    volSurgeResult,
    retoc2Result,
    patternT2Result,
    patternGreenResult,
  ] = await Promise.all([
    settle('DashboardSummary', async () => mapRawDashboardResponseToDto(await getDashboardSummary(tradeDate)), null),
    settle('Watchlist', () => fetchWatchlist(), [] as WatchlistItem[]),
    settle('持仓中心', async () => (await fetchPortfolio('open')).data, [] as PortfolioItem[]),
    settle('CrossStrategies', () => fetchCrossStrategies(), {} as Record<string, string[]>),
    settle('能量蓄势', () => fetchVolSurge(tradeDate), [] as VolSurgeItem[]),
    settle('异动策略', () => fetchRetoc2(tradeDate), [] as Retoc2Item[]),
    settle('形态策略 T2UP9', () => fetchPatternT2up9(tradeDate), [] as PatternT2up9Item[]),
    settle('形态策略 Green10', () => fetchPatternGreen10(tradeDate), [] as PatternGreen10Item[]),
  ]);

  const warnings = [
    dashboardResult.warning,
    watchlistResult.warning,
    portfolioResult.warning,
    crossResult.warning,
    volSurgeResult.warning,
    retoc2Result.warning,
    patternT2Result.warning,
    patternGreenResult.warning,
  ].filter((warning): warning is string => Boolean(warning));

  if (
    [
      dashboardResult.failed,
      watchlistResult.failed,
      portfolioResult.failed,
      crossResult.failed,
      volSurgeResult.failed,
      retoc2Result.failed,
      patternT2Result.failed,
      patternGreenResult.failed,
    ].every(Boolean)
  ) {
    throw new Error('Signals 数据源全部加载失败，当前无法生成工作台。');
  }

  return {
    dashboard: dashboardResult.data,
    watchlist: watchlistResult.data,
    portfolio: portfolioResult.data,
    crossMap: crossResult.data,
    volSurge: volSurgeResult.data,
    retoc2: retoc2Result.data,
    patternT2up9: patternT2Result.data,
    patternGreen10: patternGreenResult.data,
    warnings,
  };
}

function buildMarketSnapshotMap(sources: SignalsWorkspaceSources): Map<string, MarketSnapshot> {
  const map = new Map<string, MarketSnapshot>();

  for (const item of sources.volSurge) {
    map.set(item.ts_code, {
      name: item.name,
      close: item.close,
      pctChg: item.ret5 != null ? item.ret5 * 100 : null,
      turnoverRate: item.turnover_rate,
    });
  }

  for (const item of sources.retoc2) {
    if (!map.has(item.ts_code)) {
      map.set(item.ts_code, {
        name: item.name,
        close: item.close,
        pctChg: item.pct_chg,
        turnoverRate: item.turnover_rate,
      });
    }
  }

  for (const item of sources.patternT2up9) {
    if (!map.has(item.ts_code)) {
      map.set(item.ts_code, {
        name: item.name,
        close: null,
        pctChg: item.ret_t0 * 100,
        turnoverRate: null,
      });
    }
  }

  for (const item of sources.patternGreen10) {
    if (!map.has(item.ts_code)) {
      map.set(item.ts_code, {
        name: item.name,
        close: null,
        pctChg: null,
        turnoverRate: null,
      });
    }
  }

  return map;
}

function buildWatchlistMap(items: WatchlistItem[]): Map<string, WatchlistItem[]> {
  const map = new Map<string, WatchlistItem[]>();
  for (const item of items) {
    const current = map.get(item.ts_code) ?? [];
    current.push(item);
    map.set(item.ts_code, current);
  }
  return map;
}

function buildPortfolioMap(items: PortfolioItem[]): Map<string, PortfolioItem> {
  return new Map(items.map(item => [item.ts_code, item]));
}

function metric(label: string, value: string, helper: string, origin: SignalsDataOrigin): SignalsMetricVm {
  return { label, value, helper, origin };
}

function filter(label: string, value: string, origin: SignalsDataOrigin): SignalsFilterVm {
  return { label, value, origin };
}

function note(label: string, detail: string, origin: SignalsDataOrigin): SignalsSourceNoteVm {
  return { label, detail, origin };
}

function buildTabBase<TKey extends SignalsTabBaseVm['key']>(
  key: TKey,
  label: string,
  title: string,
  description: string,
  metrics: SignalsMetricVm[],
  filters: SignalsFilterVm[],
  sourceNotes: SignalsSourceNoteVm[],
  emptyTitle: string,
  emptyText: string,
  contextTitle: string,
  contextText: string,
  nextSteps: string[],
): SignalsTabBaseVm & { key: TKey } {
  return {
    key,
    label,
    title,
    description,
    metrics,
    filters,
    sourceNotes,
    emptyTitle,
    emptyText,
    context: {
      title: contextTitle,
      text: contextText,
      sections: [],
      nextSteps,
    },
  };
}

function mapSignalStrength(score: number, origin: SignalsDataOrigin): string {
  if (score >= 90) return '高';
  if (score >= 75) return '中高';
  if (score >= 60) return '中';
  return origin === 'primary' ? '待补充' : '过渡';
}

function buildBuyRows(sources: SignalsWorkspaceSources): SignalsBuyRowVm[] {
  const watchlistMap = buildWatchlistMap(sources.watchlist);
  const portfolioMap = buildPortfolioMap(sources.portfolio);
  const marketMap = buildMarketSnapshotMap(sources);
  const rows = new Map<string, SignalsBuyRowVm>();

  for (const item of sources.watchlist.filter(entry => Boolean(entry.buy_signal))) {
    const market = marketMap.get(item.ts_code);
    const crossStrategyCount = (sources.crossMap[item.ts_code] ?? []).filter(strategy => strategy !== 'IGNITE').length;
    const id = `${item.ts_code}-${item.strategy}-buy`;
    rows.set(id, {
      id,
      tsCode: item.ts_code,
      name: item.name,
      strategySource: toLabel(item.strategy),
      signalType: item.buy_signal ?? 'BUY_SIGNAL',
      signalStrength: mapSignalStrength(85 + Math.min(item.pool_day, 10), 'primary'),
      close: market?.close ?? null,
      pctChg: market?.pctChg ?? item.latest_pct_chg ?? null,
      turnoverRate: market?.turnoverRate ?? null,
      inWatchlist: true,
      inPortfolio: portfolioMap.has(item.ts_code),
      crossStrategyCount,
      origin: 'primary',
      sourceLabel: '主源: Watchlist',
    });
  }

  for (const item of sources.volSurge.slice(0, 12)) {
    const id = `${item.ts_code}-vol-surge`;
    if (rows.has(id)) continue;
    rows.set(id, {
      id,
      tsCode: item.ts_code,
      name: item.name,
      strategySource: '能量蓄势',
      signalType: 'VOL_SURGE_TRIGGER',
      signalStrength: mapSignalStrength(100 - item.entry_rank * 3, 'aggregate'),
      close: item.close,
      pctChg: item.ret5 != null ? item.ret5 * 100 : null,
      turnoverRate: item.turnover_rate,
      inWatchlist: watchlistMap.has(item.ts_code),
      inPortfolio: portfolioMap.has(item.ts_code),
      crossStrategyCount: (sources.crossMap[item.ts_code] ?? []).filter(strategy => strategy !== 'IGNITE').length,
      origin: 'aggregate',
      sourceLabel: '聚合: 能量蓄势',
    });
  }

  for (const item of sources.retoc2.slice(0, 10)) {
    const id = `${item.ts_code}-retoc2`;
    if (rows.has(id)) continue;
    rows.set(id, {
      id,
      tsCode: item.ts_code,
      name: item.name,
      strategySource: '异动策略',
      signalType: `RETOC2_${item.grade}`,
      signalStrength: mapSignalStrength(item.grade === 'A' ? 88 : 74, 'aggregate'),
      close: item.close,
      pctChg: item.pct_chg,
      turnoverRate: item.turnover_rate,
      inWatchlist: watchlistMap.has(item.ts_code),
      inPortfolio: portfolioMap.has(item.ts_code),
      crossStrategyCount: (sources.crossMap[item.ts_code] ?? []).filter(strategy => strategy !== 'IGNITE').length,
      origin: 'aggregate',
      sourceLabel: '聚合: 异动策略',
    });
  }

  for (const item of sources.patternT2up9.filter(entry => entry.in_pool || entry.in_continuation).slice(0, 8)) {
    const id = `${item.ts_code}-pattern-t2`;
    if (rows.has(id)) continue;
    rows.set(id, {
      id,
      tsCode: item.ts_code,
      name: item.name,
      strategySource: 'T2UP9',
      signalType: item.in_continuation ? 'PATTERN_CONTINUATION' : 'PATTERN_ENTRY',
      signalStrength: mapSignalStrength(70 + Math.round(item.ret_t2 * 100), 'aggregate'),
      close: null,
      pctChg: item.ret_t0 * 100,
      turnoverRate: null,
      inWatchlist: watchlistMap.has(item.ts_code),
      inPortfolio: portfolioMap.has(item.ts_code),
      crossStrategyCount: (sources.crossMap[item.ts_code] ?? []).filter(strategy => strategy !== 'IGNITE').length,
      origin: 'aggregate',
      sourceLabel: '聚合: 形态策略',
    });
  }

  return [...rows.values()].sort((left, right) => {
    if (left.inPortfolio !== right.inPortfolio) return left.inPortfolio ? 1 : -1;
    if (left.crossStrategyCount !== right.crossStrategyCount) return right.crossStrategyCount - left.crossStrategyCount;
    return left.tsCode.localeCompare(right.tsCode);
  });
}

function buildSellRows(sources: SignalsWorkspaceSources): SignalsSellRowVm[] {
  const actionable = sources.portfolio.filter(item => item.action_signal && item.action_signal !== 'HOLD');

  if (actionable.length > 0) {
    return actionable.map(item => ({
      id: `portfolio-${item.id}`,
      portfolioId: item.id,
      tsCode: item.ts_code,
      name: item.name,
      sourceStrategy: item.source_strategy,
      holdDays: item.hold_days,
      latestClose: item.latest_close,
      todayPnl: item.today_pnl,
      unrealizedPnl: item.unrealized_pnl,
      actionSignal: item.action_signal ?? 'HOLD',
      signalReason: item.signal_reason ?? '待后端补充原因',
      origin: 'primary',
      sourceLabel: '主源: 持仓中心',
    }));
  }

  return sources.portfolio.slice(0, 8).map(item => ({
    id: `portfolio-fallback-${item.id}`,
    portfolioId: item.id,
    tsCode: item.ts_code,
    name: item.name,
    sourceStrategy: item.source_strategy,
    holdDays: item.hold_days,
    latestClose: item.latest_close,
    todayPnl: item.today_pnl,
    unrealizedPnl: item.unrealized_pnl,
    actionSignal: item.action_signal ?? 'HOLD',
    signalReason: item.signal_reason ?? '当前无主动卖点，展示组合持仓作为过渡复核视图',
    origin: 'fallback',
    sourceLabel: '过渡: 持仓中心持仓',
  }));
}

function buildResonanceRows(sources: SignalsWorkspaceSources): SignalsResonanceRowVm[] {
  const watchlistMap = buildWatchlistMap(sources.watchlist);
  const portfolioMap = buildPortfolioMap(sources.portfolio);
  const marketMap = buildMarketSnapshotMap(sources);
  const rows: SignalsResonanceRowVm[] = [];

  for (const [tsCode, strategies] of Object.entries(sources.crossMap)) {
    const activeStrategies = strategies.filter(strategy => strategy !== 'IGNITE');
    if (activeStrategies.length < 2) continue;

    const watchlistItems = watchlistMap.get(tsCode) ?? [];
    const portfolioItem = portfolioMap.get(tsCode);
    const market = marketMap.get(tsCode);
    const name = watchlistItems[0]?.name ?? portfolioItem?.name ?? market?.name ?? tsCode;
    const latestSignal = watchlistItems.find(item => item.buy_signal)?.buy_signal
      ?? watchlistItems.find(item => item.sell_signal)?.sell_signal
      ?? '共振待复核';

    rows.push({
      id: `res-${tsCode}`,
      tsCode,
      name,
      strategies: activeStrategies.map(toLabel),
      strategyCount: activeStrategies.length,
      latestSignal,
      close: market?.close ?? portfolioItem?.latest_close ?? null,
      pctChg: market?.pctChg ?? null,
      inWatchlist: watchlistItems.length > 0,
      inPortfolio: portfolioMap.has(tsCode),
      origin: 'primary',
      sourceLabel: '主源: CrossStrategies',
    });
  }

  return rows.sort((left, right) => {
    if (left.strategyCount !== right.strategyCount) return right.strategyCount - left.strategyCount;
    if (left.inPortfolio !== right.inPortfolio) return left.inPortfolio ? 1 : -1;
    return left.tsCode.localeCompare(right.tsCode);
  });
}

function buildFlowRows(sources: SignalsWorkspaceSources): SignalsFlowRowVm[] {
  const rows: SignalsFlowRowVm[] = [];

  for (const item of sources.watchlist.filter(entry => Boolean(entry.buy_signal))) {
    rows.push({
      id: `flow-watch-buy-${item.ts_code}-${item.strategy}`,
      timeLabel: '交易日内 / Watchlist',
      eventType: '买点触发',
      strategySource: toLabel(item.strategy),
      tsCode: item.ts_code,
      name: item.name,
      signalLabel: item.buy_signal ?? 'BUY_SIGNAL',
      followAction: '待判断 / 可转买入',
      origin: 'primary',
      sourceLabel: '主源: Watchlist',
    });
  }

  for (const item of sources.portfolio.filter(entry => entry.action_signal && entry.action_signal !== 'HOLD')) {
    rows.push({
      id: `flow-sell-${item.id}`,
      timeLabel: '交易日内 / 持仓中心',
      eventType: '卖点触发',
      strategySource: item.source_strategy,
      tsCode: item.ts_code,
      name: item.name,
      signalLabel: item.action_signal ?? 'HOLD',
      followAction: '待复核 / 可转卖出',
      origin: 'primary',
      sourceLabel: '主源: 持仓中心',
    });
  }

  for (const item of sources.volSurge.slice(0, 6)) {
    rows.push({
      id: `flow-vol-${item.ts_code}`,
      timeLabel: 'Round 2 聚合流',
      eventType: '策略入选',
      strategySource: '能量蓄势',
      tsCode: item.ts_code,
      name: item.name,
      signalLabel: `排名 ${item.entry_rank}`,
      followAction: '聚合展示 / 待统一 feed',
      origin: 'aggregate',
      sourceLabel: '聚合: 能量蓄势',
    });
  }

  for (const item of sources.retoc2.slice(0, 6)) {
    rows.push({
      id: `flow-retoc2-${item.ts_code}`,
      timeLabel: 'Round 2 聚合流',
      eventType: '异动告警',
      strategySource: '异动策略',
      tsCode: item.ts_code,
      name: item.name,
      signalLabel: `Grade ${item.grade}`,
      followAction: '聚合展示 / 待统一 feed',
      origin: 'aggregate',
      sourceLabel: '聚合: 异动策略',
    });
  }

  return rows.sort((left, right) => {
    if (left.origin !== right.origin) return left.origin === 'primary' ? -1 : 1;
    return left.tsCode.localeCompare(right.tsCode);
  });
}

function buildBuyTab(sources: SignalsWorkspaceSources): SignalsBuyTabVm {
  const rows = buildBuyRows(sources);
  const primaryCount = rows.filter(row => row.origin === 'primary').length;
  const aggregateCount = rows.length - primaryCount;
  const base = buildTabBase(
    'buy',
    '今日买点',
    '今日买点工作台',
    '以 Watchlist 为主源，叠加旧策略榜单形成可浏览买点视图。当前 signal_strength 为前端映射字段，后续可替换为正式口径。',
    [
      metric('今日机会', `${sources.dashboard?.opportunity.buySignalsCount ?? rows.length}`, 'DashboardSummary / 主机会计数', 'primary'),
      metric('主源买点', `${primaryCount}`, 'Watchlist.buy_signal', 'primary'),
      metric('聚合补充', `${aggregateCount}`, '能量蓄势 / 异动策略 / 形态策略 前端聚合', 'aggregate'),
    ],
    [
      filter('交易日', sources.dashboard?.tradeDate ?? '--', 'primary'),
      filter('正式主源', 'Watchlist', 'primary'),
      filter('聚合补位', '能量蓄势 / 异动策略 / 形态策略', 'aggregate'),
    ],
    [
      note('正式主源', 'Watchlist.buy_signal + Dashboard 今日机会摘要', 'primary'),
      note('前端聚合', '能量蓄势 / 异动策略 / 形态策略 用于补足可浏览机会列表', 'aggregate'),
      note('过渡字段', 'signal_strength 为 Round 2 映射值，不代表正式后端口径', 'derived'),
    ],
    '当前没有可展示的买点',
    '如果主源与聚合源都为空，页面会保持工作台结构并等待后续交易日数据。',
    '买点上下文',
    '当前列表已可浏览，但仍属于 Round 2 过渡态。页面会标记主源与聚合来源，避免误判为正式统一接口。',
    ['补统一信号强度字段', '补行内动作与详情联动', '后续切换到正式 signals feed 时仅替换 adapter'],
  );

  base.context.sections = [
    { label: '当前行模型', value: 'buy row model 已独立于原始接口返回' },
    { label: '正式主源', value: 'Watchlist / DashboardSummary' },
    { label: '聚合补位', value: '旧策略榜单通过 adapter 汇总，不在页面层拼装' },
  ];

  return { ...base, rows };
}

function buildSellTab(sources: SignalsWorkspaceSources): SignalsSellTabVm {
  const rows = buildSellRows(sources);
  const actionableCount = rows.filter(row => row.origin === 'primary').length;
  const base = buildTabBase(
    'sell',
    '今日卖点',
    '今日卖点复核台',
    '以持仓中心为正式主源。若当前无主动卖点，则退化展示组合持仓作为过渡复核视图。',
    [
      metric('卖点提示', `${sources.dashboard?.portfolio.sellSignalsCount ?? actionableCount}`, 'DashboardSummary / 持仓中心卖点计数', 'primary'),
      metric('主动卖点', `${actionableCount}`, '持仓中心 action_signal != HOLD', 'primary'),
      metric('过渡复核', `${rows.filter(row => row.origin === 'fallback').length}`, '无主动卖点时展示组合持仓', 'fallback'),
    ],
    [
      filter('交易日', sources.dashboard?.tradeDate ?? '--', 'primary'),
      filter('正式主源', '持仓中心', 'primary'),
      filter('当前规则', actionableCount > 0 ? '只展示主动卖点' : '退化展示持仓', actionableCount > 0 ? 'primary' : 'fallback'),
    ],
    [
      note('正式主源', '持仓中心 action_signal / signal_reason', 'primary'),
      note('过渡态', '当前无主动卖点时，展示 open positions 作为复核入口', 'fallback'),
      note('后续衔接', 'Round 3 再补行内卖出、跳组合与详情联动', 'derived'),
    ],
    '当前没有卖点数据',
    '如果组合数据为空，将保持工作台结构与说明，不向其他域扩散。',
    '卖点上下文',
    '这里承接组合卖点，不替代持仓中心正式页。Round 2 重点是把主源字段收口成统一 row model。',
    ['接行内卖出动作', '补 signal_reason 展开体验', '补与持仓中心的 URL/动作衔接'],
  );

  base.context.sections = [
    { label: '当前行模型', value: 'sell row model 以持仓中心为正式主源' },
    { label: '主源字段', value: 'portfolio_id / action_signal / signal_reason 已统一收口' },
    { label: '过渡策略', value: actionableCount > 0 ? '仅展示主动卖点' : '展示持仓复核视图' },
  ];

  return { ...base, rows };
}

function buildResonanceTab(sources: SignalsWorkspaceSources): SignalsResonanceTabVm {
  const rows = buildResonanceRows(sources);
  const base = buildTabBase(
    'resonance',
    '多策略共振',
    '多策略共振观察台',
    '以 CrossStrategies 为正式主源，补齐观察池 / 持仓中心 / 市场字段，形成可浏览的共振标的列表。',
    [
      metric('共振机会', `${sources.dashboard?.opportunity.resonanceCount ?? rows.length}`, 'DashboardSummary / CrossStrategies', 'primary'),
      metric('共振标的', `${rows.length}`, 'CrossStrategies 中 active strategy >= 2', 'primary'),
      metric('已在组合', `${rows.filter(row => row.inPortfolio).length}`, '组合交叉状态由持仓中心补齐', 'derived'),
    ],
    [
      filter('交易日', sources.dashboard?.tradeDate ?? '--', 'primary'),
      filter('正式主源', 'CrossStrategies', 'primary'),
      filter('补齐来源', '观察池 / 持仓中心 / 市场快照', 'derived'),
    ],
    [
      note('正式主源', 'CrossStrategies 提供策略重叠关系', 'primary'),
      note('派生补齐', '名称、最近信号、行情字段通过其他已存在接口补齐', 'derived'),
      note('当前限制', '共振强弱仍按策略数做前端分层，未接正式强度口径', 'fallback'),
    ],
    '当前没有可展示的共振标的',
    '如果 cross strategies 返回为空，页面保留结构与来源说明，等待后续交易日数据。',
    '共振上下文',
    'Round 2 已把“多策略共振”从标签能力提升到独立工作台列表，但强弱口径仍是过渡态。',
    ['补正式共振优先级字段', '补按主策略过滤', 'Round 3 接详情与跳来源策略动作'],
  );

  base.context.sections = [
    { label: '正式主源', value: 'CrossStrategies' },
    { label: '补齐字段', value: 'latest signal / market snapshot / watchlist state' },
    { label: '过渡字段', value: '当前共振等级按 strategy_count 分层' },
  ];

  return { ...base, rows };
}

function buildFlowTab(sources: SignalsWorkspaceSources): SignalsFlowTabVm {
  const rows = buildFlowRows(sources);
  const base = buildTabBase(
    'flow',
    '策略触发流',
    '策略触发流时间线',
    '当前为 Round 2 聚合流。adapter 会把观察池、旧策略榜单与持仓中心 signal 扁平化为可浏览事件行，后续可整体替换为正式 lifecycle/event feed。',
    [
      metric('聚合事件', `${rows.length}`, 'Round 2 adapter 聚合流', 'aggregate'),
      metric('正式主源事件', `${rows.filter(row => row.origin === 'primary').length}`, '观察池 / 持仓中心', 'primary'),
      metric('旧策略补充', `${rows.filter(row => row.origin === 'aggregate').length}`, '能量蓄势 / 异动策略 聚合事件', 'aggregate'),
    ],
    [
      filter('交易日', sources.dashboard?.tradeDate ?? '--', 'primary'),
      filter('当前模式', 'Round 2 聚合流', 'aggregate'),
      filter('后续替换位', 'lifecycle / event feed', 'derived'),
    ],
    [
      note('当前模式', '本 Tab 当前不是正式 event feed，而是 adapter 聚合出的过渡时间线', 'aggregate'),
      note('正式主源', '观察池 / 持仓中心提供主要事件行', 'primary'),
      note('后续方向', 'lifecycle feed 到位后，只替换 adapter 输入，不改页面层结构', 'derived'),
    ],
    '当前没有可展示的触发流',
    '如果交易日无信号和组合动作，页面会保留聚合流说明与字段结构。',
    '触发流上下文',
    '本轮已把“策略触发流”从空壳推进到可浏览事件行，但会明确标记其为 Round 2 聚合流。',
    ['明确 lifecycle 接口契约', '补事件状态与下游动作联动', 'Round 3 再接正式 feed 替换策略'],
  );

  base.context.sections = [
    { label: '当前流类型', value: 'Round 2 聚合流' },
    { label: '主源事件', value: '观察池 buy/sell + 持仓中心 sell signal' },
    { label: '聚合事件', value: '能量蓄势 / 异动策略 作为策略触发补充' },
  ];

  return { ...base, rows };
}

export async function loadSignalsWorkspace(tradeDate: string): Promise<SignalsWorkspaceVm> {
  const sources = await loadSources(tradeDate);
  return {
    tradeDate: sources.dashboard?.tradeDate ?? tradeDate,
    generatedAtText: sources.dashboard?.generatedAt ?? '本轮未接统一生成时间，展示请求交易日',
    handoffText: 'Signals 已进入可浏览数据版。Round 2 通过 adapter 统一承接主源数据、聚合数据和过渡字段。',
    workspaceNotes: [
      note('正式主源', 'DashboardSummary / 观察池 / 持仓中心 / CrossStrategies', 'primary'),
      note('前端聚合', '能量蓄势 / 异动策略 / 形态策略 仅通过 adapter 补位，不直接绑页面', 'aggregate'),
      note('过渡字段', 'signal_strength、flow 事件时间等仍属于 derived / fallback 口径', 'derived'),
    ],
    warnings: sources.warnings,
    tabs: {
      buy: buildBuyTab(sources),
      sell: buildSellTab(sources),
      resonance: buildResonanceTab(sources),
      flow: buildFlowTab(sources),
    },
  };
}
