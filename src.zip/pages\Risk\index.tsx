import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  buildRiskContext,
  buildRiskQueryState,
  findRiskDomainByFocus,
  getRiskFocusRows,
  loadRiskWorkspace,
} from '../../adapters/risk';
import RiskBreakdownPanel from '../../components/risk/RiskBreakdownPanel';
import RiskContextPanel from '../../components/risk/RiskContextPanel';
import RiskEventFlowPanel from '../../components/risk/RiskEventFlowPanel';
import GateBlockPanel from '../../components/risk/GateBlockPanel';
import RiskHeader from '../../components/risk/RiskHeader';
import RiskOverviewStrip from '../../components/risk/RiskOverviewStrip';
import RiskScorePanel from '../../components/risk/RiskScorePanel';
import RiskTabs from '../../components/risk/RiskTabs';
import { useContextPanel } from '../../context/ContextPanelContext';
import { useDate } from '../../context/DateContext';
import { useApiData } from '../../hooks/useApiData';
import type { StockContextPanelPayload } from '../../types/contextPanel';
import type { RiskDomainModel, RiskTab } from '../../types/risk';
import { buildResearchHref } from '../../utils/researchHandoff';

interface RiskActionVm {
  key: string;
  label: string;
  enabled: boolean;
  note: string;
  href: string | null;
}

function buildSourceLabel(source: string): string {
  if (source === 'dashboard') return '来源：Dashboard';
  if (source === 'signals') return '来源：Signals';
  if (source === 'watchlist') return '来源：观察池';
  if (source === 'portfolio') return '来源：持仓中心';
  return '来源：直接进入';
}

function buildScopeLabel(scope: string): string {
  if (scope === 'watchlist') return '范围：观察池';
  if (scope === 'portfolio') return '范围：持仓中心';
  return '范围：全部';
}

function buildSourceBackHref(source: string, focus: string | null, scope: string, strategy: string | null): string | null {
  if (source === 'dashboard') return '/dashboard';
  if (source === 'signals') {
    return `/signals?source=risk${focus ? `&focus=${encodeURIComponent(focus)}` : ''}${strategy ? `&strategy=${encodeURIComponent(strategy)}` : ''}`;
  }
  if (source === 'watchlist') {
    return `/watchlist?source=risk${focus ? `&focus=${encodeURIComponent(focus)}` : ''}&view=table`;
  }
  if (source === 'portfolio') {
    return `/portfolio?source=risk${focus ? `&focus=${encodeURIComponent(focus)}` : ''}${scope === 'portfolio' ? '&tab=open' : ''}`;
  }
  return null;
}

function buildRiskContextPanelPayload(
  row: RiskDomainModel,
  context: ReturnType<typeof buildRiskContext>,
  tradeDate: string,
): StockContextPanelPayload {
  const strategyHref = row?.sourceStrategy
    ? buildSourceBackHref('signals', row.tsCode, 'all', row.sourceStrategy)
    : null;

  return {
    title: row.name,
    name: row.name,
    tsCode: row.tsCode,
    sourceStrategy: row.sourceStrategy,
    subtitle: row.tradeAllowedLabel,
    summary: context?.recommendedNextStep ?? row.recommendedPositionText,
    tags: [
      { label: row.riskLevelLabel, tone: 'state' },
      { label: row.tradeAllowedLabel, tone: row.tradeAllowed ? 'source' : 'state' },
      ...(row.sourceStrategy ? [{ label: row.sourceStrategy, tone: 'strategy' as const }] : []),
      ...(row.inWatchlist ? [{ label: '观察池', tone: 'source' as const }] : []),
      ...(row.inPortfolio ? [{ label: '持仓中', tone: 'source' as const }] : []),
    ],
    summaryItems: [
      { label: '风险等级', value: row.riskLevelLabel },
      { label: '交易结论', value: row.tradeAllowedLabel },
      { label: '来源策略', value: context?.sourceStrategyLabel ?? '未归因' },
      { label: '阻断原因', value: row.blockReason || '未触发阻断' },
      { label: '仓位上限', value: row.recommendedPositionText },
    ],
    actions: [
      {
        label: '查看研究',
        href: buildResearchHref({
          source: 'risk',
          focus: row.tsCode,
          strategy: row.sourceStrategy,
          riskLevel: row.riskLevel,
          tradeDate,
          detailRoute: row.sourceStrategy ? 'backtest' : null,
          detailKey: row.sourceStrategy,
        }),
        note: '查看当前风险对象的研究验证结论。',
      },
      {
        label: '查看观察池',
        href: row.inWatchlist ? `/watchlist?source=risk&focus=${encodeURIComponent(row.tsCode)}&view=table` : undefined,
        disabled: !row.inWatchlist,
        note: row.inWatchlist ? '回到观察池查看该对象的跟踪状态。' : '当前没有观察池关联记录。',
      },
      {
        label: '查看持仓',
        href: row.inPortfolio ? `/portfolio?source=risk&focus=${encodeURIComponent(row.tsCode)}` : undefined,
        disabled: !row.inPortfolio,
        note: row.inPortfolio ? '回到持仓中心查看该对象的组合状态。' : '当前没有持仓关联记录。',
      },
      {
        label: '查看来源策略',
        href: strategyHref ?? undefined,
        disabled: !strategyHref,
        note: strategyHref ? '回到来源工作域查看原始策略上下文。' : '当前没有可稳定跳转的来源策略页。',
      },
    ],
  };
}

export default function RiskPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { selectedDate } = useDate();
  const queryState = buildRiskQueryState(searchParams);
  const [selectedFocus, setSelectedFocus] = useState<string | null>(queryState.focus);
  const [feedback, setFeedback] = useState<{ tone: 'info' | 'warning'; text: string } | null>(null);
  const missedFocusRef = useRef<string | null>(null);
  const { openPanel, closePanel } = useContextPanel();

  const { data, loading, error, refetch } = useApiData(
    () => loadRiskWorkspace(queryState, selectedDate),
    [selectedDate, searchParams.toString()],
  );

  const activeRows = useMemo(() => (data ? getRiskFocusRows(data, queryState.tab) : []), [data, queryState.tab]);

  useEffect(() => {
    if (queryState.tab === 'breakdown') {
      setSelectedFocus(queryState.focus);
      return;
    }

    if (!activeRows.length) {
      setSelectedFocus(null);
      return;
    }

    const focusRow = queryState.focus ? activeRows.find(row => row.tsCode === queryState.focus) : null;
    if (focusRow) {
      missedFocusRef.current = null;
      setSelectedFocus(focusRow.tsCode);
      return;
    }

    if (queryState.focus && missedFocusRef.current !== `${queryState.tab}:${queryState.focus}`) {
      missedFocusRef.current = `${queryState.tab}:${queryState.focus}`;
      setFeedback({ tone: 'warning', text: `未命中 ${queryState.focus}，已回退到当前标签的第一条记录。` });
    }

    setSelectedFocus(activeRows[0].tsCode);
  }, [activeRows, queryState.focus, queryState.tab]);

  const activeDomain = useMemo(
    () => (data ? findRiskDomainByFocus(data.domainRows, selectedFocus ?? queryState.focus) : null),
    [data, queryState.focus, selectedFocus],
  );
  const activeBreakdownRow = useMemo(
    () => data?.breakdownRows.find(row => row.tsCode === (selectedFocus ?? queryState.focus ?? '')) ?? null,
    [data, queryState.focus, selectedFocus],
  );
  const context = useMemo(() => buildRiskContext(activeDomain), [activeDomain]);

  useEffect(() => {
    if (!activeDomain || !context) {
      closePanel();
      return;
    }

    openPanel({
      entityType: 'stock',
      entityKey: activeDomain.tsCode,
      sourcePage: 'risk',
      focus: activeDomain.tsCode,
      activeTab: queryState.tab,
      payloadVersion: 'v1',
      payload: buildRiskContextPanelPayload(activeDomain, context, activeDomain.tradeDate ?? selectedDate),
    });
  }, [activeDomain, context, queryState.tab, openPanel, closePanel, selectedDate]);

  useEffect(() => () => closePanel(), [closePanel]);

  const syncParams = (updater: (params: URLSearchParams) => void) => {
    const next = new URLSearchParams(searchParams);
    updater(next);
    setSearchParams(next, { replace: true });
  };

  const handleTabChange = (tab: RiskTab) => {
    syncParams(params => {
      if (tab === 'gate') params.delete('tab');
      else params.set('tab', tab);
      if (selectedFocus) params.set('focus', selectedFocus);
    });
  };

  const handleFocusChange = (tsCode: string) => {
    setSelectedFocus(tsCode);
    setFeedback(null);
    syncParams(params => {
      params.set('focus', tsCode);
    });
  };

  const openBreakdown = (tsCode: string) => {
    setSelectedFocus(tsCode);
    setFeedback(null);
    syncParams(params => {
      params.set('tab', 'breakdown');
      params.set('focus', tsCode);
    });
  };

  const openHref = (href: string | null, emptyMessage: string) => {
    if (!href) {
      setFeedback({ tone: 'warning', text: emptyMessage });
      return;
    }
    navigate(href);
  };

  const contextActions: RiskActionVm[] = useMemo(() => {
    const focus = activeDomain?.tsCode ?? queryState.focus;
    const strategy = activeDomain?.sourceStrategy ?? null;
    return [
      {
        key: 'back',
        label: '返回来源页',
        enabled: queryState.source !== 'direct',
        note: '当前来源无法精确恢复时，会回到对应工作域首页。',
        href: buildSourceBackHref(queryState.source, focus, queryState.scope, strategy),
      },
      {
        key: 'watchlist',
        label: '去观察池',
        enabled: Boolean(activeDomain?.inWatchlist),
        note: '当前股票不在观察池中，暂时无法回到观察池视角。',
        href: activeDomain?.inWatchlist
          ? `/watchlist?source=risk&focus=${encodeURIComponent(activeDomain.tsCode)}&view=table`
          : null,
      },
      {
        key: 'portfolio',
        label: '去持仓中心',
        enabled: Boolean(activeDomain?.inPortfolio),
        note: '当前股票不在持仓中心中，暂时无法回到持仓视角。',
        href: activeDomain?.inPortfolio
          ? `/portfolio?source=risk&focus=${encodeURIComponent(activeDomain.tsCode)}`
          : null,
      },
      {
        key: 'signals',
        label: '去 Signals',
        enabled: Boolean(activeDomain?.sourceStrategy),
        note: '当前缺少来源策略，暂时无法恢复到对应信号页。',
        href: activeDomain?.sourceStrategy ? `/signals?source=risk&focus=${encodeURIComponent(activeDomain.tsCode)}` : null,
      },
      {
        key: 'research',
        label: '查看研究',
        enabled: true,
        note: '围绕当前风险对象继续做回测、因子和归因验证。',
        href: activeDomain
          ? buildResearchHref({
              source: 'risk',
              focus: activeDomain.tsCode,
              strategy: activeDomain.sourceStrategy,
              riskLevel: activeDomain.riskLevel,
              tradeDate: activeDomain.tradeDate ?? selectedDate,
              detailRoute: activeDomain.sourceStrategy ? 'backtest' : null,
              detailKey: activeDomain.sourceStrategy,
            })
          : null,
      },
      {
        key: 'execution',
        label: '去模拟执行',
        enabled: Boolean(activeDomain),
        note: '跳到模拟执行，继续查看当前对象的执行约束、订单与持仓承接。',
        href: activeDomain
          ? `/execution?tab=constraints&source=risk&focus=${encodeURIComponent(activeDomain.tsCode)}${activeDomain.sourceStrategy ? `&strategy=${encodeURIComponent(activeDomain.sourceStrategy)}` : ''}`
          : null,
        },
        {
          key: 'system',
          label: '查看系统状态',
          enabled: true,
          note: '围绕当前风控判断，继续核对数据覆盖、接口健康和系统版本状态。',
          href: activeDomain
            ? '/system?source=risk&tab=runlog&focus=system-version'
            : '/system?source=risk&tab=runlog',
        },
      ];
  }, [activeDomain, queryState.focus, queryState.scope, queryState.source, selectedDate]);

  const compatibilityHint = useMemo(() => {
    if (!data) return null;
    const statuses = Object.values(data.dataStatus);
    if (statuses.every(status => status === 'backend')) {
      return null;
    }
    return data.generatedAtText;
  }, [data]);

  return (
    <div className="risk-page" data-testid="risk-page">
      <RiskHeader
        title="风控中心"
        description="围绕交易闸门、风险评分、单票拆解和风险事件，统一查看当前风控结论。"
        tradeDate={data?.tradeDate ?? selectedDate}
        generatedAtText={data?.generatedAtText ?? '正在准备风控数据...'}
        sourceLabel={buildSourceLabel(queryState.source)}
        focusLabel={`聚焦：${queryState.focus ?? '未指定'}`}
        scopeLabel={buildScopeLabel(queryState.scope)}
      />

      <RiskOverviewStrip metrics={data?.metrics ?? []} />

      <section className="card">
        <div className="card-header">
          <span className="card-title">当前工作上下文</span>
          <span className="c-muted" style={{ fontSize: 12 }}>
            {data?.filters.map(filter => `${filter.label}：${filter.value}`).join(' / ') ?? '正在恢复当前风控视角。'}
          </span>
        </div>
      </section>

      {data ? <RiskTabs activeTab={queryState.tab} tabs={data.tabs} onChange={handleTabChange} /> : null}

      <div className="risk-layout">
        <div className="risk-main">
          <section className="card">
            <div className="card-header">
              <span className="card-title">{data?.tabs[queryState.tab].title ?? '风控结果'}</span>
              <span className="c-muted" style={{ fontSize: 12 }}>
                {data?.tabs[queryState.tab].description ?? '正在准备风控结果。'}
              </span>
            </div>

            {loading ? (
              <div className="risk-loading-state">
                <div className="spinner" />
                <span>正在加载风控数据...</span>
              </div>
            ) : null}

            {!loading && error ? (
              <div className="page-error">
                <div className="page-error-msg">风控数据加载失败</div>
                <div className="page-error-detail">{error}</div>
                <button className="retry-btn" onClick={refetch}>重新加载</button>
              </div>
            ) : null}

            {!loading && !error && compatibilityHint ? (
              <div className="risk-miss-banner">{compatibilityHint}</div>
            ) : null}

            {!loading && !error && feedback ? (
              <div className="risk-miss-banner">{feedback.text}</div>
            ) : null}

            {!loading && !error && data && queryState.tab === 'gate' ? (
              <GateBlockPanel
                rows={data.gateRows}
                selectedFocus={selectedFocus}
                onSelect={handleFocusChange}
                onOpenBreakdown={openBreakdown}
                onOpenSource={href => openHref(href, '当前没有可返回的来源页。')}
                emptyTitle={data.tabs.gate.emptyTitle}
                emptyText={data.tabs.gate.emptyText}
              />
            ) : null}

            {!loading && !error && data && queryState.tab === 'scores' ? (
              <RiskScorePanel
                rows={data.scoreRows}
                selectedFocus={selectedFocus}
                onSelect={handleFocusChange}
                onOpenBreakdown={openBreakdown}
                onOpenWatchlist={href => openHref(href, '当前股票没有观察池关联。')}
                onOpenPortfolio={href => openHref(href, '当前股票没有持仓中心关联。')}
                emptyTitle={data.tabs.scores.emptyTitle}
                emptyText={data.tabs.scores.emptyText}
              />
            ) : null}

            {!loading && !error && data && queryState.tab === 'breakdown' ? (
              <RiskBreakdownPanel
                row={activeBreakdownRow}
                emptyTitle={data.tabs.breakdown.emptyTitle}
                emptyText={data.tabs.breakdown.emptyText}
              />
            ) : null}

            {!loading && !error && data && queryState.tab === 'events' ? (
              <RiskEventFlowPanel
                rows={data.eventRows}
                selectedFocus={selectedFocus}
                onSelect={handleFocusChange}
                emptyTitle={data.tabs.events.emptyTitle}
                emptyText={data.tabs.events.emptyText}
              />
            ) : null}
          </section>
        </div>

        <aside className="risk-context">
          <RiskContextPanel
            context={context}
            actions={contextActions}
            onAction={action => openHref(action.href, action.note)}
            noFocusTitle="请选择一只股票查看上下文"
            noFocusText="先从闸门阻断、风险评分或风险事件中选中一只股票，这里会显示对应的风控结论和下一步建议。"
          />
        </aside>
      </div>
    </div>
  );
}
