import { useSearchParams } from 'react-router-dom';
import {
  buildSystemFocusQueryPatch,
  getSystemRows,
  getSystemTabTitle,
  loadSystemWorkspace,
} from '../../adapters/system';
import { useApiData } from '../../hooks/useApiData';
import type { ApiHealthRow, CoverageItemRow, PipelineStepRow, RunlogVersionRow, SystemRow, SystemTab } from '../../types/system';

function buildSourceHint(source: string) {
  if (source === 'dashboard') return '来自 Dashboard，可继续核对今日运行步骤、版本摘要和异常线索。';
  if (source === 'risk') return '来自风控中心，可继续核对风险判断依赖的数据、流程与版本状态。';
  if (source === 'execution') return '来自模拟执行，可继续核对执行判断依赖的接口与运行状态。';
  if (source === 'signals') return '来自 Signals，可继续核对信号判断依赖的系统状态和数据覆盖。';
  if (source === 'watchlist') return '来自观察池，可继续核对候选保留依赖的数据更新与运行状态。';
  if (source === 'portfolio') return '来自持仓中心，可继续核对持仓判断依赖的系统流程和版本快照。';
  return '当前为系统运行中心入口，可继续查看流程、数据、接口和版本摘要。';
}

function getRowMeta(row: SystemRow) {
  if (row.objectType === 'pipeline-step') {
    const pipelineRow = row as PipelineStepRow;
    return [
      { label: '执行主体', value: pipelineRow.owner },
      { label: '执行耗时', value: pipelineRow.duration },
      { label: '关联数据集', value: pipelineRow.affectedDataset },
      { label: '处理行数', value: pipelineRow.rowCount },
    ];
  }

  if (row.objectType === 'coverage-item') {
    const coverageRow = row as CoverageItemRow;
    return [
      { label: '覆盖率', value: coverageRow.coverageLabel },
      { label: '最新日期', value: coverageRow.latestTradeDate },
      { label: '期望日期', value: coverageRow.expectedDate },
      { label: '质量状态', value: coverageRow.dqStatus },
    ];
  }

  if (row.objectType === 'api-item') {
    const apiRow = row as ApiHealthRow;
    return [
      { label: '接口域', value: apiRow.domain },
      { label: '最近检查', value: apiRow.latestCheck },
      { label: 'HTTP', value: apiRow.httpStatus },
      { label: '延迟/说明', value: apiRow.responseHint },
    ];
  }

  const runlogRow = row as RunlogVersionRow;
  return [
    { label: '版本快照', value: runlogRow.versionLabel },
    { label: '更新时间', value: runlogRow.publishedAt },
    { label: '影响范围', value: runlogRow.scopeHint },
    { label: '异常等级', value: runlogRow.anomalyLevel },
  ];
}

export default function SystemPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { data: viewModel, loading, error } = useApiData(
    () => loadSystemWorkspace(searchParams),
    [searchParams.toString()],
  );

  function setTab(tab: SystemTab) {
    const next = new URLSearchParams(searchParams);
    next.set('tab', tab);
    setSearchParams(next);
  }

  function setFocus(row: SystemRow) {
    const next = new URLSearchParams(searchParams);
    const patch = buildSystemFocusQueryPatch(row);

    if (patch.focus !== undefined) next.set('focus', patch.focus);
    if (patch.step !== undefined) patch.step ? next.set('step', patch.step) : next.delete('step');
    if (patch.dataset !== undefined) patch.dataset ? next.set('dataset', patch.dataset) : next.delete('dataset');
    if (patch.api !== undefined) patch.api ? next.set('api', patch.api) : next.delete('api');

    setSearchParams(next);
  }

  if (loading || !viewModel) {
    return (
      <div className="domain-page system-page" data-testid="system-page">
        <section className="system-hero">
          <div className="system-hero-copy">
            <div className="page-kicker">系统运行中心</div>
            <h1>系统运行中心</h1>
            <p>集中查看流程运行、数据覆盖、接口健康和版本摘要。</p>
          </div>
        </section>
        <div className="page-banner">正在加载系统运行数据...</div>
      </div>
    );
  }

  const rows = getSystemRows(viewModel);
  const activeTabState = viewModel.tabStates[viewModel.query.tab];

  return (
    <div className="domain-page system-page" data-testid="system-page">
      <section className="system-hero">
        <div className="system-hero-copy">
          <div className="page-kicker">系统运行中心</div>
          <h1>{viewModel.title}</h1>
          <p>{viewModel.subtitle}</p>
        </div>
        <div className="system-flags">
          {viewModel.filterChips.map((chip) => (
            <span key={chip.key} className="system-mini-pill active">
              <span className="system-mini-pill-label">{chip.label}</span>
              <strong>{chip.value}</strong>
            </span>
          ))}
        </div>
        <div className="system-source-hint">{buildSourceHint(viewModel.query.source)}</div>
      </section>

      <section className="system-metrics">
        {viewModel.metrics.map((metric) => (
          <article key={metric.key} className="system-metric-card">
            <span>{metric.label}</span>
            <strong>{metric.value}</strong>
            <p>{metric.note}</p>
          </article>
        ))}
      </section>

      <section className="page-tabs system-tabs">
        {viewModel.tabs.map((tab) => (
          <button
            key={tab.key}
            type="button"
            className={tab.key === viewModel.query.tab ? 'page-tab active' : 'page-tab'}
            onClick={() => setTab(tab.key)}
          >
            <span className="system-tab-label">{tab.label}</span>
            <small className="system-tab-desc">{tab.description}</small>
          </button>
        ))}
      </section>

      <section className="system-workspace">
        <div className="system-main">
          <header className="section-header system-section-header">
            <div>
              <h2>{getSystemTabTitle(viewModel.query.tab)}</h2>
              <p>{viewModel.dataStateNote}</p>
            </div>
            <div className={`system-inline-state system-inline-state-${activeTabState.sourceMode}`}>
              <span className="system-inline-state-label">{activeTabState.label}</span>
              <span className="system-inline-state-note">{activeTabState.note}</span>
            </div>
          </header>

          {error ? <div className="page-banner warning">{error}</div> : null}
          {viewModel.focusMissNote ? <div className="page-banner warning">{viewModel.focusMissNote}</div> : null}

          {viewModel.dataState === 'unsupported' ? (
            <div className="empty-state">
              <h3>{viewModel.unsupportedState.title}</h3>
              <p>{viewModel.unsupportedState.description}</p>
            </div>
          ) : rows.length === 0 ? (
            <div className="empty-state">
              <h3>{viewModel.emptyState.title}</h3>
              <p>{viewModel.emptyState.description}</p>
            </div>
          ) : (
            <div className="system-list">
              {rows.map((row) => {
                const metaItems = getRowMeta(row);

                return (
                  <button
                    key={row.id}
                    type="button"
                    className={row.id === viewModel.selectedId ? 'system-row selected' : 'system-row'}
                    onClick={() => setFocus(row)}
                  >
                    <div className="system-row-top">
                      <div className="system-row-copy">
                        <strong>{row.title}</strong>
                        <p>{row.subtitle}</p>
                      </div>
                      <div className="system-status-pill">{row.stateLabel}</div>
                    </div>

                    <div className="system-row-meta">
                      {metaItems.map((item) => (
                        <div key={item.label} className="system-row-meta-item">
                          <span>{item.label}</span>
                          <strong>{item.value}</strong>
                        </div>
                      ))}
                    </div>

                    <div className="system-row-summary">{row.summary}</div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <aside className="system-context">
          {viewModel.context ? (
            <div className="risk-context-card system-context-card">
              <div className="risk-context-body">
                <header className="system-context-header">
                  <div className="system-context-kicker">当前工作上下文</div>
                  <h3>{viewModel.context.title}</h3>
                  <p>{viewModel.context.subtitle}</p>
                  <span>{viewModel.context.sourceSummary}</span>
                </header>

                {viewModel.context.sections.map((section) => (
                  <section key={section.title} className="system-context-section">
                    <h4>{section.title}</h4>
                    <div className="system-context-grid">
                      {section.items.map((item) => (
                        <div key={item.label} className="system-context-stat">
                          <span>{item.label}</span>
                          <strong>{item.value}</strong>
                        </div>
                      ))}
                    </div>
                  </section>
                ))}

                <section className="system-context-section">
                  <h4>下一步建议</h4>
                  <div className="system-next-steps">
                    {viewModel.context.nextSteps.map((step) => (
                      <article key={step.label} className="system-next-step">
                        <strong>{step.label}</strong>
                        <p>{step.note}</p>
                      </article>
                    ))}
                  </div>
                </section>
              </div>
            </div>
          ) : (
            <div className="risk-context-card system-context-card">
              <div className="risk-context-body">
                <div className="system-context-empty-kicker">当前工作上下文</div>
                <div className="system-context-empty-summary">
                  <span>{getSystemTabTitle(viewModel.query.tab)}</span>
                  <strong>{viewModel.filterChips.find((chip) => chip.key === 'source')?.value ?? '直接进入'}</strong>
                </div>
                <h3>{viewModel.noFocus.title}</h3>
                <p className="execution-empty-text">{viewModel.noFocus.description}</p>
                <div className="system-context-empty-list">
                  <div className="system-context-empty-item">
                    <strong>可查看内容</strong>
                    <span>流程步骤、数据覆盖、接口健康和运行日志与版本摘要。</span>
                  </div>
                  <div className="system-context-empty-item">
                    <strong>使用方式</strong>
                    <span>从左侧选择一个运行对象后，右侧会承接状态、来源说明和后续建议。</span>
                  </div>
                </div>
                <p className="system-context-empty-note">{buildSourceHint(viewModel.query.source)}</p>
              </div>
            </div>
          )}
        </aside>
      </section>
    </div>
  );
}
