import { useEffect, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { buildResearchQuery, loadResearchWorkspace } from '../../adapters/research';
import { buildResearchDetailHref } from '../../adapters/researchDetail';
import { useContextPanel } from '../../context/ContextPanelContext';
import { useApiData } from '../../hooks/useApiData';
import type { ResearchTab } from '../../types/research';
import { getStrategyDisplayName } from '../../utils/displayNames';

const TAB_ORDER: ResearchTab[] = ['summary', 'ic', 'attribution', 'resonance'];

function tabLabel(tab: ResearchTab) {
  if (tab === 'ic') return '因子 IC';
  if (tab === 'attribution') return '策略归因';
  if (tab === 'resonance') return '共振分析';
  return '回测中心';
}

export default function ResearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { closePanel } = useContextPanel();
  const query = useMemo(() => buildResearchQuery(searchParams), [searchParams]);
  const { data, loading, error, refetch } = useApiData(() => loadResearchWorkspace(query), [searchParams.toString()]);

  useEffect(() => {
    closePanel();
  }, [closePanel]);

  const activeTab = data?.tabs[query.tab] ?? data?.tabs.summary;
  const activeState = data?.tabStates[query.tab] ?? data?.tabStates.summary;

  const syncTab = (tab: ResearchTab) => {
    const next = new URLSearchParams(searchParams);
    if (tab === 'summary') next.delete('tab');
    else next.set('tab', tab);
    setSearchParams(next, { replace: true });
  };

  return (
    <div className="research-page" data-testid="research-page">
      <div className="page-header">
        <div>
          <div className="page-title">
            研究中心
            <span className="page-badge badge-blue">{tabLabel(query.tab)}</span>
          </div>
          <div className="page-desc">{data?.handoffText ?? '围绕回测中心、因子、归因和共振结果继续下钻。'}</div>
        </div>
      </div>

      <div className="page-tabs">
        {TAB_ORDER.map(tab => (
          <button key={tab} type="button" className={`page-tab-btn${query.tab === tab ? ' active' : ''}`} onClick={() => syncTab(tab)}>
            {tabLabel(tab)}
          </button>
        ))}
      </div>

      {activeState ? (
        <div className={`research-state-banner is-${activeState.status}`}>
          <div className="research-state-title">{activeState.label}</div>
          <div className="research-state-note">{activeState.note}</div>
        </div>
      ) : null}

      <div className="research-layout">
        <section className="card">
          <div className="card-header">
            <span className="card-title">{activeTab?.title ?? '研究总览'}</span>
            <span className="c-muted" style={{ fontSize: 12 }}>{activeTab?.description ?? '正在准备研究数据。'}</span>
          </div>

          {loading ? (
            <div className="page-loading"><div className="spinner" />加载中...</div>
          ) : null}

          {!loading && error ? (
            <div className="page-error">
              <div className="page-error-msg">研究中心加载失败</div>
              <div className="page-error-detail">{error}</div>
              <button className="retry-btn" onClick={refetch}>重试</button>
            </div>
          ) : null}

          {!loading && !error && data ? (
            <>
              <div className="stat-grid">
                {data.metrics.map(metric => (
                  <div key={metric.label} className="stat-card">
                    <div className="stat-label">{metric.label}</div>
                    <div className="stat-value">{metric.value}</div>
                    <div className="stat-sub">{metric.helper}</div>
                  </div>
                ))}
              </div>

              {query.tab === 'summary' ? (
                data.summaryRows.length > 0 ? (
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>策略</th>
                        <th className="right">样本数</th>
                        <th className="right">T+5</th>
                        <th className="right">胜率</th>
                        <th className="right">回撤</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.summaryRows.map(row => (
                        <tr key={row.id} onClick={() => navigate(buildResearchDetailHref('backtest', row.strategy, { ...query, strategy: row.strategy }))}>
                          <td>{getStrategyDisplayName(row.strategy) ?? row.strategy}</td>
                          <td className="right">{row.sampleN}</td>
                          <td className="right">{row.returns.T5.toFixed(2)}%</td>
                          <td className="right">{row.winRate.toFixed(1)}%</td>
                          <td className="right">{row.drawdown.toFixed(1)}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="risk-breakdown-empty">
                    <div className="risk-empty-title">{activeTab?.emptyTitle ?? '当前暂无结果'}</div>
                    <div className="risk-empty-text">{activeTab?.emptyText ?? '请调整条件后重试。'}</div>
                  </div>
                )
              ) : null}

              {query.tab === 'ic' ? (
                data.icSummaryRows.length > 0 ? (
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>因子</th>
                        <th>窗口</th>
                        <th className="right">IC</th>
                        <th className="right">ICIR</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.icSummaryRows.map(row => (
                        <tr key={row.id}>
                          <td>{row.factorName}</td>
                          <td>{row.horizon}</td>
                          <td className="right">{row.ic.toFixed(3)}</td>
                          <td className="right">{row.icir.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="risk-breakdown-empty">
                    <div className="risk-empty-title">{activeTab?.emptyTitle ?? '当前暂无结果'}</div>
                    <div className="risk-empty-text">{activeTab?.emptyText ?? '请调整条件后重试。'}</div>
                  </div>
                )
              ) : null}

              {query.tab === 'attribution' ? (
                data.attributionRows.length > 0 ? (
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>分组</th>
                        <th className="right">样本数</th>
                        <th className="right">平均收益</th>
                        <th className="right">胜率</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.attributionRows.map(row => (
                        <tr key={row.id}>
                          <td>{row.groupKey}</td>
                          <td className="right">{row.sampleN}</td>
                          <td className="right">{row.avgReturn.toFixed(2)}%</td>
                          <td className="right">{row.winRate.toFixed(1)}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="risk-breakdown-empty">
                    <div className="risk-empty-title">{activeTab?.emptyTitle ?? '当前暂无结果'}</div>
                    <div className="risk-empty-text">{activeTab?.emptyText ?? '请调整条件后重试。'}</div>
                  </div>
                )
              ) : null}

              {query.tab === 'resonance' ? (
                data.resonanceRows.length > 0 ? (
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>组合</th>
                        <th className="right">策略数</th>
                        <th className="right">样本数</th>
                        <th className="right">超额收益</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.resonanceRows.map(row => (
                        <tr key={row.id}>
                          <td>{row.strategyCombo}</td>
                          <td className="right">{row.crossStrategyCount}</td>
                          <td className="right">{row.sampleN}</td>
                          <td className="right">{row.excessReturn.toFixed(2)}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="risk-breakdown-empty">
                    <div className="risk-empty-title">{activeTab?.emptyTitle ?? '当前暂无结果'}</div>
                    <div className="risk-empty-text">{activeTab?.emptyText ?? '请调整条件后重试。'}</div>
                  </div>
                )
              ) : null}
            </>
          ) : null}
        </section>
      </div>
    </div>
  );
}
