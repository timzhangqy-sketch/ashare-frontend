import DomainPlaceholder from './DomainPlaceholder';

export default function WatchlistPage() {
  return (
    <DomainPlaceholder
      routeKey="watchlist"
      phaseNote="本页为“观察池”工作域占位页。当前观察池能力仍保留在兼容入口策略页内。"
      modules={[
        '跨策略观察池总览',
        '买卖动作队列',
        '入池天数与收益跟踪',
        '共享筛选与视图切换',
      ]}
      handoffLinks={[
        { label: '前往能量蓄势观察池', to: '/ignition' },
        { label: '前往异动策略观察池', to: '/retoc2' },
        { label: '前往形态策略观察池', to: '/pattern' },
      ]}
    />
  );
}
