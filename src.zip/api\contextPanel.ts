import api, {
  fetchKline,
  fetchRiskDetail,
  fetchStockDetail,
  type KlineItem,
  type RiskApiItem,
  type StockDetailResp,
} from './index';

async function tryContextGet<T>(paths: string[], params?: Record<string, string | number | undefined>): Promise<T> {
  let lastError: unknown;
  for (const path of paths) {
    try {
      const res = await api.get(path, { params });
      return res.data as T;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError;
}

export interface StockContextLifecycleResp {
  ts_code: string;
  entry_date?: string | null;
  pool_day?: number | null;
  gain_since_entry?: number | null;
  position_status?: string | null;
  lifecycle_label?: string | null;
}

export async function fetchStockContext(tsCode: string, tradeDate: string): Promise<StockDetailResp> {
  try {
    return await tryContextGet<StockDetailResp>([
      `/api/context/stock/${tsCode}`,
    ], { trade_date: tradeDate });
  } catch {
    return fetchStockDetail(tsCode, tradeDate);
  }
}

export async function fetchStockContextKline(tsCode: string): Promise<KlineItem[]> {
  try {
    const raw = await tryContextGet<unknown>([
      `/api/context/stock/${tsCode}/kline`,
    ]);
    if (Array.isArray(raw)) return raw as KlineItem[];
    if (raw && typeof raw === 'object' && Array.isArray((raw as { data?: unknown[] }).data)) {
      return (raw as { data: KlineItem[] }).data;
    }
    return [];
  } catch {
    return fetchKline(tsCode, 60);
  }
}

export async function fetchStockContextRisk(tsCode: string, tradeDate: string): Promise<RiskApiItem | null> {
  try {
    const raw = await tryContextGet<unknown>([
      `/api/context/stock/${tsCode}/risk`,
    ], { trade_date: tradeDate });
    if (!raw || typeof raw !== 'object') return null;
    if ('data' in (raw as Record<string, unknown>) && (raw as { data?: unknown }).data && typeof (raw as { data?: unknown }).data === 'object') {
      return (raw as { data: RiskApiItem }).data;
    }
    return raw as RiskApiItem;
  } catch {
    return fetchRiskDetail(tsCode, tradeDate);
  }
}

export async function fetchStockContextLifecycle(tsCode: string, tradeDate: string): Promise<StockContextLifecycleResp | null> {
  try {
    const raw = await tryContextGet<unknown>([
      `/api/context/stock/${tsCode}/lifecycle`,
    ], { trade_date: tradeDate });
    if (!raw || typeof raw !== 'object') return null;
    if ('data' in (raw as Record<string, unknown>) && (raw as { data?: unknown }).data && typeof (raw as { data?: unknown }).data === 'object') {
      return (raw as { data: StockContextLifecycleResp }).data;
    }
    return raw as StockContextLifecycleResp;
  } catch {
    const detail = await fetchStockDetail(tsCode, tradeDate);
    return {
      ts_code: tsCode,
      entry_date: detail.watchlist_entry_date ?? null,
      pool_day: detail.watchlist_pool_day ?? null,
      gain_since_entry: detail.watchlist_gain_since_entry ?? null,
      position_status: detail.in_watchlist ? 'in_watchlist' : null,
      lifecycle_label: detail.in_watchlist ? '观察中' : '未接入生命周期',
    };
  }
}
