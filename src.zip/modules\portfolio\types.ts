export type PortfolioTabKey = 'open' | 'closed' | 'transactions';

export interface PortfolioMetricVm {
  label: string;
  value: string;
  helper: string;
}

export interface PortfolioSummaryVm {
  title: string;
  description: string;
  metrics: PortfolioMetricVm[];
}

export interface PortfolioTabVm {
  label: string;
  title: string;
  description: string;
  emptyTitle: string;
  emptyText: string;
}

export interface PortfolioTransactionRowVm {
  id: number;
  portfolioId: number;
  tsCode: string;
  tradeDate: string;
  tradeType: string;
  tradeTypeLabel: string;
  price: number;
  shares: number;
  amount: number;
  triggerSource: string | null;
  triggerSourceLabel: string;
  notes: string | null;
}

export interface PortfolioActionShellVm {
  key: 'add' | 'reduce' | 'close';
  label: string;
  enabled: boolean;
  tone: 'primary' | 'neutral' | 'warning';
  note: string;
}

export interface PortfolioBaseRowVm {
  id: number;
  tsCode: string;
  name: string;
  status: 'open' | 'closed';
  statusLabel: string;
  sourceStrategy: string;
  sourceStrategyLabel: string;
  fromWatchlist: boolean;
  sourceHint: string;
  openDate: string;
  openPrice: number;
  shares: number;
  holdDays: number | null;
  latestClose: number | null;
  todayPnl: number | null;
  todayPnlPct: number | null;
  costAmount: number | null;
  marketValue: number | null;
  unrealizedPnl: number | null;
  unrealizedPnlPct: number | null;
  actionSignal: string | null;
  actionLabel: string;
  exitSuggestion: string;
  signalReason: string | null;
  riskHint: string;
  relatedTransactions: PortfolioTransactionRowVm[];
  rawActionSignal: string | null;
}

export interface PortfolioOpenRowVm extends PortfolioBaseRowVm {}

export interface PortfolioClosedRowVm extends PortfolioBaseRowVm {
  closeDate: string | null;
  closePrice: number | null;
  realizedPnl: number | null;
  realizedPnlPct: number | null;
  exitReason: string;
}

export interface PortfolioContextLinkVm {
  key: 'source' | 'watchlist' | 'transactions';
  label: string;
  enabled: boolean;
  note?: string;
}

export interface PortfolioContextVm {
  title: string;
  code: string;
  statusLabel: string;
  sourceStrategyLabel: string;
  sourceHint: string;
  sourceQueryLabel: string;
  sourceQueryValue: string;
  holdingFacts: Array<{ label: string; value: string }>;
  judgementFacts: Array<{ label: string; value: string }>;
  transactionSummary: string;
  relatedLinks: PortfolioContextLinkVm[];
  actionShells: PortfolioActionShellVm[];
}

export interface PortfolioTransactionPanelVm {
  title: string;
  description: string;
  relatedLabel: string;
  rows: PortfolioTransactionRowVm[];
  emptyTitle: string;
  emptyText: string;
}

export interface PortfolioWorkspaceVm {
  tradeDate: string;
  generatedAtText: string;
  tabs: Record<PortfolioTabKey, PortfolioTabVm>;
  summary: Record<PortfolioTabKey, PortfolioSummaryVm>;
  openRows: PortfolioOpenRowVm[];
  closedRows: PortfolioClosedRowVm[];
  transactions: PortfolioTransactionPanelVm;
}
