import { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import { fetchCrossStrategies } from '../api';

interface CrossStrategyContextType {
  crossMap: Record<string, string[]>;
}

const CrossStrategyContext = createContext<CrossStrategyContextType>({ crossMap: {} });

export function CrossStrategyProvider({ children }: { children: ReactNode }) {
  const [crossMap, setCrossMap] = useState<Record<string, string[]>>({});

  useEffect(() => {
    fetchCrossStrategies()
      .then(setCrossMap)
      .catch(() => {});
  }, []);

  return (
    <CrossStrategyContext.Provider value={{ crossMap }}>
      {children}
    </CrossStrategyContext.Provider>
  );
}

export function useCrossStrategy(): CrossStrategyContextType {
  return useContext(CrossStrategyContext);
}
