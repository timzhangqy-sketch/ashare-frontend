import type { ContextPanelLoadStatus, StockContextLifecycleData } from '../../../types/contextPanel';

interface StockContextLifecycleProps {
  status: ContextPanelLoadStatus;
  note: string;
  data: StockContextLifecycleData | null;
}

export default function StockContextLifecycle({ status, note, data }: StockContextLifecycleProps) {
  return (
    <section className="global-context-section">
      <div className="global-context-section-title">生命周期</div>
      <div className="global-context-inline-note">{note}</div>
      {status === 'loading' ? (
        <div className="global-context-empty">正在加载生命周期...</div>
      ) : data ? (
        <div className="global-context-stat-grid">
          <div className="global-context-stat-card">
            <span>当前阶段</span>
            <strong>{data.lifecycleLabel}</strong>
          </div>
          <div className="global-context-stat-card">
            <span>入池日期</span>
            <strong>{data.entryDate ?? '--'}</strong>
          </div>
          <div className="global-context-stat-card">
            <span>观察天数</span>
            <strong>{data.poolDay != null ? `${data.poolDay}` : '--'}</strong>
          </div>
          <div className="global-context-stat-card">
            <span>入池后收益</span>
            <strong>{data.gainSinceEntry != null ? `${data.gainSinceEntry > 0 ? '+' : ''}${data.gainSinceEntry.toFixed(2)}%` : '--'}</strong>
          </div>
          <div className="global-context-risk-copy">
            <span>持仓状态</span>
            <strong>{data.positionStatus ?? '--'}</strong>
          </div>
        </div>
      ) : (
        <div className="global-context-empty">当前没有可展示的生命周期信息。</div>
      )}
    </section>
  );
}
