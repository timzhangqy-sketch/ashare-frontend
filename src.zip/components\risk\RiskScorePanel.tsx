import type { RiskScoreRow } from '../../types/risk';

interface RiskScorePanelProps {
  rows: RiskScoreRow[];
  selectedFocus: string | null;
  onSelect: (tsCode: string) => void;
  onOpenBreakdown: (tsCode: string) => void;
  onOpenWatchlist: (href: string | null) => void;
  onOpenPortfolio: (href: string | null) => void;
  emptyTitle: string;
  emptyText: string;
}

export default function RiskScorePanel({
  rows,
  selectedFocus,
  onSelect,
  onOpenBreakdown,
  onOpenWatchlist,
  onOpenPortfolio,
  emptyTitle,
  emptyText,
}: RiskScorePanelProps) {
  return (
    <div className="risk-table-shell">
      <table className="data-table">
        <thead>
          <tr>
            <th>股票</th>
            <th>总分</th>
            <th>四维摘要</th>
            <th>最小上限</th>
            <th>最终仓位上限</th>
            <th>风险等级</th>
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr className="risk-table-empty-row">
              <td colSpan={6}>
                <div className="risk-empty-state">
                  <div className="risk-empty-title">{emptyTitle}</div>
                  <div className="risk-empty-text">{emptyText}</div>
                </div>
              </td>
            </tr>
          ) : (
            rows.map(row => (
              <tr
                key={row.id}
                className={selectedFocus === row.tsCode ? 'risk-table-row selected' : 'risk-table-row'}
                onClick={() => onSelect(row.tsCode)}
              >
                <td>
                  <div className="risk-cell-title">{row.name}</div>
                  <div className="risk-inline-meta">{row.tsCode}</div>
                </td>
                <td>{row.riskScoreTotal}</td>
                <td className="risk-cell-wrap">
                  财务 {row.riskScoreFinancial} / 市场 {row.riskScoreMarket} / 事件 {row.riskScoreEvent} / 合规 {row.riskScoreCompliance}
                </td>
                <td>{row.dimCap.toFixed(2)}</td>
                <td>
                  <div>{row.positionCapMultiplierFinal.toFixed(2)}</div>
                  <div className="risk-inline-meta">{row.recommendedPositionText}</div>
                </td>
                <td>
                  <div>{row.riskLevelLabel}</div>
                  <div className="risk-inline-actions">
                    <button
                      type="button"
                      className="risk-inline-link"
                      onClick={event => {
                        event.stopPropagation();
                        onOpenBreakdown(row.tsCode);
                      }}
                    >
                      查看拆解
                    </button>
                    <button
                      type="button"
                      className="risk-inline-link"
                      onClick={event => {
                        event.stopPropagation();
                        onOpenWatchlist(row.watchlistHref);
                      }}
                    >
                      查看观察池
                    </button>
                    <button
                      type="button"
                      className="risk-inline-link"
                      onClick={event => {
                        event.stopPropagation();
                        onOpenPortfolio(row.portfolioHref);
                      }}
                    >
                      查看持仓
                    </button>
                  </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
