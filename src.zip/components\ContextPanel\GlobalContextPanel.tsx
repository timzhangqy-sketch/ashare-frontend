import { useEffect, useState } from 'react';
import { useDate } from '../../context/DateContext';
import { loadStockContextViewModel } from '../../adapters/contextPanel';
import type {
  ContextPanelPayloadBase,
  ContextPanelState,
  StockContextPanelPayload,
  StockContextViewModel,
} from '../../types/contextPanel';
import StockContextActions from './sections/StockContextActions';
import StockContextBasic from './sections/StockContextBasic';
import StockContextHeader from './sections/StockContextHeader';
import StockContextKline from './sections/StockContextKline';
import StockContextLifecycle from './sections/StockContextLifecycle';
import StockContextRisk from './sections/StockContextRisk';
import StockContextTags from './sections/StockContextTags';

function readStockPayload(payload: ContextPanelState['payload']): StockContextPanelPayload {
  if (!payload || typeof payload !== 'object') return {};
  return payload as StockContextPanelPayload;
}

function GenericContextPanel({
  panel,
  payload,
}: {
  panel: ContextPanelState;
  payload: ContextPanelPayloadBase;
}) {
  return (
    <aside className="context-panel-slot" aria-label="全局上下文">
      <div className="context-panel-card global-context-panel" data-testid="context-panel">
        <div className="context-panel-kicker">全局上下文</div>
        <div className="context-panel-title">{payload.title || panel.entityKey}</div>
        <p className="context-panel-copy">
          {payload.subtitle || '当前对象会在这里承接统一上下文。'}
        </p>
        {payload.summary ? <p className="context-panel-copy">{payload.summary}</p> : null}
      </div>
    </aside>
  );
}

export default function GlobalContextPanel({ panel }: { panel: ContextPanelState }) {
  const { selectedDate } = useDate();
  const [viewModel, setViewModel] = useState<StockContextViewModel | null>(null);
  const [loading, setLoading] = useState(false);

  const payload = readStockPayload(panel.payload);
  const stockCode = payload.tsCode ?? panel.tsCode ?? panel.focus ?? panel.entityKey;

  useEffect(() => {
    if (!panel.isOpen || panel.entityType !== 'stock' || !stockCode) {
      setViewModel(null);
      setLoading(false);
      return;
    }

    let cancelled = false;
    setLoading(true);

    loadStockContextViewModel(panel, selectedDate)
      .then(result => {
        if (cancelled) return;
        setViewModel(result);
        setLoading(false);
      })
      .catch(() => {
        if (cancelled) return;
        setViewModel(null);
        setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [panel, selectedDate, stockCode]);

  if (!panel.isOpen || !panel.entityType || !panel.entityKey) return null;

  if (panel.entityType !== 'stock' || !stockCode) {
    return <GenericContextPanel panel={panel} payload={payload} />;
  }

  if (!viewModel && loading) {
    return (
      <aside className="context-panel-slot" aria-label="全局上下文">
        <div className="context-panel-card global-context-panel" data-testid="context-panel">
          <div className="context-panel-kicker">全局上下文</div>
          <div className="context-panel-title">{payload.name ?? stockCode}</div>
          <div className="global-context-empty">正在加载股票上下文...</div>
        </div>
      </aside>
    );
  }

  const title = viewModel?.title ?? payload.name ?? payload.title ?? stockCode;
  const sourceStrategy = viewModel?.sourceStrategy ?? payload.sourceStrategy ?? null;

  return (
    <aside className="context-panel-slot" aria-label="全局上下文">
      <div className="context-panel-card global-context-panel" data-testid="context-panel">
        <StockContextHeader
          name={title}
          tsCode={stockCode}
          sourcePage={panel.sourcePage}
          sourceStrategy={sourceStrategy}
        />
        {viewModel ? <div className="global-context-inline-note">{viewModel.statusText}</div> : null}
        <StockContextTags tags={viewModel?.tags ?? payload.tags ?? []} />
        <StockContextBasic
          data={viewModel?.main ?? null}
          loading={loading}
          summaryItems={viewModel?.summaryItems ?? payload.summaryItems ?? []}
        />
        <StockContextKline
          status={viewModel?.kline.status ?? (loading ? 'loading' : 'empty')}
          note={viewModel?.kline.note ?? '当前没有可展示的 K 线摘要。'}
          data={viewModel?.kline.data ?? null}
        />
        <StockContextRisk
          status={viewModel?.risk.status ?? (loading ? 'loading' : 'empty')}
          note={viewModel?.risk.note ?? '当前没有可展示的风险拆解。'}
          data={viewModel?.risk.data ?? null}
        />
        <StockContextLifecycle
          status={viewModel?.lifecycle.status ?? (loading ? 'loading' : 'empty')}
          note={viewModel?.lifecycle.note ?? '当前没有可展示的生命周期信息。'}
          data={viewModel?.lifecycle.data ?? null}
        />
        <StockContextActions actions={viewModel?.actions ?? payload.actions ?? []} />
      </div>
    </aside>
  );
}
