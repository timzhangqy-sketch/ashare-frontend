import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import StockDrawer from '../components/Drawer/StockDrawer';
import { loadSignalsWorkspace } from '../adapters/signals';
import { getRouteMetaByKey } from '../config/routeMeta';
import { useContextPanel } from '../context/ContextPanelContext';
import { useDate } from '../context/DateContext';
import { useApiData } from '../hooks/useApiData';
import type { StockDetail } from '../types/stock';
import type { StockContextPanelPayload } from '../types/contextPanel';
import { getStrategyDisplayName } from '../utils/displayNames';
import { buildResearchHref } from '../utils/researchHandoff';
import {
  signalsTabOrder,
  type SignalsActionKind,
  type SignalsBuyRowVm,
  type SignalsDataOrigin,
  type SignalsFlowRowVm,
  type SignalsResonanceRowVm,
  type SignalsSellRowVm,
  type SignalsSourceNoteVm,
  type SignalsTabKey,
  type SignalsWorkspaceVm,
} from '../types/signals';
import { getMockDetail } from '../utils/score';

const signalsMeta = getRouteMetaByKey('signals');

type SignalsRowVm = SignalsBuyRowVm | SignalsSellRowVm | SignalsResonanceRowVm | SignalsFlowRowVm;
type TabSelectionMap = Partial<Record<SignalsTabKey, string>>;

interface SignalsActionVm {
  label: string;
  kind: SignalsActionKind;
  onClick?: () => void;
  disabled?: boolean;
}

interface SignalsSelectionVm {
  title: string;
  tsCode: string;
  signal: string;
  source: string;
  inWatchlist: boolean;
  inPortfolio: boolean;
  summary: string;
  tags: string[];
  actions: SignalsActionVm[];
}

interface ActionFeedbackVm {
  tone: 'info' | 'success' | 'warning';
  text: string;
}

function normalizeTab(value: string | null): SignalsTabKey {
  return signalsTabOrder.includes(value as SignalsTabKey) ? (value as SignalsTabKey) : 'buy';
}

function originClassName(origin: SignalsDataOrigin): string {
  return `signals-origin-${origin}`;
}

function formatNumber(value: number | null | undefined, digits = 2): string {
  return value == null ? '--' : value.toFixed(digits);
}

function formatSigned(value: number | null | undefined, suffix = '', digits = 2): string {
  if (value == null) return '--';
  return `${value > 0 ? '+' : ''}${value.toFixed(digits)}${suffix}`;
}

function getActiveRows(workspace: SignalsWorkspaceVm, activeTab: SignalsTabKey): SignalsRowVm[] {
  if (activeTab === 'buy') return workspace.tabs.buy.rows;
  if (activeTab === 'sell') return workspace.tabs.sell.rows;
  if (activeTab === 'resonance') return workspace.tabs.resonance.rows;
  return workspace.tabs.flow.rows;
}

function getStrategyMeta(strategySource: string): { path: string; strategy: string } | null {
  const value = strategySource.toUpperCase();
  if (value.includes('VOL') || value.includes('IGNITE')) return { path: '/dashboard', strategy: 'VOL_SURGE' };
  if (value.includes('RETOC2')) return { path: '/retoc2', strategy: 'RETOC2' };
  if (value.includes('T2UP9')) return { path: '/pattern', strategy: 'PATTERN_T2UP9' };
  if (value.includes('GREEN10')) return { path: '/pattern', strategy: 'PATTERN_GREEN10' };
  if (value.includes('PATTERN')) return { path: '/pattern', strategy: value };
  return null;
}

function displayStrategyName(value: string | null | undefined): string {
  if (!value) return '--';
  return getStrategyDisplayName(value) ?? value;
}

function buildStrategyHref(strategySource: string, tsCode: string): string | null {
  const meta = getStrategyMeta(strategySource);
  if (!meta) return null;
  const params = new URLSearchParams({
    ts_code: tsCode,
    source: 'signals',
    strategy: meta.strategy,
  });
  return `${meta.path}?${params.toString()}`;
}

function buildExecutionHref(tsCode: string, strategy: string | null) {
  const params = new URLSearchParams({
    tab: 'orders',
    source: 'signals',
    focus: tsCode,
  });
  if (strategy) params.set('strategy', strategy);
  return `/execution?${params.toString()}`;
}

function getRowStrategies(row: SignalsRowVm): string[] {
  if ('strategies' in row) return row.strategies;
  if ('strategySource' in row) return [row.strategySource];
  if ('sourceStrategy' in row) return [row.sourceStrategy];
  return [(row as SignalsFlowRowVm).strategySource];
}

function buildStockDetail(row: SignalsRowVm): StockDetail {
  const close = 'latestClose' in row ? row.latestClose ?? 0 : 'close' in row ? row.close ?? 0 : 0;
  const changePct = 'pctChg' in row ? row.pctChg ?? 0 : 'todayPnl' in row ? row.todayPnl ?? 0 : 0;
  return getMockDetail(row.tsCode, row.name, getRowStrategies(row), close, changePct);
}

function findRowByTsCode(rows: SignalsRowVm[], tsCode: string | null): SignalsRowVm | null {
  if (!tsCode) return null;
  return rows.find(row => row.tsCode === tsCode) ?? null;
}

function buildSignalsContextPayload(
  row: SignalsRowVm,
  activeTab: SignalsTabKey,
  tradeDate: string,
  selectionVm: SignalsSelectionVm | null,
  openDetail: (target: SignalsRowVm, autoOpenBuyForm?: boolean) => void,
  jumpTo: (href: string | null, fallbackText: string) => void,
): StockContextPanelPayload {
  const primaryStrategy =
    getRowStrategies(row)[0] ?? null;

  const researchHref = buildResearchHref({
    source: 'signals',
    focus: row.tsCode,
    strategy: primaryStrategy,
    resonance: 'strategyCount' in row ? String(row.strategyCount) : undefined,
    tradeDate,
    detailRoute: activeTab === 'resonance' && 'strategies' in row && row.strategies.length > 0 ? 'resonance' : primaryStrategy ? 'backtest' : null,
    detailKey: activeTab === 'resonance' && 'strategies' in row && row.strategies.length > 0 ? row.strategies.join('+') : primaryStrategy,
  });

  const tags = [
    { label: activeTab === 'buy' ? '今日买点' : activeTab === 'sell' ? '今日卖点' : activeTab === 'resonance' ? '多策略共振' : '策略触发流', tone: 'source' as const },
    ...(selectionVm?.tags ?? []).map(tag => ({ label: tag, tone: 'state' as const })),
  ];

  const summaryItems = activeTab === 'buy'
    ? [
        { label: '来源策略', value: displayStrategyName((row as SignalsBuyRowVm).strategySource) },
        { label: '当前信号', value: (row as SignalsBuyRowVm).signalType },
        { label: '状态', value: `${(row as SignalsBuyRowVm).inWatchlist ? '观察池' : '未入池'} / ${(row as SignalsBuyRowVm).inPortfolio ? '组合中' : '未入组合'}` },
      ]
    : activeTab === 'sell'
      ? [
          { label: '来源策略', value: displayStrategyName((row as SignalsSellRowVm).sourceStrategy) },
          { label: '退出信号', value: (row as SignalsSellRowVm).actionSignal },
          { label: '持有天数', value: (row as SignalsSellRowVm).holdDays != null ? `${(row as SignalsSellRowVm).holdDays} 天` : '--' },
        ]
      : activeTab === 'resonance'
        ? [
            { label: '共振策略', value: (row as SignalsResonanceRowVm).strategies.map(strategy => displayStrategyName(strategy)).join(' / ') },
            { label: '策略数', value: String((row as SignalsResonanceRowVm).strategyCount) },
            { label: '当前信号', value: (row as SignalsResonanceRowVm).latestSignal },
          ]
        : [
            { label: '事件类型', value: (row as SignalsFlowRowVm).eventType },
            { label: '来源策略', value: displayStrategyName((row as SignalsFlowRowVm).strategySource) },
            { label: '后续动作', value: (row as SignalsFlowRowVm).followAction },
          ];

  return {
    title: row.name,
    name: row.name,
    tsCode: row.tsCode,
    sourceStrategy: primaryStrategy,
    subtitle: selectionVm?.signal ?? '当前股票上下文',
    summary: selectionVm?.summary ?? '由 Signals 工作域统一承接的股票上下文。',
    tags,
    summaryItems,
    actions: [
      {
        label: '查看详情',
        onClick: () => openDetail(row),
        note: '继续使用原有详情抽屉。',
      },
      {
        label: '查看研究',
        href: researchHref,
        note: '跳转到 Research 工作域。',
      },
      {
        label: '去模拟执行',
        href: buildExecutionHref(row.tsCode, primaryStrategy),
        note: '跳转到模拟执行工作域。',
      },
      {
        label: '查看来源策略',
        onClick: () => jumpTo(buildStrategyHref(primaryStrategy ?? '', row.tsCode), '当前条目没有可识别的来源策略页。'),
        disabled: !buildStrategyHref(primaryStrategy ?? '', row.tsCode),
        note: primaryStrategy ? '继续查看来源策略页面。' : '当前条目没有可识别的来源策略页。',
      },
    ],
  };
}

function CompactSourceBadge({ note }: { note: SignalsSourceNoteVm }) {
  return <span className={`signals-origin-badge ${originClassName(note.origin)}`}>{note.label}</span>;
}

function ActionButton({ action }: { action: SignalsActionVm }) {
  return (
    <button
      type="button"
      className={`signals-action-btn ${action.kind}`}
      onClick={action.onClick}
      disabled={action.disabled}
    >
      <span>{action.label}</span>
      <span className="signals-action-kind">
        {action.kind === 'execute' ? '执行' : action.kind === 'jump' ? '跳转' : '占位'}
      </span>
    </button>
  );
}

function RowActionGroup({ actions }: { actions: SignalsActionVm[] }) {
  return (
    <div className="signals-row-actions">
      {actions.map(action => (
        <ActionButton key={`${action.label}-${action.kind}`} action={action} />
      ))}
    </div>
  );
}

function getTableColumns(activeTab: SignalsTabKey): string[] {
  if (activeTab === 'buy') return ['股票', '来源策略', '核心信号', '现价 / 涨跌', '换手 / 共振', '状态', '来源', '动作'];
  if (activeTab === 'sell') return ['股票', '来源策略', '卖点信号', '持有 / 现价', '今日 / 浮盈亏', '原因', '来源', '动作'];
  if (activeTab === 'resonance') return ['股票', '策略组合', '策略数', '最新信号', '现价 / 涨跌', '状态', '来源', '动作'];
  return ['时间', '事件', '来源策略', '股票', '信号', '后续动作', '动作'];
}

function buildSelectionVm(
  row: SignalsRowVm | null,
  activeTab: SignalsTabKey,
  tradeDate: string,
  jumpTo: (href: string | null, fallbackText: string) => void,
  openDetail: (target: SignalsRowVm, autoOpenBuyForm?: boolean) => void,
  onPlaceholder: (text: string) => void,
): SignalsSelectionVm | null {
  if (!row) return null;

  if (activeTab === 'buy') {
    const buyRow = row as SignalsBuyRowVm;
    const href = buildStrategyHref(buyRow.strategySource, buyRow.tsCode);
    return {
      title: buyRow.name,
      tsCode: buyRow.tsCode,
      signal: buyRow.signalType,
      source: displayStrategyName(buyRow.strategySource),
      inWatchlist: buyRow.inWatchlist,
      inPortfolio: buyRow.inPortfolio,
      summary: `${buyRow.signalStrength}，共振 ${buyRow.crossStrategyCount}`,
      tags: [
        buyRow.sourceLabel,
        buyRow.turnoverRate != null ? `换手 ${formatNumber(buyRow.turnoverRate)}%` : '换手待补',
      ],
      actions: [
        { label: '查看详情', kind: 'execute', onClick: () => openDetail(buyRow) },
        { label: '买入入口', kind: 'execute', onClick: () => openDetail(buyRow, true) },
        {
          label: '查看研究',
          kind: 'jump',
          onClick: () => jumpTo(buildResearchHref({
            source: 'signals',
            focus: buyRow.tsCode,
            strategy: buyRow.strategySource,
            tradeDate,
            detailRoute: buyRow.strategySource ? 'backtest' : null,
            detailKey: buyRow.strategySource,
          }), ''),
        },
        {
          label: '去模拟执行',
          kind: 'jump',
          onClick: () => jumpTo(buildExecutionHref(buyRow.tsCode, buyRow.strategySource), ''),
        },
        {
          label: '原始策略页',
          kind: href ? 'jump' : 'placeholder',
          onClick: href ? () => jumpTo(href, '') : () => onPlaceholder('当前买点没有可识别的来源策略页。'),
        },
      ],
    };
  }

  if (activeTab === 'sell') {
    const sellRow = row as SignalsSellRowVm;
    return {
      title: sellRow.name,
      tsCode: sellRow.tsCode,
      signal: sellRow.actionSignal,
      source: displayStrategyName(sellRow.sourceStrategy),
      inWatchlist: false,
      inPortfolio: true,
      summary: `持有 ${sellRow.holdDays ?? '--'} 天，浮盈亏 ${formatSigned(sellRow.unrealizedPnl)}`,
      tags: [sellRow.sourceLabel, sellRow.signalReason],
      actions: [
        { label: '查看详情', kind: 'execute', onClick: () => openDetail(sellRow) },
        {
          label: '查看研究',
          kind: 'jump',
          onClick: () => jumpTo(buildResearchHref({
            source: 'signals',
            focus: sellRow.tsCode,
            strategy: sellRow.sourceStrategy,
            tradeDate,
            detailRoute: sellRow.sourceStrategy ? 'backtest' : null,
            detailKey: sellRow.sourceStrategy,
          }), ''),
        },
        {
          label: '去模拟执行',
          kind: 'jump',
          onClick: () => jumpTo(buildExecutionHref(sellRow.tsCode, sellRow.sourceStrategy), ''),
        },
        {
          label: '跳组合',
          kind: 'jump',
          onClick: () => jumpTo(`/portfolio?source=signals&ts_code=${encodeURIComponent(sellRow.tsCode)}`, ''),
        },
        {
          label: '卖出复核',
          kind: 'placeholder',
          onClick: () => onPlaceholder('卖出复核尚未接正式流程，当前保留为占位入口。'),
        },
      ],
    };
  }

  if (activeTab === 'resonance') {
    const resonanceRow = row as SignalsResonanceRowVm;
    const href = buildStrategyHref(resonanceRow.strategies[0] ?? '', resonanceRow.tsCode);
    return {
      title: resonanceRow.name,
      tsCode: resonanceRow.tsCode,
      signal: resonanceRow.latestSignal,
      source: resonanceRow.strategies.map(strategy => displayStrategyName(strategy)).join(' / '),
      inWatchlist: resonanceRow.inWatchlist,
      inPortfolio: resonanceRow.inPortfolio,
      summary: `${resonanceRow.strategyCount} 个策略共振`,
      tags: [
        resonanceRow.sourceLabel,
        resonanceRow.close != null ? `现价 ${formatNumber(resonanceRow.close)}` : '价格待补',
      ],
      actions: [
        { label: '查看详情', kind: 'execute', onClick: () => openDetail(resonanceRow) },
        {
          label: '查看研究',
          kind: 'jump',
          onClick: () => jumpTo(buildResearchHref({
            source: 'signals',
            focus: resonanceRow.tsCode,
            strategy: resonanceRow.strategies[0] ?? null,
            resonance: String(resonanceRow.strategyCount),
            tradeDate,
            detailRoute: resonanceRow.strategies.length > 0 ? 'resonance' : null,
            detailKey: resonanceRow.strategies.length > 0 ? resonanceRow.strategies.join('+') : null,
          }), ''),
        },
        {
          label: '去模拟执行',
          kind: 'jump',
          onClick: () => jumpTo(buildExecutionHref(resonanceRow.tsCode, resonanceRow.strategies[0] ?? null), ''),
        },
        {
          label: '来源策略页',
          kind: href ? 'jump' : 'placeholder',
          onClick: href ? () => jumpTo(href, '') : () => onPlaceholder('当前共振条目没有可识别的来源策略页。'),
        },
        { label: '买入入口', kind: 'execute', onClick: () => openDetail(resonanceRow, true) },
      ],
    };
  }

  const flowRow = row as SignalsFlowRowVm;
  return {
    title: flowRow.name,
    tsCode: flowRow.tsCode,
    signal: flowRow.eventType,
    source: displayStrategyName(flowRow.strategySource),
    inWatchlist: flowRow.origin === 'primary',
    inPortfolio: flowRow.followAction.toLowerCase().includes('portfolio') || flowRow.followAction.includes('卖'),
    summary: `${flowRow.timeLabel} / ${flowRow.followAction}`,
    tags: [flowRow.sourceLabel, flowRow.signalLabel],
    actions: [
      { label: '关联股票详情', kind: 'execute', onClick: () => openDetail(flowRow) },
      {
        label: '查看研究',
        kind: 'jump',
        onClick: () => jumpTo(buildResearchHref({
          source: 'signals',
          focus: flowRow.tsCode,
          strategy: flowRow.strategySource,
          tradeDate,
          detailRoute: flowRow.strategySource ? 'backtest' : null,
          detailKey: flowRow.strategySource,
        }), ''),
      },
      {
        label: '去模拟执行',
        kind: 'jump',
        onClick: () => jumpTo(buildExecutionHref(flowRow.tsCode, flowRow.strategySource), ''),
      },
      {
        label: '事件流升级',
        kind: 'placeholder',
        onClick: () => onPlaceholder('策略触发流当前仍为聚合视图，正式事件流尚未接入。'),
      },
    ],
  };
}

function renderTableRows(
  activeTab: SignalsTabKey,
  rows: SignalsRowVm[],
  selectedCode: string | null,
  tradeDate: string | null,
  onSelect: (row: SignalsRowVm) => void,
  openDetail: (row: SignalsRowVm, autoOpenBuyForm?: boolean) => void,
  jumpTo: (href: string | null, fallbackText: string) => void,
  onPlaceholder: (text: string) => void,
) {
  return rows.map(row => {
    let actions: SignalsActionVm[] = [];

    if (activeTab === 'buy') {
      const buyRow = row as SignalsBuyRowVm;
      const href = buildStrategyHref(buyRow.strategySource, buyRow.tsCode);
      actions = [
        { label: '详情', kind: 'execute', onClick: () => openDetail(buyRow) },
        { label: '买入', kind: 'execute', onClick: () => openDetail(buyRow, true) },
        {
          label: '研究',
          kind: 'jump',
          onClick: () => jumpTo(buildResearchHref({
            source: 'signals',
            focus: buyRow.tsCode,
            strategy: buyRow.strategySource,
            tradeDate,
            detailRoute: buyRow.strategySource ? 'backtest' : null,
            detailKey: buyRow.strategySource,
          }), ''),
        },
        {
          label: '模拟执行',
          kind: 'jump',
          onClick: () => jumpTo(buildExecutionHref(buyRow.tsCode, buyRow.strategySource), ''),
        },
        {
          label: '策略页',
          kind: href ? 'jump' : 'placeholder',
          onClick: href ? () => jumpTo(href, '') : () => onPlaceholder('当前行没有可识别的来源策略页。'),
        },
      ];
    } else if (activeTab === 'sell') {
      const sellRow = row as SignalsSellRowVm;
      actions = [
        { label: '详情', kind: 'execute', onClick: () => openDetail(sellRow) },
        {
          label: '研究',
          kind: 'jump',
          onClick: () => jumpTo(buildResearchHref({
            source: 'signals',
            focus: sellRow.tsCode,
            strategy: sellRow.sourceStrategy,
            tradeDate,
            detailRoute: sellRow.sourceStrategy ? 'backtest' : null,
            detailKey: sellRow.sourceStrategy,
          }), ''),
        },
        {
          label: '模拟执行',
          kind: 'jump',
          onClick: () => jumpTo(buildExecutionHref(sellRow.tsCode, sellRow.sourceStrategy), ''),
        },
        { label: '组合', kind: 'jump', onClick: () => jumpTo(`/portfolio?source=signals&ts_code=${encodeURIComponent(sellRow.tsCode)}`, '') },
        { label: '复核', kind: 'placeholder', onClick: () => onPlaceholder('卖出复核尚未接正式流程，当前保留为占位入口。') },
      ];
    } else if (activeTab === 'resonance') {
      const resonanceRow = row as SignalsResonanceRowVm;
      const href = buildStrategyHref(resonanceRow.strategies[0] ?? '', resonanceRow.tsCode);
      actions = [
        { label: '详情', kind: 'execute', onClick: () => openDetail(resonanceRow) },
        {
          label: '研究',
          kind: 'jump',
          onClick: () => jumpTo(buildResearchHref({
            source: 'signals',
            focus: resonanceRow.tsCode,
            strategy: resonanceRow.strategies[0] ?? null,
            resonance: String(resonanceRow.strategyCount),
            tradeDate,
            detailRoute: resonanceRow.strategies.length > 0 ? 'resonance' : null,
            detailKey: resonanceRow.strategies.length > 0 ? resonanceRow.strategies.join('+') : null,
          }), ''),
        },
        {
          label: '模拟执行',
          kind: 'jump',
          onClick: () => jumpTo(buildExecutionHref(resonanceRow.tsCode, resonanceRow.strategies[0] ?? null), ''),
        },
        {
          label: '策略页',
          kind: href ? 'jump' : 'placeholder',
          onClick: href ? () => jumpTo(href, '') : () => onPlaceholder('当前共振条目没有可识别的来源策略页。'),
        },
        { label: '买入', kind: 'execute', onClick: () => openDetail(resonanceRow, true) },
      ];
    } else {
      const flowRow = row as SignalsFlowRowVm;
      actions = [
        { label: '详情', kind: 'execute', onClick: () => openDetail(flowRow) },
        {
          label: '研究',
          kind: 'jump',
          onClick: () => jumpTo(buildResearchHref({
            source: 'signals',
            focus: flowRow.tsCode,
            strategy: flowRow.strategySource,
            tradeDate,
            detailRoute: flowRow.strategySource ? 'backtest' : null,
            detailKey: flowRow.strategySource,
          }), ''),
        },
        {
          label: '模拟执行',
          kind: 'jump',
          onClick: () => jumpTo(buildExecutionHref(flowRow.tsCode, flowRow.strategySource), ''),
        },
        { label: '升级', kind: 'placeholder', onClick: () => onPlaceholder('策略触发流当前仍为聚合视图，正式事件流尚未接入。') },
      ];
    }

    return (
      <tr
        key={`${activeTab}-${row.id}`}
        className={selectedCode === row.tsCode ? 'signals-table-row selected' : 'signals-table-row'}
        onClick={() => onSelect(row)}
      >
        {activeTab === 'buy' ? (
          <>
            <td><div className="signals-cell-title">{row.name}</div><div className="signals-inline-meta">{row.tsCode}</div></td>
            <td>{displayStrategyName((row as SignalsBuyRowVm).strategySource)}</td>
            <td><div>{(row as SignalsBuyRowVm).signalType}</div><div className="signals-inline-meta">{(row as SignalsBuyRowVm).signalStrength}</div></td>
            <td className="right"><div>{formatNumber((row as SignalsBuyRowVm).close)}</div><div className="signals-inline-meta">{formatSigned((row as SignalsBuyRowVm).pctChg, '%')}</div></td>
            <td className="right"><div>{(row as SignalsBuyRowVm).turnoverRate != null ? `${formatNumber((row as SignalsBuyRowVm).turnoverRate)}%` : '--'}</div><div className="signals-inline-meta">共振 {(row as SignalsBuyRowVm).crossStrategyCount}</div></td>
            <td><div className="signals-status-stack"><span className={`signals-mini-pill${(row as SignalsBuyRowVm).inWatchlist ? ' active' : ''}`}>观察池</span><span className={`signals-mini-pill${(row as SignalsBuyRowVm).inPortfolio ? ' active' : ''}`}>组合</span></div></td>
            <td><div className={`signals-origin-badge ${originClassName((row as SignalsBuyRowVm).origin)}`}>{(row as SignalsBuyRowVm).sourceLabel}</div></td>
          </>
        ) : null}
        {activeTab === 'sell' ? (
          <>
            <td><div className="signals-cell-title">{row.name}</div><div className="signals-inline-meta">{row.tsCode}</div></td>
            <td>{displayStrategyName((row as SignalsSellRowVm).sourceStrategy)}</td>
            <td>{(row as SignalsSellRowVm).actionSignal}</td>
            <td className="right"><div>{(row as SignalsSellRowVm).holdDays != null ? `${(row as SignalsSellRowVm).holdDays} 天` : '--'}</div><div className="signals-inline-meta">{formatNumber((row as SignalsSellRowVm).latestClose)}</div></td>
            <td className="right"><div>{formatSigned((row as SignalsSellRowVm).todayPnl)}</div><div className="signals-inline-meta">{formatSigned((row as SignalsSellRowVm).unrealizedPnl)}</div></td>
            <td className="signals-cell-wrap">{(row as SignalsSellRowVm).signalReason}</td>
            <td><div className={`signals-origin-badge ${originClassName((row as SignalsSellRowVm).origin)}`}>{(row as SignalsSellRowVm).sourceLabel}</div></td>
          </>
        ) : null}
        {activeTab === 'resonance' ? (
          <>
            <td><div className="signals-cell-title">{row.name}</div><div className="signals-inline-meta">{row.tsCode}</div></td>
            <td className="signals-cell-wrap">{(row as SignalsResonanceRowVm).strategies.map(strategy => displayStrategyName(strategy)).join(' / ')}</td>
            <td className="center">{(row as SignalsResonanceRowVm).strategyCount}</td>
            <td>{(row as SignalsResonanceRowVm).latestSignal}</td>
            <td className="right"><div>{formatNumber((row as SignalsResonanceRowVm).close)}</div><div className="signals-inline-meta">{formatSigned((row as SignalsResonanceRowVm).pctChg, '%')}</div></td>
            <td><div className="signals-status-stack"><span className={`signals-mini-pill${(row as SignalsResonanceRowVm).inWatchlist ? ' active' : ''}`}>观察池</span><span className={`signals-mini-pill${(row as SignalsResonanceRowVm).inPortfolio ? ' active' : ''}`}>组合</span></div></td>
            <td><div className={`signals-origin-badge ${originClassName((row as SignalsResonanceRowVm).origin)}`}>{(row as SignalsResonanceRowVm).sourceLabel}</div></td>
          </>
        ) : null}
        {activeTab === 'flow' ? (
          <>
            <td>{(row as SignalsFlowRowVm).timeLabel}</td>
            <td>{(row as SignalsFlowRowVm).eventType}</td>
            <td>{displayStrategyName((row as SignalsFlowRowVm).strategySource)}</td>
            <td><div className="signals-cell-title">{row.name}</div><div className="signals-inline-meta">{row.tsCode}</div></td>
            <td>{(row as SignalsFlowRowVm).signalLabel}</td>
            <td><div>{(row as SignalsFlowRowVm).followAction}</div><div className={`signals-origin-badge ${originClassName((row as SignalsFlowRowVm).origin)}`}>{(row as SignalsFlowRowVm).sourceLabel}</div></td>
          </>
        ) : null}
        <td onClick={event => event.stopPropagation()}>
          <RowActionGroup actions={actions} />
        </td>
      </tr>
    );
  });
}

export default function Signals() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { selectedDate } = useDate();
  const { data, loading, error, refetch } = useApiData(() => loadSignalsWorkspace(selectedDate), [selectedDate]);
  const activeTab = normalizeTab(searchParams.get('tab'));
  const entrySource = searchParams.get('source');
  const focusCode = searchParams.get('focus');
  const missedFocusRef = useRef<string | null>(null);

  const [selectedCodes, setSelectedCodes] = useState<TabSelectionMap>({});
  const [drawerStock, setDrawerStock] = useState<StockDetail | null>(null);
  const [autoOpenBuyForm, setAutoOpenBuyForm] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<ActionFeedbackVm | null>(null);
  const { openPanel, closePanel } = useContextPanel();

  const workspace = data;
  const activeVm = workspace?.tabs[activeTab];
  const activeRows = workspace ? getActiveRows(workspace, activeTab) : [];
  const selectedCode = selectedCodes[activeTab] ?? null;
  const selectedRow = findRowByTsCode(activeRows, selectedCode) ?? activeRows[0] ?? null;

  const syncSearchParams = (updater: (params: URLSearchParams) => void) => {
    const nextParams = new URLSearchParams(searchParams);
    updater(nextParams);
    setSearchParams(nextParams, { replace: true });
  };

  const clearFeedback = () => setActionFeedback(null);

  const selectRow = (tab: SignalsTabKey, row: SignalsRowVm) => {
    clearFeedback();
    setSelectedCodes(prev => ({ ...prev, [tab]: row.tsCode }));
    syncSearchParams(params => {
      if (tab === 'buy') params.delete('tab');
      else params.set('tab', tab);
      params.set('focus', row.tsCode);
    });
  };

  const openDetail = (row: SignalsRowVm, openBuyForm = false) => {
    selectRow(activeTab, row);
    setAutoOpenBuyForm(openBuyForm);
    setDrawerStock(buildStockDetail(row));
    setActionFeedback({
      tone: openBuyForm ? 'success' : 'info',
      text: openBuyForm
        ? `已打开 ${row.name} 详情，并展开买入入口。`
        : `已打开 ${row.name} 详情，选中项与右侧上下文保持同步。`,
    });
  };

  const jumpTo = (href: string | null, fallbackText: string) => {
    if (!href) {
      setActionFeedback({ tone: 'warning', text: fallbackText });
      return;
    }
    navigate(href);
  };

  const markPlaceholder = (text: string) => {
    setActionFeedback({ tone: 'warning', text });
  };

  useEffect(() => {
    if (!workspace) return;
    const rows = getActiveRows(workspace, activeTab);

    if (rows.length === 0) {
      setSelectedCodes(prev => ({ ...prev, [activeTab]: '' }));
      clearFeedback();
      return;
    }

    const focusedRow = findRowByTsCode(rows, focusCode);
    if (focusedRow) {
      missedFocusRef.current = null;
      setSelectedCodes(prev => (prev[activeTab] === focusedRow.tsCode ? prev : { ...prev, [activeTab]: focusedRow.tsCode }));
      return;
    }

    const rememberedCode = selectedCodes[activeTab] ?? null;
    const rememberedRow = findRowByTsCode(rows, rememberedCode);
    if (rememberedRow) return;

    setSelectedCodes(prev => ({ ...prev, [activeTab]: rows[0].tsCode }));
    if (focusCode && missedFocusRef.current !== `${activeTab}:${focusCode}`) {
      missedFocusRef.current = `${activeTab}:${focusCode}`;
      setActionFeedback({
        tone: 'warning',
        text: `未命中 ${focusCode}，已回退到当前 Tab 首行。`,
      });
    }
  }, [workspace, activeTab, focusCode, selectedCodes]);

  const selectionVm = useMemo(
    () => buildSelectionVm(selectedRow, activeTab, workspace?.tradeDate ?? selectedDate, jumpTo, openDetail, markPlaceholder),
    [selectedRow, activeTab, workspace?.tradeDate, selectedDate],
  );

  useEffect(() => {
    if (!selectedRow || !selectionVm) {
      closePanel();
      return;
    }

    openPanel({
      entityType: 'stock',
      entityKey: selectedRow.tsCode,
      sourcePage: 'signals',
      tradeDate: selectedDate,
      focus: selectedRow.tsCode,
      activeTab,
      payloadVersion: 'v1',
      payload: buildSignalsContextPayload(selectedRow, activeTab, workspace?.tradeDate ?? selectedDate, selectionVm, openDetail, jumpTo),
    });
  }, [selectedRow, selectionVm, activeTab, openPanel, closePanel, workspace?.tradeDate, selectedDate]);

  useEffect(() => () => closePanel(), [closePanel]);

  const compactNotes = useMemo(() => {
    if (!workspace) {
      return [
        { label: '主源', detail: 'Dashboard / Watchlist / 持仓中心 / 多策略共振', origin: 'primary' as SignalsDataOrigin },
        { label: '聚合', detail: '旧策略列表和过渡字段由 adapter 补位', origin: 'aggregate' as SignalsDataOrigin },
      ];
    }
    return workspace.workspaceNotes.slice(0, 2);
  }, [workspace]);

  const handleTabChange = (nextTab: SignalsTabKey) => {
    clearFeedback();
    syncSearchParams(params => {
      if (nextTab === 'buy') params.delete('tab');
      else params.set('tab', nextTab);
      const rememberedCode = selectedCodes[nextTab];
      if (rememberedCode) params.set('focus', rememberedCode);
      else params.delete('focus');
    });
  };

  const emptyCount = activeRows.length;
  const hasSelection = Boolean(selectionVm);

  return (
    <div className="signals-page" data-testid="signals-page">
      <section className="signals-hero card">
        <div className="signals-hero-copy">
          <div className="page-title">
            {signalsMeta.title}
            <span className="page-badge badge-blue">Workspace</span>
          </div>
          <p className="page-desc">{signalsMeta.description}</p>
          <p className="signals-hero-note">
            从 Dashboard 的今日机会继续往下做筛选、判断、下钻和动作。
          </p>
          <div className="signals-entry-flags">
            {entrySource === 'dashboard' ? <span className="signals-mini-pill active">来自 Dashboard</span> : null}
            {focusCode ? <span className="signals-mini-pill active">focus {focusCode}</span> : null}
            <span className="signals-mini-pill active">tab {activeTab}</span>
          </div>
        </div>
        <div className="signals-hero-side">
          <div className="signals-hero-kicker">交易日</div>
          <div className="signals-hero-date">{workspace?.tradeDate ?? selectedDate}</div>
          <div className="signals-hero-sub">{workspace?.generatedAtText ?? 'Signals 数据准备中'}</div>
        </div>
      </section>

      <section className="card signals-compact-card">
        <div className="signals-compact-body">
          <div className="signals-compact-copy">主源和聚合来源已下沉为轻提示，不占主视觉。</div>
          <div className="signals-compact-tags">
            {compactNotes.map(item => (
              <span key={`${item.label}-${item.detail}`} className="signals-compact-item">
                <CompactSourceBadge note={item} />
                <span className="signals-compact-detail">{item.detail}</span>
              </span>
            ))}
          </div>
          {workspace?.warnings.length ? (
            <div className="signals-warning-inline">
              {workspace.warnings.slice(0, 2).map(warning => (
                <span key={warning} className="signals-warning-chip">{warning}</span>
              ))}
            </div>
          ) : null}
        </div>
      </section>

      <div className="page-tabs signals-tabs">
        {signalsTabOrder.map(tabKey => (
          <button
            key={tabKey}
            className={`page-tab-btn${activeTab === tabKey ? ' active' : ''}`}
            onClick={() => handleTabChange(tabKey)}
            type="button"
          >
            {workspace?.tabs[tabKey].label ?? tabKey}
          </button>
        ))}
      </div>

      <section className="signals-layout">
        <div className="signals-main">
          <section className="card">
            <div className="card-header">
              <span className="card-title">{activeVm?.title ?? 'Signals 工作台'}</span>
              <span className="c-muted" style={{ fontSize: 12 }}>
                {activeTab === 'buy' ? '/signals' : `/signals?tab=${activeTab}`}
              </span>
            </div>

            {loading ? (
              <div className="signals-loading-state">
                <div className="spinner" />
                <span>Signals 数据加载中...</span>
              </div>
            ) : null}

            {!loading && error ? (
              <div className="page-error">
                <div className="page-error-msg">Signals 数据加载失败</div>
                <div className="page-error-detail">{error}</div>
                <button className="retry-btn" onClick={refetch}>重试</button>
              </div>
            ) : null}

            {!loading && !error && activeVm ? (
              <>
                <div className="signals-summary-grid">
                  {activeVm.metrics.map(metric => (
                    <div key={metric.label} className="stat-card signals-summary-card">
                      <div className="stat-label">{metric.label}</div>
                      <div className="stat-value signals-summary-value">{metric.value}</div>
                      <div className="stat-sub">{metric.helper}</div>
                      <div className={`signals-origin-inline ${originClassName(metric.origin)}`}>{metric.origin}</div>
                    </div>
                  ))}
                </div>
                <div className="signals-summary-note signals-summary-note-compact">{activeVm.description}</div>
              </>
            ) : null}
          </section>

          <section className="card">
            <div className="card-header">
              <span className="card-title">筛选</span>
              <span className="c-muted" style={{ fontSize: 12 }}>
                当前保持轻量结构，避免打断工作流
              </span>
            </div>
            <div className="signals-filter-shell">
              {(activeVm?.filters ?? []).map(item => (
                <div key={item.label} className="signals-filter-pill">
                  <span>{item.label}</span>
                  <span className="signals-filter-placeholder">{item.value}</span>
                  <span className={`signals-filter-origin ${originClassName(item.origin)}`}>{item.origin}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="card">
            <div className="card-header">
              <span className="card-title">{activeTab === 'flow' ? '策略触发流' : '信号列表'}</span>
              <span className="c-muted" style={{ fontSize: 12 }}>
                {activeTab === 'flow'
                  ? '当前为聚合视图，后续替换为正式事件流'
                  : `当前 ${emptyCount} 条，可点选并联动右侧上下文`}
              </span>
            </div>
            <div className="signals-table-shell">
              <table className="data-table">
                <thead>
                  <tr>{getTableColumns(activeTab).map(column => <th key={column}>{column}</th>)}</tr>
                </thead>
                <tbody>
                  {emptyCount === 0 && activeVm ? (
                    <tr className="signals-table-empty-row">
                      <td colSpan={getTableColumns(activeTab).length}>
                        <div className="signals-empty-state">
                          <div className="signals-empty-title">{activeVm.emptyTitle}</div>
                          <div className="signals-empty-text">{activeVm.emptyText}</div>
                        </div>
                      </td>
                    </tr>
                  ) : renderTableRows(
                    activeTab,
                    activeRows,
                    selectedCode,
                    workspace?.tradeDate ?? selectedDate,
                    row => selectRow(activeTab, row),
                    openDetail,
                    jumpTo,
                    markPlaceholder,
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </div>

        <aside className="signals-context">
          <section className="card signals-context-card">
            <div className="card-header">
              <span className="card-title">{hasSelection ? '当前选中' : '右侧上下文'}</span>
              <span className="c-muted" style={{ fontSize: 12 }}>
                {hasSelection ? '随行联动' : '等待选中'}
              </span>
            </div>
            <div className="signals-context-body">
              {actionFeedback ? (
                <div className={`signals-feedback-banner ${actionFeedback.tone}`}>{actionFeedback.text}</div>
              ) : null}

              {selectionVm ? (
                <>
                  <div className="signals-context-head">
                    <div className="signals-context-title">{selectionVm.title}</div>
                    <div className="signals-context-code">{selectionVm.tsCode}</div>
                  </div>
                  <div className="signals-context-signal">
                    <div className="signals-context-label">当前信号</div>
                    <div className="signals-context-value">{selectionVm.signal}</div>
                  </div>
                  <div className="signals-context-section">
                    <div className="signals-context-label">来源策略</div>
                    <div className="signals-context-value">{selectionVm.source}</div>
                  </div>
                  <div className="signals-context-section">
                    <div className="signals-context-label">状态</div>
                    <div className="signals-status-stack">
                      <span className={`signals-mini-pill${selectionVm.inWatchlist ? ' active' : ''}`}>观察池</span>
                      <span className={`signals-mini-pill${selectionVm.inPortfolio ? ' active' : ''}`}>组合</span>
                    </div>
                  </div>
                  <div className="signals-context-section">
                    <div className="signals-context-label">摘要</div>
                    <div className="signals-context-text">{selectionVm.summary}</div>
                  </div>
                  <div className="signals-context-section">
                    <div className="signals-context-label">快捷动作</div>
                    <div className="signals-context-actions">
                      {selectionVm.actions.map(action => (
                        <ActionButton key={`${action.label}-${action.kind}`} action={action} />
                      ))}
                    </div>
                  </div>
                  <div className="signals-context-section">
                    <div className="signals-context-label">补充标签</div>
                    <div className="signals-context-tags">
                      {selectionVm.tags.map(tag => (
                        <span key={tag} className="signals-mini-pill active">{tag}</span>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <div className="signals-context-empty">
                  {emptyCount === 0
                    ? '当前 Tab 暂无数据，右侧上下文保持为空。'
                    : '点击左侧任一行后，这里会显示对应信号或事件的轻量摘要。'}
                </div>
              )}
            </div>
          </section>
        </aside>
      </section>

      <StockDrawer
        stock={drawerStock}
        onClose={() => {
          setDrawerStock(null);
          setAutoOpenBuyForm(false);
        }}
        autoOpenBuyForm={autoOpenBuyForm}
      />
    </div>
  );
}
