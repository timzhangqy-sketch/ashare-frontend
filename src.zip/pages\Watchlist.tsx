import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import StockDrawer from '../components/Drawer/StockDrawer';
import { CrossTags } from '../components/CrossTags';
import WatchlistActionMenu from '../components/WatchlistActionMenu';
import WatchlistGroupView from '../components/WatchlistGroupView';
import WatchlistStatusBadge from '../components/WatchlistStatusBadge';
import { loadWatchlistWorkspace } from '../adapters/watchlist';
import { useContextPanel } from '../context/ContextPanelContext';
import { useDate } from '../context/DateContext';
import { useApiData } from '../hooks/useApiData';
import type { StockDetail } from '../types/stock';
import type { StockContextPanelPayload } from '../types/contextPanel';
import type {
  WatchlistActionVm,
  WatchlistQueryState,
  WatchlistRowVm,
  WatchlistViewKey,
} from '../types/watchlist';
import { getStrategyDisplayName } from '../utils/displayNames';
import { buildResearchHref } from '../utils/researchHandoff';
import { getMockDetail } from '../utils/score';

type FeedbackTone = 'info' | 'warning' | 'success';

interface FeedbackState {
  tone: FeedbackTone;
  text: string;
}

function normalizeView(value: string | null): WatchlistViewKey {
  if (value === 'group' || value === 'heat') return value;
  return 'table';
}

function buildQueryState(searchParams: URLSearchParams): WatchlistQueryState {
  return {
    source: searchParams.get('source'),
    focus: searchParams.get('focus'),
    strategy: searchParams.get('strategy'),
    status: searchParams.get('status'),
    signal: searchParams.get('signal'),
    query: searchParams.get('query'),
    view: normalizeView(searchParams.get('view')),
    groupBy: searchParams.get('groupBy') === 'strategy' ? 'strategy' : 'lifecycle',
  };
}

function buildDrawerStock(row: WatchlistRowVm): StockDetail {
  return getMockDetail(row.tsCode, row.name, [row.strategy], 0, row.latestPctChg);
}

function formatSignedPercent(value: number | null | undefined, decimal = false): string {
  if (value == null) return '--';
  const parsed = decimal ? value * 100 : value;
  return `${parsed > 0 ? '+' : ''}${parsed.toFixed(2)}%`;
}

function SignalBadge({ label, tone }: { label: string | null; tone: 'buy' | 'sell' }) {
  if (!label) return <span className="watchlist-signal-empty">无信号</span>;
  return <span className={`watchlist-signal-badge ${tone}`}>{label}</span>;
}

function displayStrategyName(value: string | null | undefined): string {
  if (!value) return '全部';
  return getStrategyDisplayName(value) ?? value;
}

function buildSourceContext(queryState: WatchlistQueryState): string {
  if (queryState.source !== 'signals') return '用于持续跟踪、筛选和整理当前观察对象。';
  const parts = ['来自 Signals'];
  if (queryState.strategy) parts.push(`策略：${displayStrategyName(queryState.strategy)}`);
  if (queryState.signal) parts.push(`信号：${queryState.signal}`);
  if (queryState.focus) parts.push(`聚焦：${queryState.focus}`);
  return `${parts.join(' / ')}`;
}

function buildActionSummary(row: WatchlistRowVm): Array<{ label: string; type: string }> {
  return row.availableActions.map(action => ({
    label: action.label,
    type: action.summaryType ?? action.kind,
  }));
}

function buildWatchlistContextPayload(
  row: WatchlistRowVm,
  tradeDate: string,
  openDetail: (row: WatchlistRowVm) => void,
): StockContextPanelPayload {
  return {
    title: row.name,
    name: row.name,
    tsCode: row.tsCode,
    sourceStrategy: row.strategy,
    subtitle: row.lifecycleStatusLabel,
    summary: row.inPortfolio
      ? `当前已移交到持仓跟踪${row.portfolioStatus ? `（${row.portfolioStatus}）` : ''}。`
      : '当前仍在观察池，可继续跟踪信号、来源与后续动作。',
    tags: [
      { label: row.lifecycleStatusLabel, tone: 'state' },
      { label: row.signalLabel, tone: 'source' },
      ...(row.crossTags ?? []).map(tag => ({ label: tag, tone: 'strategy' as const })),
    ],
    summaryItems: [
      { label: '来源策略', value: row.strategy },
      { label: '入池日期', value: row.entryDate },
      { label: '观察天数', value: `${row.poolDay}` },
      { label: '最新涨跌', value: formatSignedPercent(row.latestPctChg) },
      { label: '入池后涨跌', value: formatSignedPercent(row.gainSinceEntry, true) },
      { label: '持仓状态', value: row.inPortfolio ? `已移交${row.portfolioStatus ? ` / ${row.portfolioStatus}` : ''}` : '仍在观察池' },
    ],
    actions: [
      {
        label: '查看详情',
        onClick: () => openDetail(row),
        note: '继续使用原有详情抽屉。',
      },
      {
        label: '查看风控',
        href: `/risk?tab=breakdown&source=watchlist&focus=${encodeURIComponent(row.tsCode)}&scope=watchlist`,
        note: '跳转到风控中心。',
      },
      {
        label: '查看研究',
        href: buildResearchHref({
          source: 'watchlist',
          focus: row.tsCode,
          strategy: row.strategy,
          tradeDate,
          detailRoute: row.strategy ? 'backtest' : null,
          detailKey: row.strategy,
        }),
        note: '跳转到研究中心。',
      },
      {
        label: '去模拟执行',
        href: `/execution?tab=orders&source=watchlist&focus=${encodeURIComponent(row.tsCode)}&strategy=${encodeURIComponent(row.strategy)}`,
        note: '跳转到模拟执行工作域。',
      },
    ],
  };
}

export default function Watchlist() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { selectedDate } = useDate();
  const searchKey = searchParams.toString();
  const queryState = buildQueryState(searchParams);
  const focusWarningRef = useRef<string | null>(null);
  const selectionWarningRef = useRef<string | null>(null);

  const { data, loading, error, refetch } = useApiData(
    () => loadWatchlistWorkspace(queryState, selectedDate),
    [selectedDate, searchKey],
  );

  const [selectedCode, setSelectedCode] = useState<string | null>(null);
  const [drawerStock, setDrawerStock] = useState<StockDetail | null>(null);
  const [feedback, setFeedback] = useState<FeedbackState | null>(null);
  const { openPanel, closePanel } = useContextPanel();

  const rows = data?.rows ?? [];
  const groups = data?.groups ?? [];
  const activeRow = useMemo(
    () => rows.find(row => row.tsCode === selectedCode) ?? rows[0] ?? null,
    [rows, selectedCode],
  );

  const syncParams = (updater: (params: URLSearchParams) => void) => {
    const nextParams = new URLSearchParams(searchParams);
    updater(nextParams);
    setSearchParams(nextParams, { replace: true });
  };

  const setFeedbackMessage = (tone: FeedbackTone, text: string) => {
    setFeedback({ tone, text });
  };

  useEffect(() => {
    if (!rows.length) {
      setSelectedCode(null);
      setFeedback(null);
      return;
    }

    const focusRow = queryState.focus
      ? rows.find(row => row.tsCode.toUpperCase() === queryState.focus?.toUpperCase())
      : null;

    if (focusRow) {
      focusWarningRef.current = null;
      selectionWarningRef.current = null;
      setSelectedCode(focusRow.tsCode);
      return;
    }

    if (queryState.focus && focusWarningRef.current !== `${queryState.view}:${queryState.focus}:${queryState.groupBy}`) {
      focusWarningRef.current = `${queryState.view}:${queryState.focus}:${queryState.groupBy}`;
      setFeedbackMessage('warning', `当前观察池结果未命中 ${queryState.focus}，已回退到首行。`);
    }

    if (!queryState.focus) {
      focusWarningRef.current = null;
    }

    if (selectedCode && rows.some(row => row.tsCode === selectedCode)) return;

    if (selectedCode && selectionWarningRef.current !== `${selectedCode}:${queryState.view}:${queryState.groupBy}:${searchKey}`) {
      selectionWarningRef.current = `${selectedCode}:${queryState.view}:${queryState.groupBy}:${searchKey}`;
      setFeedbackMessage('warning', '上一条选中项已不在当前筛选结果中，已回退到首行。');
    }

    setSelectedCode(rows[0].tsCode);
  }, [rows, selectedCode, queryState.focus, queryState.view, queryState.groupBy, searchKey]);

  useEffect(() => {
    if (!activeRow) return;
    const element = document.querySelector<HTMLElement>(`[data-watchlist-row="${activeRow.id}"]`);
    if (element) {
      element.scrollIntoView({ block: 'nearest' });
    }
  }, [activeRow, queryState.view, queryState.groupBy]);

  const updateFilterParam = (key: string, value: string) => {
    syncParams(params => {
      if (!value || value === 'all') params.delete(key);
      else params.set(key, value);
    });
  };

  const handleViewChange = (view: WatchlistViewKey) => {
    syncParams(params => {
      if (view === 'table') params.delete('view');
      else params.set('view', view);
    });
  };

  const handleRowSelect = (row: WatchlistRowVm) => {
    setSelectedCode(row.tsCode);
    syncParams(params => {
      params.set('focus', row.tsCode);
    });
  };

  const openDetail = (row: WatchlistRowVm) => {
    handleRowSelect(row);
    setDrawerStock(buildDrawerStock(row));
    setFeedbackMessage('info', `已打开 ${row.name} 详情抽屉，观察池选中项保持在当前行。`);
  };

  const handleAction = (row: WatchlistRowVm, action: WatchlistActionVm) => {
    handleRowSelect(row);

    if (action.kind === 'detail') {
      openDetail(row);
      return;
    }

    if (action.kind === 'strategy') {
      if (action.href) {
        navigate(action.href);
      } else {
        setFeedbackMessage('warning', action.note ?? '当前来源策略页暂未映射。');
      }
      return;
    }

    if (action.kind === 'portfolio') {
      if (row.inPortfolio && action.href) {
        navigate(action.href);
      } else {
        setFeedbackMessage('info', action.note ?? '当前仅为前端承接入口，不触发后端写入。');
      }
      return;
    }

    setFeedbackMessage('warning', action.note ?? `${action.label} 当前仍为占位动作，不触发后端写入。`);
  };

  const actionSummary = activeRow ? buildActionSummary(activeRow) : [];

  useEffect(() => {
    if (!activeRow) {
      closePanel();
      return;
    }

    openPanel({
      entityType: 'stock',
      entityKey: activeRow.tsCode,
      sourcePage: 'watchlist',
      tradeDate: selectedDate,
      focus: activeRow.tsCode,
      activeTab: queryState.view === 'group' ? `group:${queryState.groupBy}` : queryState.view,
      payloadVersion: 'v1',
      payload: buildWatchlistContextPayload(activeRow, selectedDate, openDetail),
    });
  }, [activeRow, queryState.view, queryState.groupBy, openPanel, closePanel, selectedDate]);

  useEffect(() => () => closePanel(), [closePanel]);

  return (
    <div className="watchlist-page" data-testid="watchlist-page">
      <section className="watchlist-hero card">
        <div className="watchlist-hero-copy">
          <div className="page-title">
            观察池
            <span className="page-badge badge-blue">工作台</span>
          </div>
          <p className="page-desc">
            统一管理观察对象、状态筛选和后续动作准备。
          </p>
          <p className="watchlist-hero-note">{buildSourceContext(queryState)}</p>
          <div className="watchlist-entry-flags">
            <span className="watchlist-mini-pill active">来源：{queryState.source === 'signals' ? '来自 Signals' : '直接进入'}</span>
            <span className="watchlist-mini-pill active">聚焦：{queryState.focus ?? '无'}</span>
            <span className="watchlist-mini-pill active">策略：{displayStrategyName(queryState.strategy)}</span>
            <span className="watchlist-mini-pill active">状态：{queryState.status ?? '全部'}</span>
            <span className="watchlist-mini-pill active">信号：{queryState.signal ?? '全部'}</span>
            <span className="watchlist-mini-pill active">视图：{queryState.view === 'table' ? '表格' : queryState.view === 'group' ? '分组' : '热度'}</span>
            {queryState.view === 'group' ? (
              <span className="watchlist-mini-pill active">分组：{queryState.groupBy === 'strategy' ? '按策略' : '按状态'}</span>
            ) : null}
          </div>
        </div>
        <div className="watchlist-hero-side">
          <div className="watchlist-hero-kicker">交易日</div>
          <div className="watchlist-hero-date">{data?.tradeDate ?? selectedDate}</div>
          <div className="watchlist-hero-sub">当前观察池与持仓状态已同步加载</div>
        </div>
      </section>

      <section className="card">
        <div className="watchlist-metric-strip watchlist-metric-strip-5">
          {(data?.metrics ?? []).map(metric => (
            <div key={metric.label} className="stat-card watchlist-metric-card">
              <div className="stat-label">{metric.label}</div>
              <div className="stat-value watchlist-metric-value">{metric.value}</div>
              <div className="stat-sub">{metric.helper}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="card">
        <div className="card-header">
          <span className="card-title">筛选</span>
          <span className="c-muted" style={{ fontSize: 12 }}>
            当前筛选条件会自动保留并恢复。
          </span>
        </div>
        <div className="watchlist-controls">
          <label className="watchlist-control">
            <span>状态</span>
            <select value={queryState.status ?? 'all'} onChange={event => updateFilterParam('status', event.target.value)}>
              {(data?.filterOptions.statusOptions ?? []).map(option => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </label>
          <label className="watchlist-control">
            <span>策略</span>
            <select value={queryState.strategy ?? 'all'} onChange={event => updateFilterParam('strategy', event.target.value)}>
              {(data?.filterOptions.strategyOptions ?? []).map(option => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </label>
          <label className="watchlist-control">
            <span>信号</span>
            <select value={queryState.signal ?? 'all'} onChange={event => updateFilterParam('signal', event.target.value)}>
              {(data?.filterOptions.signalOptions ?? []).map(option => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </label>
          <label className="watchlist-control watchlist-control-query">
            <span>搜索</span>
            <input
              type="text"
              value={queryState.query ?? ''}
              placeholder="搜索股票代码或名称"
              onChange={event => updateFilterParam('query', event.target.value.trim())}
            />
          </label>
        </div>
        <div className="watchlist-filter-strip">
          {(data?.filters ?? []).map(filter => (
            <div key={`${filter.label}-${filter.value}`} className="watchlist-filter-pill">
              <span>{filter.label}</span>
              <span className="watchlist-filter-value">{filter.value}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="card">
        <div className="card-header">
          <span className="card-title">视图</span>
          <span className="c-muted" style={{ fontSize: 12 }}>
            可在表格与分组之间切换，热度视图暂保留说明。
          </span>
        </div>
        <div className="watchlist-view-switch">
          {(data?.viewOptions ?? []).map(option => (
            <button
              key={option.key}
              type="button"
              className={`watchlist-view-btn${queryState.view === option.key ? ' active' : ''}`}
              onClick={() => handleViewChange(option.key)}
            >
              <span>{option.label}</span>
              <span className="watchlist-view-helper">{option.helper}</span>
            </button>
          ))}
        </div>
        {queryState.view === 'group' ? (
          <div className="watchlist-group-switch">
            {(data?.groupByOptions ?? []).map(option => (
              <button
                key={option.value}
                type="button"
                className={`watchlist-group-by-btn${queryState.groupBy === option.value ? ' active' : ''}`}
                onClick={() => updateFilterParam('groupBy', option.value)}
              >
                {option.label}
              </button>
            ))}
          </div>
        ) : null}
      </section>

      <div className="watchlist-layout">
        <div className="watchlist-main">
          <section className="card">
            <div className="card-header">
              <span className="card-title">观察列表</span>
              <span className="c-muted" style={{ fontSize: 12 }}>
                当前视图：{queryState.view === 'table' ? '表格' : queryState.view === 'group' ? '分组' : '热度'}
              </span>
            </div>

            {loading ? (
              <div className="watchlist-loading-state">
                <div className="spinner" />
                <span>正在加载观察池...</span>
              </div>
            ) : null}

            {!loading && error ? (
              <div className="page-error">
                <div className="page-error-msg">观察池加载失败</div>
                <div className="page-error-detail">{error}</div>
                <button className="retry-btn" onClick={refetch}>重试</button>
              </div>
            ) : null}

            {!loading && !error && feedback ? (
              <div className={`watchlist-feedback-banner ${feedback.tone}`}>{feedback.text}</div>
            ) : null}

            {!loading && !error && queryState.view === 'heat' ? (
              <div className="watchlist-view-placeholder">
                <div className="watchlist-view-placeholder-title">热度视图</div>
                <div className="watchlist-view-placeholder-copy">
                  后续将用于展示多策略热度与优先级，当前可先使用表格或分组视图完成日常管理。
                </div>
              </div>
            ) : null}

            {!loading && !error && queryState.view === 'group' ? (
              <div className="watchlist-group-shell">
                <WatchlistGroupView
                  groups={groups}
                  selectedCode={activeRow?.tsCode ?? null}
                  onSelect={handleRowSelect}
                  onAction={handleAction}
                />
              </div>
            ) : null}

            {!loading && !error && queryState.view === 'table' ? (
              <div className="watchlist-table-shell">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>股票</th>
                      <th>策略</th>
                      <th>状态</th>
                      <th className="center">入池日期</th>
                      <th className="right">观察天数</th>
                      <th className="right">最新涨跌</th>
                      <th className="right">入池后涨跌</th>
                      <th className="center">信号</th>
                      <th className="center">交叉标签</th>
                      <th className="center">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.length === 0 ? (
                      <tr className="watchlist-table-empty-row">
                        <td colSpan={10}>
                          <div className="watchlist-empty-state">
                            <div className="watchlist-empty-title">{data?.emptyTitle ?? 'No rows'}</div>
                            <div className="watchlist-empty-text">{data?.emptyText ?? 'Watchlist is empty for the current query.'}</div>
                          </div>
                        </td>
                      </tr>
                    ) : rows.map(row => (
                      <tr
                        key={row.id}
                        data-watchlist-row={row.id}
                        className={activeRow?.id === row.id ? 'watchlist-table-row selected' : 'watchlist-table-row'}
                        onClick={() => handleRowSelect(row)}
                      >
                        <td>
                          <div className="watchlist-cell-title">
                            {row.name}
                            <CrossTags tsCode={row.tsCode} currentStrategy={row.strategy} />
                          </div>
                          <div className="watchlist-inline-meta">{row.tsCode}</div>
                        </td>
                        <td>
                          <div>{row.strategy}</div>
                          <div className="watchlist-inline-meta">{row.sourceLabel}</div>
                        </td>
                        <td>
                          <div className="watchlist-status-stack">
                            <WatchlistStatusBadge status={row.lifecycleStatus} label={row.lifecycleStatusLabel} />
                            {row.inPortfolio ? <span className="watchlist-mini-pill active">已移交</span> : null}
                          </div>
                        </td>
                        <td className="center">{row.entryDate}</td>
                        <td className="right">{row.poolDay}</td>
                        <td className="right">{formatSignedPercent(row.latestPctChg)}</td>
                        <td className="right">{formatSignedPercent(row.gainSinceEntry, true)}</td>
                        <td className="center">
                          <div className="watchlist-signal-stack">
                            <SignalBadge label={row.buySignal} tone="buy" />
                            <SignalBadge label={row.sellSignal} tone="sell" />
                          </div>
                        </td>
                        <td className="center">
                          <div className="watchlist-cross-stack">
                            {row.crossTags.length ? row.crossTags.slice(0, 2).map(tag => (
                              <span key={tag} className="watchlist-mini-pill active">{tag}</span>
                            )) : <span className="watchlist-signal-empty">无</span>}
                          </div>
                        </td>
                        <td onClick={event => event.stopPropagation()}>
                          <WatchlistActionMenu actions={row.availableActions} onAction={action => handleAction(row, action)} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : null}
          </section>
        </div>

        <aside className="watchlist-context">
          <section className="card watchlist-context-card">
            <div className="card-header">
              <span className="card-title">工作上下文</span>
              <span className="c-muted" style={{ fontSize: 12 }}>
                {activeRow ? '当前观察对象上下文' : '等待选择观察对象'}
              </span>
            </div>
            <div className="watchlist-context-body">
              {activeRow ? (
                <>
                  <div className="watchlist-context-head">
                    <div className="watchlist-context-title">{activeRow.name}</div>
                    <div className="watchlist-context-code">{activeRow.tsCode}</div>
                  </div>

                  <div className="watchlist-context-primary">
                    <WatchlistStatusBadge status={activeRow.lifecycleStatus} label={activeRow.lifecycleStatusLabel} />
                    <span className="watchlist-mini-pill active">{activeRow.strategy}</span>
                    <span className="watchlist-mini-pill active">{activeRow.inPortfolio ? '已移交持仓' : '仍在观察池'}</span>
                  </div>

                  <div className="watchlist-context-grid">
                    <div className="watchlist-context-stat">
                      <span>入池日期</span>
                      <strong>{activeRow.entryDate}</strong>
                    </div>
                    <div className="watchlist-context-stat">
                      <span>观察天数</span>
                      <strong>{activeRow.poolDay}</strong>
                    </div>
                    <div className="watchlist-context-stat">
                      <span>最新涨跌</span>
                      <strong>{formatSignedPercent(activeRow.latestPctChg)}</strong>
                    </div>
                    <div className="watchlist-context-stat">
                      <span>入池后涨跌</span>
                      <strong>{formatSignedPercent(activeRow.gainSinceEntry, true)}</strong>
                    </div>
                  </div>

                  <div className="watchlist-context-section">
                    <div className="watchlist-context-label">当前判断</div>
                    <div className="watchlist-context-tags">
                      <SignalBadge label={activeRow.buySignal} tone="buy" />
                      <SignalBadge label={activeRow.sellSignal} tone="sell" />
                      <span className="watchlist-mini-pill active">{activeRow.signalLabel}</span>
                    </div>
                  </div>

                  <div className="watchlist-context-section">
                    <div className="watchlist-context-label">持仓移交</div>
                    <div className="watchlist-context-copy">
                      {activeRow.inPortfolio
                        ? `当前已移交到持仓跟踪${activeRow.portfolioStatus ? `（${activeRow.portfolioStatus}）` : ''}。`
                        : '当前仅提供转持仓入口，正式落库动作后续再接。'}
                    </div>
                  </div>

                  <div className="watchlist-context-section">
                    <div className="watchlist-context-label">交叉标签</div>
                    <div className="watchlist-context-tags">
                      {activeRow.crossTags.length
                        ? activeRow.crossTags.map(tag => <span key={tag} className="watchlist-mini-pill active">{tag}</span>)
                        : <span className="watchlist-signal-empty">无交叉标签</span>}
                    </div>
                  </div>

                  <div className="watchlist-context-section">
                    <div className="watchlist-context-label">推荐动作</div>
                    <div className="watchlist-context-summary-list">
                      {actionSummary.map(action => (
                        <div key={`${action.label}-${action.type}`} className="watchlist-context-summary-item">
                          <span>{action.label}</span>
                          <span className={`watchlist-action-type ${action.type}`}>
                            {action.type === 'detail' ? '详情' : action.type === 'jump' ? '跳转' : action.type === 'handoff' ? '持仓' : '待接入'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="watchlist-context-section">
                    <div className="watchlist-context-label">当前可执行操作</div>
                    <div className="watchlist-context-actions">
                      <WatchlistActionMenu actions={activeRow.availableActions} onAction={action => handleAction(activeRow, action)} />
                      <button
                        type="button"
                        className="watchlist-context-risk-link"
                        onClick={() => navigate(`/risk?tab=breakdown&source=watchlist&focus=${encodeURIComponent(activeRow.tsCode)}&scope=watchlist`)}
                      >
                        查看风控
                      </button>
                      <button
                        type="button"
                        className="watchlist-context-risk-link"
                        onClick={() => navigate(buildResearchHref({
                          source: 'watchlist',
                          focus: activeRow.tsCode,
                          strategy: activeRow.strategy,
                          tradeDate: selectedDate,
                          detailRoute: activeRow.strategy ? 'backtest' : null,
                          detailKey: activeRow.strategy,
                        }))}
                      >
                        查看研究
                      </button>
                      <button
                        type="button"
                        className="watchlist-context-risk-link"
                        onClick={() => navigate(`/execution?tab=orders&source=watchlist&focus=${encodeURIComponent(activeRow.tsCode)}&strategy=${encodeURIComponent(activeRow.strategy)}`)}
                      >
                        去模拟执行
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="watchlist-context-empty">
                  选择一只股票后，可在这里查看当前状态、信号与可执行操作。
                </div>
              )}
            </div>
          </section>

          <section className="card watchlist-context-card">
            <div className="card-header">
              <span className="card-title">页面说明</span>
              <span className="c-muted" style={{ fontSize: 12 }}>当前口径说明</span>
            </div>
            <div className="watchlist-notes">
              {(data?.sourceNotes ?? []).map(note => (
                <div key={note} className="watchlist-note-item">{note}</div>
              ))}
            </div>
          </section>
        </aside>
      </div>

      <StockDrawer stock={drawerStock} onClose={() => setDrawerStock(null)} />
    </div>
  );
}
