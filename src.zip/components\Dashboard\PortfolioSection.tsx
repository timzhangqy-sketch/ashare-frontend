import { Link } from 'react-router-dom';
import type { PortfolioSectionVm } from '../../types/dashboard';
import MetricStrip from './MetricStrip';
import SectionCard from './SectionCard';
import StatusState from './StatusState';

interface PortfolioSectionProps {
  data?: PortfolioSectionVm;
  status: 'loading' | 'empty' | 'error' | 'normal';
  onRetry: () => void;
}

export default function PortfolioSection({
  data,
  status,
  onRetry,
}: PortfolioSectionProps) {
  return (
    <SectionCard
      title="组合"
      badge="组合域"
      description="回答组合状态怎样，优先看持仓数量、市值、现金比和卖点提示。"
    >
      {status === 'loading' ? (
        <StatusState
          type="loading"
          title="组合模块加载中"
          description="正在汇总持仓和动作提示。"
          compact
        />
      ) : null}
      {status === 'error' ? (
        <StatusState
          type="error"
          title="组合模块加载失败"
          description="当前无法生成组合摘要，请稍后重试。"
          actionLabel="重新加载"
          onAction={onRetry}
          compact
        />
      ) : null}
      {status === 'empty' ? (
        <StatusState
          type="empty"
          title="当前无组合摘要"
          description="尚未获取持仓数据，或今天没有新的组合变化。"
          compact
        />
      ) : null}
      {status === 'normal' && data ? (
        <div className="dashboard-section-layout">
          <MetricStrip items={data.metrics} />
          <div className="dashboard-callout-card">
            <div className="dashboard-list-title">动作提示</div>
            <p className="dashboard-callout-copy">{data.actionHint}</p>
            <div className="dashboard-inline-actions">
              <Link className="dashboard-inline-link" to="/portfolio">
                前往组合域
              </Link>
              <Link className="dashboard-inline-link" to="/portfolio">
                查看旧持仓页
              </Link>
            </div>
          </div>
        </div>
      ) : null}
    </SectionCard>
  );
}
