import { Link } from 'react-router-dom';
import type { DashboardKpiVm } from '../../types/dashboard';

interface KpiCardProps {
  item: DashboardKpiVm;
}

export default function KpiCard({ item }: KpiCardProps) {
  return (
    <Link className="dashboard-kpi-card" to={item.href}>
      <div className="dashboard-kpi-label">{item.label}</div>
      <div className={`dashboard-kpi-value tone-${item.tone}`}>{item.value}</div>
      <div className="dashboard-kpi-meta">
        <span>{item.helperText}</span>
        <span className="dashboard-kpi-link">查看</span>
      </div>
    </Link>
  );
}
