import { Link } from 'react-router-dom';
import type { SystemHealthSectionVm } from '../../types/dashboard';
import MetricStrip from './MetricStrip';
import SectionCard from './SectionCard';
import StatusState from './StatusState';

interface SystemHealthSectionProps {
  data?: SystemHealthSectionVm;
  status: 'loading' | 'empty' | 'error' | 'normal';
  onRetry: () => void;
}

export default function SystemHealthSection({
  data,
  status,
  onRetry,
}: SystemHealthSectionProps) {
  return (
    <SectionCard
      title="系统健康"
      badge="系统域"
      description="回答系统今天有没有异常，优先看 Pipeline、数据覆盖率和失败步骤。"
    >
      {status === 'loading' ? (
        <StatusState
          type="loading"
          title="系统摘要加载中"
          description="正在整理系统健康和运行诊断。"
          compact
        />
      ) : null}
      {status === 'error' ? (
        <StatusState
          type="error"
          title="系统摘要加载失败"
          description="当前无法生成系统健康摘要，请稍后重试。"
          actionLabel="重新加载"
          onAction={onRetry}
          compact
        />
      ) : null}
      {status === 'empty' ? (
        <StatusState
          type="empty"
          title="当前无系统摘要"
          description="今天暂未收到系统状态更新。"
          compact
        />
      ) : null}
      {status === 'normal' && data ? (
        <div className="dashboard-section-layout">
          <MetricStrip items={data.metrics} />
          <div className="dashboard-list-card">
            <div className="dashboard-list-title">系统异常与提醒</div>
            <div className="dashboard-list-items">
              {data.issues.map(item => (
                <Link key={item.name} className="dashboard-list-item" to={item.href}>
                  <div>
                    <div className="dashboard-item-title">{item.name}</div>
                    <div className="dashboard-item-sub">{item.summary}</div>
                  </div>
                  <div className="dashboard-item-side">
                    <span className={`page-badge badge-${item.tone === 'danger' ? 'gold' : 'blue'}`}>
                      {item.statusLabel}
                    </span>
                    <span className="dashboard-item-hint">{item.helperText}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </SectionCard>
  );
}
