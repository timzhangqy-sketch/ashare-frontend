import { fetchPortfolio, fetchTransactions, fetchWatchlist } from '../../api';
import type { PortfolioItem, PortfolioResponse, TransactionItem, WatchlistItem } from '../../api';
import type {
  PortfolioActionShellVm,
  PortfolioClosedRowVm,
  PortfolioContextVm,
  PortfolioMetricVm,
  PortfolioOpenRowVm,
  PortfolioSummaryVm,
  PortfolioTransactionRowVm,
  PortfolioWorkspaceVm,
} from './types';
import { getStrategyDisplayName } from '../../utils/displayNames';

const ACTION_COPY: Record<string, { label: string; suggestion: string }> = {
  HOLD: { label: '继续持有', suggestion: '当前以继续持有为主，建议跟踪后续信号变化。' },
  REDUCE: { label: '减仓观察', suggestion: '该持仓已进入减仓观察区，建议优先复核仓位和兑现节奏。' },
  CLOSE: { label: '接近退出', suggestion: '退出信号已接近执行区，建议优先核对平仓条件。' },
  STOP_LOSS: { label: '止损退出', suggestion: '当前更接近止损处置，建议优先检查退出纪律。' },
};

const STRATEGY_COPY: Record<string, string> = {
  VOL_SURGE: '能量蓄势',
  RETOC2: '异动策略',
  PATTERN_T2UP9: '形态策略',
  PATTERN_GREEN10: '形态策略',
};

const TRADE_TYPE_COPY: Record<string, string> = {
  BUY: '买入',
  SELL: '卖出',
  ADD: '加仓',
  REDUCE: '减仓',
  CLOSE: '平仓',
};

const formatMoney = (value: number | null | undefined): string =>
  value == null ? '--' : `${value >= 0 ? '+' : ''}${value.toFixed(2)}`;

const formatPlainMoney = (value: number | null | undefined): string =>
  value == null ? '--' : value.toFixed(2);

const formatPercent = (value: number | null | undefined): string =>
  value == null ? '--' : `${value >= 0 ? '+' : ''}${(value * 100).toFixed(2)}%`;

function toStrategyLabel(strategy: string | null | undefined): string {
  if (!strategy) return '未标注策略';
  return getStrategyDisplayName(strategy) || STRATEGY_COPY[strategy] || strategy;
}

function toActionCopy(signal: string | null | undefined): { label: string; suggestion: string } {
  if (!signal) return ACTION_COPY.HOLD;
  return ACTION_COPY[signal] ?? { label: signal, suggestion: '当前建议来自已有组合信号，请结合持仓计划复核。' };
}

function toTradeTypeLabel(value: string): string {
  return TRADE_TYPE_COPY[value] ?? value;
}

function toTriggerSourceLabel(value: string | null | undefined): string {
  if (!value) return '手动或历史记录';
  return getStrategyDisplayName(value) || STRATEGY_COPY[value] || value;
}

function buildActionShells(isClosed: boolean): PortfolioActionShellVm[] {
  if (isClosed) {
    return [
      { key: 'add', label: '加仓', enabled: false, tone: 'neutral', note: '已平仓记录仅保留复盘入口，本轮不开放加仓。' },
      { key: 'reduce', label: '减仓', enabled: false, tone: 'neutral', note: '已平仓记录不再执行减仓动作。' },
      { key: 'close', label: '平仓', enabled: false, tone: 'warning', note: '当前记录已完成退出，平仓动作仅保留状态展示。' },
    ];
  }
  return [
    { key: 'add', label: '加仓', enabled: false, tone: 'primary', note: '本轮先提供动作入口位，正式提交待后端接口接入。' },
    { key: 'reduce', label: '减仓', enabled: false, tone: 'warning', note: '本轮先承接减仓语义，正式执行待后端接口接入。' },
    { key: 'close', label: '平仓', enabled: false, tone: 'warning', note: '本轮先承接退出判断，正式平仓待后端接口接入。' },
  ];
}

function buildTransactionRow(portfolioId: number, item: TransactionItem): PortfolioTransactionRowVm {
  return {
    id: item.id,
    portfolioId,
    tsCode: item.ts_code,
    tradeDate: item.trade_date,
    tradeType: item.trade_type,
    tradeTypeLabel: toTradeTypeLabel(item.trade_type),
    price: item.price,
    shares: item.shares,
    amount: item.amount,
    triggerSource: item.trigger_source,
    triggerSourceLabel: toTriggerSourceLabel(item.trigger_source),
    notes: item.notes,
  };
}

function buildTransactionMap(entries: Array<{ portfolioId: number; items: TransactionItem[] }>): Map<number, PortfolioTransactionRowVm[]> {
  return new Map(entries.map(entry => [entry.portfolioId, entry.items.map(item => buildTransactionRow(entry.portfolioId, item))]));
}

function buildSourceHint(item: PortfolioItem, watchlistMap: Map<string, WatchlistItem>): string {
  if (watchlistMap.has(item.ts_code)) {
    return '已移交';
  }
  return '无';
}

function buildBaseRow(
  item: PortfolioItem,
  status: 'open' | 'closed',
  watchlistMap: Map<string, WatchlistItem>,
  transactionMap: Map<number, PortfolioTransactionRowVm[]>,
) {
  const actionCopy = toActionCopy(item.action_signal);

  return {
    id: item.id,
    tsCode: item.ts_code,
    name: item.name,
    status,
    statusLabel: status === 'open' ? '持有中' : '已平仓',
    sourceStrategy: item.source_strategy,
    sourceStrategyLabel: toStrategyLabel(item.source_strategy),
    fromWatchlist: watchlistMap.has(item.ts_code),
    sourceHint: buildSourceHint(item, watchlistMap),
    openDate: item.open_date,
    openPrice: item.open_price,
    shares: item.shares,
    holdDays: item.hold_days,
    latestClose: item.latest_close,
    todayPnl: item.today_pnl,
    todayPnlPct: item.today_pnl_pct,
    costAmount: item.cost_amount,
    marketValue: item.market_value,
    unrealizedPnl: item.unrealized_pnl,
    unrealizedPnlPct: item.unrealized_pnl_pct,
    actionSignal: item.action_signal,
    actionLabel: actionCopy.label,
    exitSuggestion: actionCopy.suggestion,
    signalReason: item.signal_reason,
    riskHint: '风险提示待后续风控工作域正式接入。',
    relatedTransactions: transactionMap.get(item.id) ?? [],
    rawActionSignal: item.action_signal,
  };
}

function buildOpenRows(
  resp: PortfolioResponse,
  watchlistMap: Map<string, WatchlistItem>,
  transactionMap: Map<number, PortfolioTransactionRowVm[]>,
): PortfolioOpenRowVm[] {
  return resp.data.map(item => buildBaseRow(item, 'open', watchlistMap, transactionMap));
}

function buildClosedRows(
  resp: PortfolioResponse,
  watchlistMap: Map<string, WatchlistItem>,
  transactionMap: Map<number, PortfolioTransactionRowVm[]>,
): PortfolioClosedRowVm[] {
  return resp.data.map(item => ({
    ...buildBaseRow(item, 'closed', watchlistMap, transactionMap),
    closeDate: item.close_date,
    closePrice: item.close_price,
    realizedPnl: item.realized_pnl,
    realizedPnlPct: item.realized_pnl_pct,
    exitReason: item.signal_reason || toActionCopy(item.action_signal).suggestion,
  }));
}

function buildOpenSummary(resp: PortfolioResponse, rows: PortfolioOpenRowVm[]): PortfolioSummaryVm {
  const warningCount = rows.filter(row => row.rawActionSignal && row.rawActionSignal !== 'HOLD').length;
  const metrics: PortfolioMetricVm[] = [
    { label: '当前持仓数', value: String(rows.length), helper: '当前仍在组合跟踪中的持仓数量。' },
    { label: '组合市值', value: formatPlainMoney(resp.total_value), helper: '当前持仓的最新市值估算。' },
    { label: '浮动盈亏', value: formatMoney(resp.total_pnl), helper: formatPercent(resp.total_pnl_pct) },
    { label: '退出关注', value: String(warningCount), helper: '已进入减仓观察或接近退出的持仓数。' },
  ];

  return {
    title: '当前持仓',
    description: '查看持仓表现、退出判断与来源承接，作为组合日常管理入口。',
    metrics,
  };
}

function buildClosedSummary(rows: PortfolioClosedRowVm[]): PortfolioSummaryVm {
  const realized = rows.reduce((sum, row) => sum + (row.realizedPnl ?? 0), 0);
  const winCount = rows.filter(row => (row.realizedPnl ?? 0) > 0).length;
  const avgPct = rows.length
    ? rows.reduce((sum, row) => sum + ((row.realizedPnlPct ?? 0) * 100), 0) / rows.length
    : 0;

  return {
    title: '已平仓',
    description: '复盘退出原因、兑现结果与来源路径，形成退出管理视图。',
    metrics: [
      { label: '平仓记录数', value: String(rows.length), helper: '当前可回看平仓结果的记录数量。' },
      { label: '累计已实现盈亏', value: formatMoney(realized), helper: '已平仓记录的累计已实现盈亏。' },
      { label: '盈利笔数', value: String(winCount), helper: '已平仓中产生正收益的记录数量。' },
      { label: '平均收益率', value: `${avgPct >= 0 ? '+' : ''}${avgPct.toFixed(2)}%`, helper: '基于已平仓记录的平均收益率。' },
    ],
  };
}

function buildTransactionSummary(rows: PortfolioTransactionRowVm[]): PortfolioSummaryVm {
  const buyCount = rows.filter(row => row.tradeType === 'BUY' || row.tradeType === 'ADD').length;
  const sellCount = rows.filter(row => row.tradeType === 'SELL' || row.tradeType === 'REDUCE' || row.tradeType === 'CLOSE').length;

  return {
    title: '交易流水',
    description: '围绕当前选中持仓查看建仓、加仓、减仓和平仓过程。',
    metrics: [
      { label: '关联流水数', value: String(rows.length), helper: '当前已加载的组合交易记录数。' },
      { label: '买入相关', value: String(buyCount), helper: '包含建仓与加仓记录。' },
      { label: '卖出相关', value: String(sellCount), helper: '包含减仓与平仓记录。' },
      { label: '最近来源', value: rows[0]?.triggerSourceLabel ?? '待选择持仓', helper: '优先展示当前记录关联的最近触发来源。' },
    ],
  };
}

export function buildPortfolioContext(
  row: PortfolioOpenRowVm | PortfolioClosedRowVm | null,
  sourceQuery: string | null,
): PortfolioContextVm | null {
  if (!row) return null;

  const sourceQueryValue = sourceQuery === 'dashboard'
    ? '来自 Dashboard'
    : sourceQuery === 'signals'
      ? '来自 Signals'
      : sourceQuery === 'watchlist'
        ? '来自观察池'
        : '直接进入';

  return {
    title: row.name,
    code: row.tsCode,
    statusLabel: row.statusLabel,
    sourceStrategyLabel: row.sourceStrategyLabel,
    sourceHint: row.fromWatchlist ? '已移交' : '无',
    sourceQueryLabel: '来源上下文',
    sourceQueryValue,
    holdingFacts: [
      { label: '建仓时间', value: row.openDate },
      { label: '建仓价', value: formatPlainMoney(row.openPrice) },
      { label: '持仓数量', value: String(row.shares) },
      { label: '持仓天数', value: row.holdDays == null ? '--' : String(row.holdDays) },
      { label: row.status === 'open' ? '浮动盈亏' : '已实现盈亏', value: row.status === 'open' ? formatMoney(row.unrealizedPnl) : formatMoney(('realizedPnl' in row ? row.realizedPnl : null)) },
      { label: row.status === 'open' ? '浮盈比例' : '收益比例', value: row.status === 'open' ? formatPercent(row.unrealizedPnlPct) : formatPercent(('realizedPnlPct' in row ? row.realizedPnlPct : null)) },
    ],
    judgementFacts: [
      { label: '当前判断', value: row.actionLabel },
      { label: '退出建议', value: row.exitSuggestion },
      { label: row.status === 'open' ? '操作信号' : '平仓原因', value: row.status === 'open' ? (row.actionSignal ?? 'HOLD') : ('exitReason' in row ? row.exitReason : '--') },
      { label: '风险提示', value: row.riskHint },
    ],
    transactionSummary: row.relatedTransactions.length > 0
      ? `已关联 ${row.relatedTransactions.length} 条交易流水`
      : '当前暂无关联交易流水',
    relatedLinks: [
      { key: 'source', label: '查看来源', enabled: true, note: `来源策略：${row.sourceStrategyLabel}` },
      { key: 'watchlist', label: '查看关联观察池', enabled: row.fromWatchlist, note: row.fromWatchlist ? '该标的来自观察池移交，可继续回看观察上下文。' : '当前没有观察池关联记录。' },
      { key: 'transactions', label: '查看交易流水', enabled: true, note: row.relatedTransactions.length > 0 ? '切换到交易流水页签查看关联记录。' : '当前暂无流水记录，仍可查看正式空态。' },
    ],
    actionShells: buildActionShells(row.status === 'closed'),
  };
}

export async function loadPortfolioWorkspace(tradeDate: string): Promise<PortfolioWorkspaceVm> {
  const [openResp, closedResp, watchlist] = await Promise.all([
    fetchPortfolio('open'),
    fetchPortfolio('closed'),
    fetchWatchlist(),
  ]);

  const transactionTargets = [...openResp.data, ...closedResp.data].slice(0, 12);
  const transactionEntries = await Promise.all(
    transactionTargets.map(async item => {
      try {
        const items = await fetchTransactions(item.id);
        return { portfolioId: item.id, items };
      } catch {
        return { portfolioId: item.id, items: [] };
      }
    }),
  );

  const watchlistMap = new Map(watchlist.map(item => [item.ts_code, item]));
  const transactionMap = buildTransactionMap(transactionEntries);
  const openRows = buildOpenRows(openResp, watchlistMap, transactionMap);
  const closedRows = buildClosedRows(closedResp, watchlistMap, transactionMap);
  const transactionRows = [...openRows, ...closedRows]
    .flatMap(row => row.relatedTransactions)
    .sort((a, b) => `${b.tradeDate}-${b.id}`.localeCompare(`${a.tradeDate}-${a.id}`));

  return {
    tradeDate,
    generatedAtText: '已完成持仓、退出与交易流水的组合工作域承接。',
    tabs: {
      open: {
        label: '当前持仓',
        title: '当前持仓',
        description: '查看持仓表现、退出判断与来源承接。',
        emptyTitle: '当前没有可管理持仓',
        emptyText: '组合当前没有 open 持仓，可从 Dashboard、Signals 或观察池继续承接。',
      },
      closed: {
        label: '已平仓',
        title: '已平仓',
        description: '查看退出原因、收益结果与来源复盘。',
        emptyTitle: '当前没有平仓记录',
        emptyText: '已平仓页签暂时没有记录，可在后续退出后回看结果。',
      },
      transactions: {
        label: '交易流水',
        title: '交易流水',
        description: '围绕当前选中持仓查看交易过程与触发来源。',
        emptyTitle: '当前没有可展示流水',
        emptyText: '请先选中一个持仓或平仓记录，组合会在这里承接相关流水。',
      },
    },
    summary: {
      open: buildOpenSummary(openResp, openRows),
      closed: buildClosedSummary(closedRows),
      transactions: buildTransactionSummary(transactionRows),
    },
    openRows,
    closedRows,
    transactions: {
      title: '交易流水',
      description: '承接当前选中持仓的建仓、加仓、减仓和平仓记录。',
      relatedLabel: '默认显示当前已加载的关联流水；切换选中项后可继续收窄到对应记录。',
      rows: transactionRows,
      emptyTitle: '当前没有交易流水',
      emptyText: '本轮已建立正式流水结构；若后端暂无记录，则先显示为空态。',
    },
  };
}
