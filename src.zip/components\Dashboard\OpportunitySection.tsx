import { Link } from 'react-router-dom';
import type { OpportunitySectionVm } from '../../types/dashboard';
import MetricStrip from './MetricStrip';
import SectionCard from './SectionCard';
import StatusState from './StatusState';

interface OpportunitySectionProps {
  data?: OpportunitySectionVm;
  status: 'loading' | 'empty' | 'error' | 'normal';
  onRetry: () => void;
}

export default function OpportunitySection({
  data,
  status,
  onRetry,
}: OpportunitySectionProps) {
  return (
    <SectionCard
      title="机会"
      badge="信号域"
      description="回答今天机会在哪里，优先看可执行信号、共振机会和观察池候选。"
    >
      {status === 'loading' ? (
        <StatusState
          type="loading"
          title="机会模块加载中"
          description="正在整理信号和候选列表。"
          compact
        />
      ) : null}
      {status === 'error' ? (
        <StatusState
          type="error"
          title="机会模块加载失败"
          description="当前无法生成机会摘要，请稍后重试。"
          actionLabel="重新加载"
          onAction={onRetry}
          compact
        />
      ) : null}
      {status === 'empty' ? (
        <StatusState
          type="empty"
          title="当前无新增机会"
          description="今天暂无新的机会摘要，可继续查看兼容策略页。"
          compact
        />
      ) : null}
      {status === 'normal' && data ? (
        <div className="dashboard-section-layout">
          <MetricStrip items={data.metrics} />
          <div className="dashboard-list-card">
            <div className="dashboard-list-title">重点机会</div>
            <div className="dashboard-list-items">
              {data.topOpportunities.map(item => (
                <Link key={item.name} className="dashboard-list-item" to={item.href}>
                  <div>
                    <div className="dashboard-item-title">{item.name}</div>
                    <div className="dashboard-item-sub">{item.strategyLabel}</div>
                  </div>
                  <div className="dashboard-item-side">
                    <span className={`page-badge badge-${item.tone === 'danger' ? 'gold' : 'blue'}`}>
                      {item.scoreLabel}
                    </span>
                    <span className="dashboard-item-hint">{item.helperText}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </SectionCard>
  );
}
