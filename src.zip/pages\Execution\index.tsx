import { useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { loadExecutionWorkspace } from '../../adapters/execution'
import { useContextPanel } from '../../context/ContextPanelContext'
import { useApiData } from '../../hooks/useApiData'
import type { StockContextPanelPayload } from '../../types/contextPanel'
import type {
  ExecutionConstraintRow,
  ExecutionDataStatus,
  ExecutionRow,
  ExecutionTab,
  SimFillRow,
  SimOrderRow,
  SimPositionRow,
} from '../../types/execution'

function formatNumber(value: number, digits = 2) {
  return value.toFixed(digits)
}

function getTabTitle(tab: ExecutionTab) {
  const map: Record<ExecutionTab, string> = {
    orders: '模拟订单',
    positions: '模拟持仓',
    fills: '模拟成交',
    constraints: '执行约束',
  }
  return map[tab]
}

function getTabDescription(tab: ExecutionTab) {
  const map: Record<ExecutionTab, string> = {
    orders: '查看已经进入执行域的订单对象、状态推进和来源策略。',
    positions: '查看模拟持仓状态、来源对象和当前仓位建议。',
    fills: '查看成交结果以及与订单、持仓之间的关联。',
    constraints: '查看执行前是否允许下单、限制原因和仓位上限。',
  }
  return map[tab]
}

function getStatusTitle(status: ExecutionDataStatus) {
  if (status === 'real') return '真实数据'
  if (status === 'fallback') return '兼容数据视图'
  return '暂未接入'
}

function renderRowMeta(row: ExecutionRow) {
  if (row.objectType === 'order') {
    const order = row as SimOrderRow
    return `${order.side === 'buy' ? '买入' : '卖出'} / ${order.qty} 股 / ${formatNumber(order.price)} / ${order.orderStatusLabel}`
  }
  if (row.objectType === 'position') {
    const position = row as SimPositionRow
    return `${position.shares} 股 / 成本 ${formatNumber(position.entryPrice)} / ${position.positionStatusLabel}`
  }
  if (row.objectType === 'fill') {
    const fill = row as SimFillRow
    return `${fill.side === 'buy' ? '买入成交' : '卖出成交'} / ${fill.fillQty} 股 / ${formatNumber(fill.fillPrice)} / ${fill.fillStatusLabel}`
  }
  const constraint = row as ExecutionConstraintRow
  return `${constraint.constraintStatusLabel} / ${constraint.positionCapText}`
}

function buildExecutionContextPanelPayload(row: ExecutionRow): StockContextPanelPayload {
  const tags = [
    { label: row.sourceLabel, tone: 'source' as const },
    { label: row.strategyLabel, tone: 'strategy' as const },
    { label: row.tradeAllowedLabel, tone: 'state' as const },
    { label: row.riskLevelLabel, tone: 'risk' as const },
  ]

  return {
    title: row.name,
    name: row.name,
    tsCode: row.tsCode,
    sourceStrategy: row.sourceStrategy,
    subtitle: row.statusLabel,
    summary: row.summary,
    tags,
    summaryItems: [
      { label: '执行对象', value: row.objectType === 'order' ? '模拟订单' : row.objectType === 'position' ? '模拟持仓' : row.objectType === 'fill' ? '模拟成交' : '执行约束' },
      { label: '来源链路', value: row.sourceLabel },
      { label: '来源策略', value: row.strategyLabel },
      { label: '执行结论', value: row.tradeAllowedLabel },
      { label: '风险等级', value: row.riskLevelLabel },
      { label: '仓位建议', value: row.positionCapText },
      { label: '阻断原因', value: row.blockReason ?? '无' },
    ],
    actions: [
      {
        label: '查看风控',
        href: `/risk?tab=breakdown&source=execution&focus=${encodeURIComponent(row.tsCode)}&scope=portfolio`,
        note: '核对当前执行对象对应的风险结论。',
      },
      {
        label: '查看持仓',
        href: `/portfolio?source=execution&focus=${encodeURIComponent(row.tsCode)}`,
        note: '回到持仓中心查看关联持仓。',
      },
      {
        label: '查看研究',
        href: `/research?source=execution&focus=${encodeURIComponent(row.tsCode)}${row.sourceStrategy ? `&strategy=${encodeURIComponent(row.sourceStrategy)}` : ''}`,
        note: '查看当前对象对应的研究验证。',
      },
      {
        label: '查看系统状态',
        href: '/system?source=execution&tab=api',
        note: '核对执行依赖的接口与运行状态。',
      },
    ],
  }
}

export default function ExecutionPage() {
  const navigate = useNavigate()
  const [searchParams, setSearchParams] = useSearchParams()
  const { openPanel, closePanel } = useContextPanel()
  const { data, loading, error } = useApiData(
    () => loadExecutionWorkspace(searchParams),
    [searchParams.toString()],
  )

  const activeTab = data?.query.tab ?? 'constraints'
  const rows =
    !data
      ? []
      : activeTab === 'orders'
        ? data.orders
        : activeTab === 'positions'
          ? data.positions
          : activeTab === 'fills'
            ? data.fills
            : data.constraints
  const activeRow =
    rows.find((row) => row.id === data?.selectedId)
    ?? rows.find((row) => row.tsCode === data?.query.focus || row.focusKey === data?.query.focus)
    ?? null

  const activeTabState = data?.tabStates?.[activeTab]

  function setTab(tab: ExecutionTab) {
    const next = new URLSearchParams(searchParams)
    next.set('tab', tab)
    setSearchParams(next)
  }

  function setFocus(row: ExecutionRow) {
    const next = new URLSearchParams(searchParams)
    next.set('focus', row.focusKey)
    setSearchParams(next)
  }

  function openSystem() {
    navigate('/system?source=execution&tab=api')
  }

  useEffect(() => {
    if (!activeRow) {
      closePanel()
      return
    }

    openPanel({
      entityType: 'stock',
      entityKey: activeRow.tsCode,
      sourcePage: 'execution',
      focus: activeRow.tsCode,
      activeTab,
      payloadVersion: 'v1',
      payload: buildExecutionContextPanelPayload(activeRow),
    })
  }, [activeRow, activeTab, openPanel, closePanel])

  useEffect(() => () => closePanel(), [closePanel])

  return (
    <div className="domain-page execution-page" data-testid="execution-page">
      <section className="execution-hero">
        <div className="execution-hero-main">
          <div className="page-kicker">模拟执行</div>
          <h1>{data?.title ?? '模拟执行'}</h1>
          <p>{data?.subtitle ?? '围绕执行意图、模拟持仓、模拟成交和执行约束，统一查看当前执行上下文。'}</p>
          <div className="execution-flags">
            {(data?.filterChips ?? []).map((chip) => (
              <span key={chip.key} className="execution-mini-pill active">
                {chip.label}：{chip.value}
              </span>
            ))}
          </div>
        </div>
        <div className="execution-hero-side">
          <div className="execution-hero-side-title">当前状态</div>
          <strong>{getStatusTitle(activeTabState?.status ?? data?.dataStatus ?? 'fallback')}</strong>
          <p>{activeTabState?.note ?? data?.statusNote ?? '当前标签展示执行域数据。'}</p>
        </div>
      </section>

      <section className="execution-metrics">
        {(data?.metrics ?? []).map((metric) => (
          <article key={metric.key} className="execution-metric-card">
            <span>{metric.label}</span>
            <strong>{metric.value}</strong>
            <p>{metric.note}</p>
          </article>
        ))}
      </section>

      <section className="page-tabs execution-tabs">
        {(data?.tabs ?? []).map((tab) => (
          <button
            key={tab.key}
            type="button"
            className={tab.key === activeTab ? 'page-tab active' : 'page-tab'}
            onClick={() => setTab(tab.key)}
          >
            <span className="execution-tab-label">{tab.label}</span>
            <small className="execution-tab-desc">{tab.description}</small>
          </button>
        ))}
      </section>

      {loading ? <div className="page-banner">正在加载模拟执行数据...</div> : null}
      {error ? <div className="page-banner warning">模拟执行数据加载失败：{error}</div> : null}
      {data?.focusMissNote ? <div className="page-banner warning">{data.focusMissNote}</div> : null}

      <section className="execution-workspace">
        <div className="execution-main">
          <header className="section-header">
            <div>
              <h2>{getTabTitle(activeTab)}</h2>
              <p>{getTabDescription(activeTab)}</p>
              {!loading && !error && activeTabState ? (
                <div className={`execution-inline-state is-${activeTabState.status}`}>
                  <span className="execution-inline-state-label">{getStatusTitle(activeTabState.status)}</span>
                  <span className="execution-inline-state-note">{activeTabState.note}</span>
                </div>
              ) : null}
            </div>
          </header>

          {rows.length === 0 ? (
            <div className="empty-state">
              <h3>当前标签暂无可展示对象</h3>
              <p>你可以切换标签，或通过上游工作域重新带入执行意图。</p>
            </div>
          ) : (
            <div className="execution-list">
              {rows.map((row) => (
                <button
                  key={row.id}
                  type="button"
                  className={row.id === data?.selectedId ? 'execution-row selected' : 'execution-row'}
                  onClick={() => setFocus(row)}
                >
                  <div className="execution-row-top">
                    <div className="execution-row-copy">
                      <strong className="execution-row-title">
                        <span className="execution-row-name">{row.name}</span>{' '}
                        <span className="execution-row-code">{row.tsCode}</span>
                      </strong>
                      <p>{renderRowMeta(row)}</p>
                    </div>
                    <div className={`execution-status-pill execution-status-${row.constraintStatus}`}>
                      {row.constraintStatusLabel}
                    </div>
                  </div>
                  <div className="execution-row-summary">{row.summary}</div>
                  <div className="execution-row-bottom">
                    <span className="execution-pill execution-pill-source">{row.sourceLabel}</span>
                    <span className="execution-pill">{row.strategyLabel}</span>
                    <span className="execution-pill execution-pill-allow">{row.tradeAllowedLabel}</span>
                    <span className="execution-pill execution-pill-risk">{row.riskLevelLabel}</span>
                    <span className="execution-pill execution-pill-cap">{row.positionCapText}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        <aside className="execution-context">
          {data?.context ? (
            <>
              <header className="execution-context-header">
                <h3 className="execution-context-object-title">{data.context.title}</h3>
                <p>{data.context.subtitle}</p>
                <span>{data.context.sourceSummary}</span>
              </header>

              {data.context.sections.map((section) => (
                <section key={section.title} className="execution-context-section">
                  <h4 className="execution-context-section-heading">{section.title}</h4>
                  <div className="execution-context-grid">
                    {section.items.map((item) => (
                      <div key={item.label} className="execution-context-stat">
                        <span className="execution-context-stat-label">{item.label}</span>
                        <strong className="execution-context-stat-value">{item.value}</strong>
                      </div>
                    ))}
                  </div>
                </section>
              ))}

              <section className="execution-context-section">
                <h4>下一步建议</h4>
                <div className="execution-next-steps">
                  {data.context.nextSteps.map((step) => (
                    <article key={step.label} className="execution-next-step">
                      <strong>{step.label}</strong>
                      <p>{step.note}</p>
                    </article>
                  ))}
                </div>
                <button type="button" className="table-action-btn" onClick={openSystem}>
                  查看系统状态
                </button>
              </section>
            </>
          ) : (
            <div className="execution-context-empty-card">
              <div className="execution-context-empty-kicker">当前工作上下文</div>
              <h3>{data?.noFocus.title ?? '请选择一个执行对象'}</h3>
              <p>{data?.noFocus.description ?? '先从当前标签选择一条记录，再查看来源链路、风险结论和仓位建议。'}</p>
              <div className="execution-context-empty-list">
                <div className="execution-context-empty-item">
                  <strong>来源链路</strong>
                  <span>可承接 Signals、观察池、持仓中心和风控中心带来的执行意图。</span>
                </div>
                <div className="execution-context-empty-item">
                  <strong>风险结论</strong>
                  <span>右侧会展示允许执行、限制原因和当前风险等级。</span>
                </div>
                <div className="execution-context-empty-item">
                  <strong>仓位建议</strong>
                  <span>右侧会同步给出仓位上限、关联订单、持仓和成交关系。</span>
                </div>
                <button type="button" className="table-action-btn" onClick={openSystem}>
                  查看系统状态
                </button>
              </div>
            </div>
          )}
        </aside>
      </section>
    </div>
  )
}
