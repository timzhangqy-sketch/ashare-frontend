import { useEffect, useMemo } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { loadResearchWorkspace } from '../../adapters/research';
import {
  buildResearchBaseHref,
  buildResearchDetailHref,
  buildResearchDetailQuery,
  normalizeResearchDetailRouteTab,
  resolveResearchDetailViewModel,
} from '../../adapters/researchDetail';
import { useContextPanel } from '../../context/ContextPanelContext';
import { useApiData } from '../../hooks/useApiData';
import type { StockContextPanelPayload } from '../../types/contextPanel';
import type { BacktestDetailRow } from '../../types/research';
import type {
  AttributionDetailVm,
  BacktestDetailVm,
  FactorIcDetailVm,
  ResearchDetailTableColumn,
  ResearchDetailTableRow,
  ResearchDetailViewModel,
  ResonanceDetailVm,
} from '../../types/researchDetail';
import { getStrategyDisplayName } from '../../utils/displayNames';

function buildResearchContextPanelPayload(row: BacktestDetailRow): StockContextPanelPayload {
  return {
    title: row.name,
    name: row.name,
    tsCode: row.tsCode,
    sourceStrategy: row.strategy,
    subtitle: row.statusLabel,
    summary: `${getStrategyDisplayName(row.strategy) ?? row.strategy} · 入场 ${row.entryDate}`,
    tags: [
      { label: getStrategyDisplayName(row.strategy) ?? row.strategy, tone: 'strategy' },
      { label: row.statusLabel, tone: 'state' },
      { label: '研究中心', tone: 'source' },
    ],
    summaryItems: [
      { label: '策略', value: getStrategyDisplayName(row.strategy) ?? row.strategy },
      { label: '入场日期', value: row.entryDate },
      { label: '入场价', value: row.entryPrice.toFixed(2) },
      { label: 'T+5', value: row.horizonReturns.T5 != null ? `${row.horizonReturns.T5.toFixed(2)}%` : '--' },
    ],
    actions: [
      {
        label: '风控中心',
        href: `/risk?tab=breakdown&source=research&focus=${encodeURIComponent(row.tsCode)}`,
        note: '继续查看该标的的风险上下文。',
      },
      {
        label: '持仓中心',
        href: `/portfolio?source=research&focus=${encodeURIComponent(row.tsCode)}`,
        note: '继续查看该标的在持仓中心的状态。',
      },
    ],
  };
}

function DetailBanner({ vm }: { vm: ResearchDetailViewModel }) {
  return (
    <div className={`research-state-banner is-${vm.status}`}>
      <div className="research-state-title">{vm.sourceLabel}</div>
      <div className="research-state-note">{vm.sourceNote}</div>
    </div>
  );
}

function SummaryGrid({ items }: { items: ResearchDetailViewModel['summaryCards'] }) {
  return (
    <div className="research-detail-grid">
      {items.map(item => (
        <div key={`${item.label}-${item.value}`} className={`research-detail-stat tone-${item.tone ?? 'default'}`}>
          <span>{item.label}</span>
          <strong>{item.value}</strong>
        </div>
      ))}
    </div>
  );
}

function InfoGrid({ items }: { items: ResearchDetailViewModel['infoCards'] }) {
  return (
    <div className="research-detail-grid">
      {items.map(item => (
        <div key={`${item.label}-${item.value}`} className="research-detail-stat muted">
          <span>{item.label}</span>
          <strong>{item.value}</strong>
        </div>
      ))}
    </div>
  );
}

function NotesBlock({ items }: { items: string[] }) {
  return (
    <div className="risk-context-list">
      {items.map(item => (
        <div key={item} className="risk-context-list-row">
          <span className="risk-context-list-value">{item}</span>
        </div>
      ))}
    </div>
  );
}

function ChartCard({
  title,
  description,
  status,
  data,
  emptyText,
}: {
  title: string;
  description: string;
  status: 'real' | 'fallback' | 'placeholder';
  data: Array<{ label: string; value: number; secondaryValue?: number }>;
  emptyText?: string;
}) {
  return (
    <section className="card">
      <div className="card-header">
        <span className="card-title">{title}</span>
        <span className={`research-chart-badge is-${status}`}>{status === 'real' ? '真实数据' : status === 'fallback' ? '兼容回退' : '占位'}</span>
      </div>
      <div className={`research-detail-chart-shell is-${status}`}>
        <div className="research-detail-chart-copy">{description}</div>
        {data.length === 0 ? (
          <div className="research-detail-chart-empty">{emptyText ?? '当前没有可展示的图表数据。'}</div>
        ) : (
          <div className="research-chart-list">
            {data.map(item => (
              <div key={`${title}-${item.label}`} className="research-chart-list-row">
                <span>{item.label}</span>
                <strong>{item.value.toFixed(2)}</strong>
                {item.secondaryValue != null ? <span className="c-muted">{item.secondaryValue.toFixed(2)}</span> : null}
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function TableSection({
  title,
  note,
  columns,
  rows,
  selectedFocus,
  onRowClick,
}: {
  title: string;
  note: string;
  columns: ResearchDetailTableColumn[];
  rows: ResearchDetailTableRow[];
  selectedFocus: string | null;
  onRowClick?: (row: ResearchDetailTableRow) => void;
}) {
  return (
    <section className="card">
      <div className="card-header">
        <span className="card-title">{title}</span>
        <span className="c-muted" style={{ fontSize: 12 }}>{note}</span>
      </div>
      <div className="research-table-shell">
        <table className="data-table research-compare-table">
          <thead>
            <tr>
              <th>对象</th>
              {columns.map(column => (
                <th key={column.key} className={column.align === 'right' ? 'right' : column.align === 'center' ? 'center' : undefined}>
                  {column.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length + 1}>
                  <div className="risk-breakdown-empty">
                    <div className="risk-empty-title">当前没有可展示的数据</div>
                    <div className="risk-empty-text">请调整来源、策略或交易日后重试。</div>
                  </div>
                </td>
              </tr>
            ) : rows.map(row => (
              <tr
                key={row.id}
                className={selectedFocus && row.stockFocus?.tsCode === selectedFocus ? 'research-table-row selected' : 'research-table-row'}
                onClick={() => onRowClick?.(row)}
              >
                <td>
                  <div className="risk-cell-title">{row.title}</div>
                  {row.subtitle ? <div className="risk-inline-meta">{row.subtitle}</div> : null}
                </td>
                {columns.map(column => {
                  const cell = row.cells[column.key];
                  return (
                    <td key={column.key} className={column.align === 'right' ? 'right' : column.align === 'center' ? 'center' : undefined}>
                      <div className={`research-detail-cell tone-${cell?.tone ?? 'default'}`}>
                        <span>{cell?.value ?? '--'}</span>
                        {cell?.subValue ? <div className="risk-inline-meta">{cell.subValue}</div> : null}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function BacktestSection({ vm, onOpenStockSample }: { vm: BacktestDetailVm; onOpenStockSample: (row: ResearchDetailTableRow) => void }) {
  return (
    <>
      <section className="card">
        <div className="card-header">
          <span className="card-title">回测摘要</span>
          <span className="c-muted" style={{ fontSize: 12 }}>围绕当前策略查看样本收益与关键指标。</span>
        </div>
        <SummaryGrid items={vm.summaryCards} />
      </section>
      <TableSection title="样本明细" note={vm.sampleNote} columns={vm.sampleColumns} rows={vm.sampleRows} selectedFocus={vm.selectedFocus} onRowClick={onOpenStockSample} />
      <div className="research-detail-chart-grid">
        <ChartCard {...vm.charts.performanceSeries} />
        <ChartCard {...vm.charts.horizonBars} />
        <ChartCard {...vm.charts.returnDistribution} />
      </div>
    </>
  );
}

function FactorSection({ vm }: { vm: FactorIcDetailVm }) {
  return (
    <>
      <section className="card">
        <div className="card-header">
          <span className="card-title">因子摘要</span>
          <span className="c-muted" style={{ fontSize: 12 }}>查看因子 IC、ICIR 与分桶表现。</span>
        </div>
        <SummaryGrid items={vm.summaryCards} />
      </section>
      <TableSection title="分桶表现" note={vm.bucketNote} columns={vm.bucketColumns} rows={vm.bucketRows} selectedFocus={null} />
      <div className="research-detail-chart-grid">
        <ChartCard {...vm.charts.icSeries} />
        <ChartCard {...vm.charts.bucketBars} />
        <ChartCard {...vm.charts.layerProfile} />
      </div>
    </>
  );
}

function AttributionSection({ vm }: { vm: AttributionDetailVm }) {
  return (
    <>
      <section className="card">
        <div className="card-header">
          <span className="card-title">归因摘要</span>
          <span className="c-muted" style={{ fontSize: 12 }}>查看当前分组的收益、胜率与回撤表现。</span>
        </div>
        <SummaryGrid items={vm.summaryCards} />
      </section>
      <TableSection title="分组对比" note={vm.contributionNote} columns={vm.contributionColumns} rows={vm.contributionRows} selectedFocus={null} />
      <div className="research-detail-chart-grid">
        <ChartCard {...vm.charts.contributionBars} />
        <ChartCard {...vm.charts.groupCompare} />
        <ChartCard {...vm.charts.drawdownCompare} />
      </div>
    </>
  );
}

function ResonanceSection({ vm, onOpenStockSample }: { vm: ResonanceDetailVm; onOpenStockSample: (row: ResearchDetailTableRow) => void }) {
  return (
    <>
      <section className="card">
        <div className="card-header">
          <span className="card-title">共振摘要</span>
          <span className="c-muted" style={{ fontSize: 12 }}>查看策略组合的共振强度与超额收益。</span>
        </div>
        <SummaryGrid items={vm.summaryCards} />
      </section>
      <TableSection title="命中样本" note={vm.hitNote} columns={vm.hitColumns} rows={vm.hitRows} selectedFocus={vm.selectedFocus} onRowClick={onOpenStockSample} />
      <div className="research-detail-chart-grid">
        <ChartCard {...vm.charts.intensityBars} />
        <ChartCard {...vm.charts.excessBars} />
        <ChartCard {...vm.charts.hitPerformance} />
      </div>
    </>
  );
}

function DetailBody({ vm, onOpenStockSample }: { vm: ResearchDetailViewModel; onOpenStockSample: (row: ResearchDetailTableRow) => void }) {
  if (vm.kind === 'backtest') return <BacktestSection vm={vm} onOpenStockSample={onOpenStockSample} />;
  if (vm.kind === 'factor-ic') return <FactorSection vm={vm} />;
  if (vm.kind === 'attribution') return <AttributionSection vm={vm} />;
  return <ResonanceSection vm={vm} onOpenStockSample={onOpenStockSample} />;
}

export default function ResearchDetailPage() {
  const navigate = useNavigate();
  const { detailTab: detailTabParam, detailKey: detailKeyParam } = useParams();
  const [searchParams] = useSearchParams();
  const routeTab = normalizeResearchDetailRouteTab(detailTabParam);
  const { openPanel, closePanel } = useContextPanel();

  useEffect(() => {
    if (!routeTab) navigate('/research', { replace: true });
  }, [routeTab, navigate]);

  const query = useMemo(() => {
    if (!routeTab) return null;
    return buildResearchDetailQuery(routeTab, searchParams, detailKeyParam ?? '');
  }, [routeTab, searchParams, detailKeyParam]);

  const { data, loading, error, refetch } = useApiData(
    () => (query ? loadResearchWorkspace(query) : Promise.resolve(null)),
    [routeTab ?? 'invalid', detailKeyParam ?? '', searchParams.toString()],
  );

  const detailVm = useMemo(() => {
    if (!routeTab || !query || !data) return null;
    return resolveResearchDetailViewModel(data, routeTab, detailKeyParam, query);
  }, [routeTab, query, data, detailKeyParam]);

  useEffect(() => {
    if (!detailVm || detailVm.kind !== 'backtest' || !detailVm.focusSample) {
      closePanel();
      return;
    }

    openPanel({
      entityType: 'stock',
      entityKey: detailVm.focusSample.tsCode,
      sourcePage: 'research',
      focus: detailVm.focusSample.tsCode,
      activeTab: 'summary',
      payloadVersion: 'v1',
      payload: buildResearchContextPanelPayload(detailVm.focusSample),
    });
  }, [detailVm, openPanel, closePanel]);

  useEffect(() => () => closePanel(), [closePanel]);

  if (!routeTab || !query) return null;

  const backHref = detailVm?.backHref ?? buildResearchBaseHref(query);

  const openStockSample = (row: ResearchDetailTableRow) => {
    if (!detailVm || !row.stockFocus) return;

    if (detailVm.kind === 'backtest') {
      navigate(buildResearchDetailHref('backtest', detailVm.detailKey, {
        ...detailVm.query,
        strategy: row.stockFocus.strategy,
        focus: row.stockFocus.tsCode,
      }));
      return;
    }

    if (detailVm.kind === 'resonance') {
      navigate(buildResearchDetailHref('resonance', detailVm.detailKey, {
        ...detailVm.query,
        focus: row.stockFocus.tsCode,
      }));
    }
  };

  return (
    <div className="research-page research-detail-page" data-testid="research-detail-page">
      <section className="card research-detail-hero">
        <div className="research-detail-hero-main">
          <button type="button" className="research-detail-back" onClick={() => navigate(backHref)}>
            返回研究中心
          </button>
          <div className="risk-kicker">
            {detailVm?.kind === 'backtest'
              ? '回测明细'
              : detailVm?.kind === 'factor-ic'
                ? '因子明细'
                : detailVm?.kind === 'attribution'
                  ? '归因明细'
                  : '共振明细'}
          </div>
          <div className="research-hero-headline">
            <h1>{detailVm?.title ?? '研究明细'}</h1>
            <p>{detailVm?.subtitle ?? '围绕当前研究对象继续查看详细结果。'}</p>
          </div>
          <div className="research-context-chips">
            {(detailVm?.sourceBadges ?? []).map(item => (
              <span key={`${item.label}-${item.value}`} className="research-filter-chip">
                {item.label}: {item.value}
              </span>
            ))}
          </div>
        </div>
      </section>

      {detailVm ? <DetailBanner vm={detailVm} /> : null}

      {loading ? (
        <div className="card risk-loading-state">
          <div className="spinner" />
          <span>加载研究明细中...</span>
        </div>
      ) : null}

      {!loading && error ? (
        <div className="page-error">
          <div className="page-error-msg">研究明细加载失败</div>
          <div className="page-error-detail">{error}</div>
          <button className="retry-btn" onClick={refetch}>重试</button>
        </div>
      ) : null}

      {!loading && !error && detailVm ? (
        <div className="research-detail-layout" data-testid="research-detail-body">
          <DetailBody vm={detailVm} onOpenStockSample={openStockSample} />

          <section className="card">
            <div className="card-header">
              <span className="card-title">筛选上下文</span>
              <span className="c-muted" style={{ fontSize: 12 }}>当前页面承接的来源、策略与过滤条件。</span>
            </div>
            <InfoGrid items={detailVm.infoCards} />
          </section>

          <section className="card">
            <div className="card-header">
              <span className="card-title">说明</span>
              <span className="c-muted" style={{ fontSize: 12 }}>当前明细页的补充说明与兼容提示。</span>
            </div>
            <NotesBlock items={detailVm.notes} />
          </section>
        </div>
      ) : null}
    </div>
  );
}
