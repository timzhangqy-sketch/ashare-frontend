import { useState } from 'react';
import StockDrawer from '../components/Drawer/StockDrawer';
import WatchlistTab from '../components/WatchlistTab';
import { CrossTags } from '../components/CrossTags';
import { useDate } from '../context/DateContext';
import { useApiData } from '../hooks/useApiData';
import {
  fetchPatternGreen10,
  fetchPatternT2up9,
  type PatternGreen10Item,
  type PatternT2up9Item,
} from '../api';
import type { StockDetail } from '../types/stock';
import { getMockDetail } from '../utils/score';

type MainTab = 'today' | 'watchlist';
type PatternTab = 't2' | 'green10';
type WatchlistSub = 'PATTERN_T2UP9' | 'PATTERN_GREEN10';

function formatPercent(value: number | null | undefined, decimal = true): string {
  if (value == null) return '--';
  const pct = decimal ? value * 100 : value;
  return `${pct > 0 ? '+' : ''}${pct.toFixed(1)}%`;
}

function openPatternStock(tsCode: string, name: string, strategy: string, pctChg: number): StockDetail {
  return getMockDetail(tsCode, name, [strategy], 0, pctChg);
}

function T2Table({ selectedDate, onOpen }: { selectedDate: string; onOpen: (stock: StockDetail) => void }) {
  const { data, loading, error, refetch } = useApiData(() => fetchPatternT2up9(selectedDate), [selectedDate]);
  const rows = data ?? [];

  return (
    <>
      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">形态样本</div>
          <div className="stat-value c-red">{loading ? '--' : rows.length}</div>
          <div className="stat-sub">T-2 大阳触发样本</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">观察池命中</div>
          <div className="stat-value c-blue">{loading ? '--' : rows.filter(row => row.in_pool).length}</div>
          <div className="stat-sub">当前仍在观察池</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">延续跟踪</div>
          <div className="stat-value c-cyan">{loading ? '--' : rows.filter(row => row.in_continuation).length}</div>
          <div className="stat-sub">进入延续跟踪</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">T+2 平均收益</div>
          <div className="stat-value c-gold">
            {loading ? '--' : formatPercent(rows.length ? rows.reduce((sum, row) => sum + (row.ret_2d ?? 0), 0) / rows.length : 0)}
          </div>
          <div className="stat-sub">形态样本后续表现</div>
        </div>
      </div>

      <section className="card">
        <div className="card-header">
          <span className="card-title">T-2 强势形态</span>
          <span className="c-muted" style={{ fontSize: 12 }}>形态策略样本列表，承接旧形态扫描页语义</span>
        </div>

        {loading ? <div className="page-loading"><div className="spinner" />加载中...</div> : null}
        {!loading && error ? (
          <div className="page-error">
            <div className="page-error-msg">形态策略加载失败</div>
            <div className="page-error-detail">{error}</div>
            <button className="retry-btn" onClick={refetch}>重试</button>
          </div>
        ) : null}

        {!loading && !error ? (
          <div className="data-table-shell">
            <table className="data-table">
              <thead>
                <tr>
                  <th>股票</th>
                  <th className="right">T-2</th>
                  <th className="right">T-1</th>
                  <th className="right">T</th>
                  <th className="right">T+2</th>
                  <th className="center">观察池</th>
                  <th className="center">延续</th>
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 ? (
                  <tr>
                    <td colSpan={7}>
                      <div className="empty-state">
                        <div className="empty-text">当前交易日没有形态策略样本。</div>
                      </div>
                    </td>
                  </tr>
                ) : rows.map((row: PatternT2up9Item) => (
                  <tr key={row.ts_code} onClick={() => onOpen(openPatternStock(row.ts_code, row.name, '形态策略', (row.ret_t0 ?? 0) * 100))}>
                    <td>
                      <div className="watchlist-cell-title">
                        {row.name}
                        <CrossTags tsCode={row.ts_code} currentStrategy="PATTERN_T2UP9" />
                      </div>
                      <div className="watchlist-inline-meta">{row.ts_code}</div>
                    </td>
                    <td className="right">{formatPercent(row.ret_t2)}</td>
                    <td className="right">{formatPercent(row.ret_t1)}</td>
                    <td className="right">{formatPercent(row.ret_t0)}</td>
                    <td className="right">{formatPercent(row.ret_2d)}</td>
                    <td className="center">{row.in_pool ? '是' : '否'}</td>
                    <td className="center">{row.in_continuation ? '是' : '否'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </section>
    </>
  );
}

function Green10Table({ selectedDate, onOpen }: { selectedDate: string; onOpen: (stock: StockDetail) => void }) {
  const { data, loading, error, refetch } = useApiData(() => fetchPatternGreen10(selectedDate), [selectedDate]);
  const rows = data ?? [];

  return (
    <>
      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">形态样本</div>
          <div className="stat-value c-red">{loading ? '--' : rows.length}</div>
          <div className="stat-sub">10 日形态样本</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">最高绿柱数</div>
          <div className="stat-value c-blue">{loading ? '--' : (rows.length ? Math.max(...rows.map(row => row.green_days_10d)) : 0)}</div>
          <div className="stat-sub">近 10 日窗口</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">平均绿柱数</div>
          <div className="stat-value c-cyan">
            {loading ? '--' : (rows.length ? (rows.reduce((sum, row) => sum + row.green_days_10d, 0) / rows.length).toFixed(1) : '0.0')}
          </div>
          <div className="stat-sub">形态强度</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">观察池命中</div>
          <div className="stat-value c-gold">{loading ? '--' : rows.filter(row => row.in_pool).length}</div>
          <div className="stat-sub">当前仍在观察池</div>
        </div>
      </div>

      <section className="card">
        <div className="card-header">
          <span className="card-title">10 日形态</span>
          <span className="c-muted" style={{ fontSize: 12 }}>形态策略样本列表，承接旧 10 日窗口扫描页语义</span>
        </div>

        {loading ? <div className="page-loading"><div className="spinner" />加载中...</div> : null}
        {!loading && error ? (
          <div className="page-error">
            <div className="page-error-msg">形态策略加载失败</div>
            <div className="page-error-detail">{error}</div>
            <button className="retry-btn" onClick={refetch}>重试</button>
          </div>
        ) : null}

        {!loading && !error ? (
          <div className="data-table-shell">
            <table className="data-table">
              <thead>
                <tr>
                  <th>股票</th>
                  <th className="right">绿柱</th>
                  <th className="right">红柱</th>
                  <th className="right">平柱</th>
                  <th className="center">观察池</th>
                  <th className="center">延续</th>
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 ? (
                  <tr>
                    <td colSpan={6}>
                      <div className="empty-state">
                        <div className="empty-text">当前交易日没有形态策略样本。</div>
                      </div>
                    </td>
                  </tr>
                ) : rows.map((row: PatternGreen10Item) => (
                  <tr key={row.ts_code} onClick={() => onOpen(openPatternStock(row.ts_code, row.name, '形态策略', 0))}>
                    <td>
                      <div className="watchlist-cell-title">
                        {row.name}
                        <CrossTags tsCode={row.ts_code} currentStrategy="PATTERN_GREEN10" />
                      </div>
                      <div className="watchlist-inline-meta">{row.ts_code}</div>
                    </td>
                    <td className="right">{row.green_days_10d}</td>
                    <td className="right">{row.red_days_10d}</td>
                    <td className="right">{row.flat_days_10d}</td>
                    <td className="center">{row.in_pool ? '是' : '否'}</td>
                    <td className="center">{row.in_continuation ? '是' : '否'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </section>
    </>
  );
}

export default function PatternScreen() {
  const { selectedDate } = useDate();
  const [mainTab, setMainTab] = useState<MainTab>('today');
  const [patternTab, setPatternTab] = useState<PatternTab>('t2');
  const [watchlistSub, setWatchlistSub] = useState<WatchlistSub>('PATTERN_T2UP9');
  const [selected, setSelected] = useState<StockDetail | null>(null);
  const [buyMode, setBuyMode] = useState(false);

  return (
    <div className="pattern-page" data-testid="pattern-page">
      <div className="page-header">
        <div>
          <div className="page-title">
            形态策略
            <span className="page-badge badge-blue">技术分析</span>
          </div>
          <div className="page-desc">基于形态策略规则自动扫描 K 线形态机会 · {selectedDate}</div>
        </div>
      </div>

      <div className="page-tabs">
        <button type="button" className={`page-tab-btn${mainTab === 'today' ? ' active' : ''}`} onClick={() => setMainTab('today')}>
          今日样本
        </button>
        <button type="button" className={`page-tab-btn${mainTab === 'watchlist' ? ' active' : ''}`} onClick={() => setMainTab('watchlist')}>
          观察池承接
        </button>
      </div>

      {mainTab === 'watchlist' ? (
        <>
          <div className="page-tabs" style={{ marginBottom: 16 }}>
            <button type="button" className={`page-tab-btn${watchlistSub === 'PATTERN_T2UP9' ? ' active' : ''}`} onClick={() => setWatchlistSub('PATTERN_T2UP9')}>
              T-2 强势形态
            </button>
            <button type="button" className={`page-tab-btn${watchlistSub === 'PATTERN_GREEN10' ? ' active' : ''}`} onClick={() => setWatchlistSub('PATTERN_GREEN10')}>
              10 日形态
            </button>
          </div>

          <WatchlistTab
            key={watchlistSub}
            strategy={watchlistSub}
            onOpen={stock => {
              setBuyMode(false);
              setSelected(stock);
            }}
            onBuy={stock => {
              setBuyMode(true);
              setSelected(stock);
            }}
          />
        </>
      ) : (
        <>
          <div className="page-tabs" style={{ marginBottom: 16 }}>
            <button type="button" className={`page-tab-btn${patternTab === 't2' ? ' active' : ''}`} onClick={() => setPatternTab('t2')}>
              T-2 强势形态
            </button>
            <button type="button" className={`page-tab-btn${patternTab === 'green10' ? ' active' : ''}`} onClick={() => setPatternTab('green10')}>
              10 日形态
            </button>
          </div>

          {patternTab === 't2' ? <T2Table selectedDate={selectedDate} onOpen={setSelected} /> : <Green10Table selectedDate={selectedDate} onOpen={setSelected} />}
        </>
      )}

      <StockDrawer
        stock={selected}
        autoOpenBuyForm={buyMode}
        onClose={() => {
          setSelected(null);
          setBuyMode(false);
        }}
      />
    </div>
  );
}
