export type WatchlistViewKey = 'table' | 'group' | 'heat';
export type WatchlistLifecycleStatus = 'candidate' | 'signaled' | 'handed_off' | 'blocked';
export type WatchlistSignalFilter = 'all' | 'buy' | 'sell' | 'any' | 'none';
export type WatchlistGroupBy = 'lifecycle' | 'strategy';
export type WatchlistActionKind = 'detail' | 'strategy' | 'portfolio' | 'risk' | 'placeholder';

export interface WatchlistMetricVm {
  label: string;
  value: string;
  helper: string;
}

export interface WatchlistFilterVm {
  label: string;
  value: string;
}

export interface WatchlistFilterOptionVm {
  label: string;
  value: string;
}

export interface WatchlistActionVm {
  key: string;
  label: string;
  kind: WatchlistActionKind;
  disabled?: boolean;
  href?: string | null;
  note?: string;
  summaryType?: 'detail' | 'jump' | 'handoff' | 'placeholder';
}

export interface WatchlistRowVm {
  id: string;
  tsCode: string;
  name: string;
  strategy: string;
  entryDate: string;
  poolDay: number;
  latestPctChg: number;
  gainSinceEntry: number;
  buySignal: string | null;
  sellSignal: string | null;
  vrToday: number | null;
  lifecycleStatus: WatchlistLifecycleStatus;
  lifecycleStatusLabel: string;
  lifecycleStatusOrigin: 'derived';
  inPortfolio: boolean;
  portfolioStatus: string | null;
  portfolioId: number | null;
  crossTags: string[];
  signalState: WatchlistSignalFilter;
  signalLabel: string;
  sourceLabel: string;
  sourceOrigin: 'primary' | 'derived';
  availableActions: WatchlistActionVm[];
}

export interface WatchlistGroupVm {
  key: string;
  label: string;
  helper: string;
  count: number;
  rows: WatchlistRowVm[];
}

export interface WatchlistFiltersVm {
  statusOptions: WatchlistFilterOptionVm[];
  strategyOptions: WatchlistFilterOptionVm[];
  signalOptions: WatchlistFilterOptionVm[];
}

export interface WatchlistWorkspaceVm {
  tradeDate: string;
  totalCount: number;
  rows: WatchlistRowVm[];
  metrics: WatchlistMetricVm[];
  filters: WatchlistFilterVm[];
  filterOptions: WatchlistFiltersVm;
  viewOptions: Array<{
    key: WatchlistViewKey;
    label: string;
    helper: string;
    enabled: boolean;
  }>;
  groupByOptions: WatchlistFilterOptionVm[];
  groups: WatchlistGroupVm[];
  emptyTitle: string;
  emptyText: string;
  sourceNotes: string[];
}

export interface WatchlistQueryState {
  source: string | null;
  focus: string | null;
  strategy: string | null;
  status: string | null;
  signal: string | null;
  query: string | null;
  view: WatchlistViewKey;
  groupBy: WatchlistGroupBy;
}
