import type { DashboardRuntimeSnapshot } from '../context/DashboardRuntimeContext';
import type {
  DashboardKpiVm,
  DashboardMetricVm,
  DashboardSectionVm,
  DashboardSummaryDto,
  DashboardViewModel,
  HealthStatus,
  OpportunityCardVm,
  OpportunitySectionVm,
  PortfolioSectionVm,
  RawDashboardSummaryPayload,
  RawDashboardSummaryResponse,
  RiskEventVm,
  RiskSectionVm,
  StatusTone,
  SystemHealthSectionVm,
  SystemIssueVm,
  TodaySummaryViewModel,
} from '../types/dashboard';

export const dashboardKpiLinkMap = {
  buySignalsCount: '/signals?tab=buy&source=dashboard',
  resonanceCount: '/signals?tab=resonance&source=dashboard',
  watchlistCandidates: '/watchlist',
  gateBlockedCount: '/risk?source=dashboard',
  highRiskPositionsCount: '/risk?source=dashboard&scope=portfolio',
  positionsCount: '/portfolio',
  sellSignalsCount: '/portfolio',
  failedStepsCount: '/system?source=dashboard&tab=pipeline',
  versionLabel: '/system?source=dashboard&tab=runlog',
} as const;

function normalizeHealthStatus(value: string): HealthStatus {
  const normalized = value.trim().toLowerCase();
  if (normalized === 'ok') return 'healthy';
  if (normalized === 'warning' || normalized === 'warn') return 'warning';
  return 'danger';
}

function formatPercent(value: number, digits = 1): string {
  return `${(value * 100).toFixed(digits)}%`;
}

function formatDateTime(value: string): string {
  return value.replace('T', ' ').replace(/\.\d+/, '').replace(/\+\d{2}:\d{2}$/, '');
}

function formatSignedPercent(value: number, digits = 2): string {
  const pct = value * 100;
  return `${pct > 0 ? '+' : pct < 0 ? '-' : ''}${Math.abs(pct).toFixed(digits)}%`;
}

function formatMoney(value: number): string {
  if (value >= 100000000) return `${(value / 100000000).toFixed(2)}亿`;
  if (value >= 10000) return `${(value / 10000).toFixed(1)}万`;
  return `${value.toFixed(0)}`;
}

function formatSignedMoney(value: number): string {
  const sign = value > 0 ? '+' : value < 0 ? '-' : '';
  return `${sign}${formatMoney(Math.abs(value))}`;
}

function toneFromHealth(status: HealthStatus): StatusTone {
  if (status === 'healthy') return 'positive';
  if (status === 'warning') return 'warning';
  return 'danger';
}

function toneFromDelta(value: number): StatusTone {
  if (value > 0) return 'positive';
  if (value < 0) return 'danger';
  return 'neutral';
}

function unwrapRawSummary(raw: RawDashboardSummaryResponse): RawDashboardSummaryPayload {
  return raw.data ?? raw;
}

export function buildSectionState(hasItems: boolean, hasSignal: boolean): DashboardSectionVm['state'] {
  return hasItems || hasSignal ? 'normal' : 'empty';
}

export function mapRawDashboardResponseToDto(
  raw: RawDashboardSummaryResponse,
): DashboardSummaryDto {
  const payload = unwrapRawSummary(raw);

  return {
    tradeDate: payload.trade_date,
    generatedAt: payload.generated_at,
    versionSnapshot: payload.version_snapshot,
    todayChanges: {
      newSignals: payload.today_changes.new_signals,
      removedSignals: payload.today_changes.removed_signals,
      watchlistDelta: payload.today_changes.watchlist_delta,
      portfolioDelta: payload.today_changes.portfolio_delta,
      riskAlertsDelta: payload.today_changes.risk_alerts_delta,
      systemAlertsDelta: payload.today_changes.system_alerts_delta,
      summaryText: payload.today_changes.summary_text,
    },
    opportunity: {
      buySignalsCount: payload.opportunity.buy_signals_count,
      resonanceCount: payload.opportunity.resonance_count,
      watchlistCandidates: payload.opportunity.watchlist_candidates,
      strongestStrategyLabel: payload.opportunity.strongest_strategy_label,
      hottestSectorLabel: payload.opportunity.hottest_sector_label,
      actionableCount: payload.opportunity.actionable_count,
      topOpportunities: payload.opportunity.top_opportunities.map(item => ({
        tsCode: item.ts_code,
        name: item.name,
        strategyLabel: item.strategy_label,
        sectorLabel: item.sector_label,
        score: item.score,
        hint: item.hint,
      })),
    },
    risk: {
      gateBlockedCount: payload.risk.gate_blocked_count,
      highRiskWatchlistCount: payload.risk.high_risk_watchlist_count,
      highRiskPositionsCount: payload.risk.high_risk_positions_count,
      newRiskEventsCount: payload.risk.new_risk_events_count,
      highestRiskName: payload.risk.highest_risk_name,
      highestRiskScore: payload.risk.highest_risk_score,
      riskHint: payload.risk.risk_hint,
    },
    portfolio: {
      positionType: payload.portfolio.position_type,
      positionsCount: payload.portfolio.positions_count,
      totalMarketValue: payload.portfolio.total_market_value,
      cashRatio: payload.portfolio.cash_ratio,
      dailyPnl: payload.portfolio.daily_pnl,
      dailyPnlPct: payload.portfolio.daily_pnl_pct,
      cumulativePnlPct: payload.portfolio.cumulative_pnl_pct,
      concentrationTop1: payload.portfolio.concentration_top1,
      sellSignalsCount: payload.portfolio.sell_signals_count,
      actionHint: payload.portfolio.action_hint,
    },
    systemHealth: {
      pipelineStatus: normalizeHealthStatus(payload.system_health.pipeline_status),
      latestSuccessTime: payload.system_health.latest_success_time,
      failedStepsCount: payload.system_health.failed_steps_count,
      dataCoveragePct: payload.system_health.data_coverage_pct,
      dqStatus: normalizeHealthStatus(payload.system_health.dq_status),
      apiHealthStatus: normalizeHealthStatus(payload.system_health.api_health_status),
      versionLabel: payload.system_health.version_label,
      systemHint: payload.system_health.system_hint,
    },
  };
}

function buildTodaySummary(dto: DashboardSummaryDto): TodaySummaryViewModel {
  const metrics: DashboardMetricVm[] = [
    {
      id: 'new-signals',
      label: '新增信号',
      value: `${dto.todayChanges.newSignals}`,
      helperText: '今天新增买点信号数',
      tone: dto.todayChanges.newSignals > 0 ? 'positive' : 'neutral',
    },
    {
      id: 'removed-signals',
      label: '移除信号',
      value: `${dto.todayChanges.removedSignals}`,
      helperText: '今天退出关注的信号数',
      tone: dto.todayChanges.removedSignals > 0 ? 'warning' : 'neutral',
    },
    {
      id: 'watchlist-delta',
      label: '观察池变化',
      value: `${dto.todayChanges.watchlistDelta > 0 ? '+' : ''}${dto.todayChanges.watchlistDelta}`,
      helperText: '观察池净变动',
      tone: toneFromDelta(dto.todayChanges.watchlistDelta),
    },
    {
      id: 'portfolio-delta',
      label: '组合变化',
      value: `${dto.todayChanges.portfolioDelta > 0 ? '+' : ''}${dto.todayChanges.portfolioDelta}`,
      helperText: '组合动作净变动',
      tone: toneFromDelta(dto.todayChanges.portfolioDelta),
    },
    {
      id: 'risk-delta',
      label: '风险提醒',
      value: `${dto.todayChanges.riskAlertsDelta > 0 ? '+' : ''}${dto.todayChanges.riskAlertsDelta}`,
      helperText: '新增风险提醒',
      tone: dto.todayChanges.riskAlertsDelta > 0 ? 'warning' : 'neutral',
    },
    {
      id: 'system-delta',
      label: '系统提醒',
      value: `${dto.todayChanges.systemAlertsDelta > 0 ? '+' : ''}${dto.todayChanges.systemAlertsDelta}`,
      helperText: '新增系统告警',
      tone: dto.todayChanges.systemAlertsDelta > 0 ? 'danger' : 'neutral',
    },
  ];

  return {
    headline: '今日关注摘要',
    summaryText: dto.todayChanges.summaryText,
    metrics,
  };
}

export function buildDashboardKpis(dto: DashboardSummaryDto): DashboardKpiVm[] {
  return [
    {
      id: 'buySignalsCount',
      label: '今日机会',
      value: `${dto.opportunity.buySignalsCount}`,
      helperText: '买点信号数',
      tone: dto.opportunity.buySignalsCount > 0 ? 'positive' : 'neutral',
      href: dashboardKpiLinkMap.buySignalsCount,
    },
    {
      id: 'resonanceCount',
      label: '共振机会',
      value: `${dto.opportunity.resonanceCount}`,
      helperText: `最强策略 ${dto.opportunity.strongestStrategyLabel}`,
      tone: dto.opportunity.resonanceCount > 0 ? 'info' : 'neutral',
      href: dashboardKpiLinkMap.resonanceCount,
    },
    {
      id: 'watchlistCandidates',
      label: '观察池候选',
      value: `${dto.opportunity.watchlistCandidates}`,
      helperText: `热点方向 ${dto.opportunity.hottestSectorLabel}`,
      tone: dto.opportunity.watchlistCandidates > 0 ? 'info' : 'neutral',
      href: dashboardKpiLinkMap.watchlistCandidates,
    },
    {
      id: 'gateBlockedCount',
      label: '风控拦截',
      value: `${dto.risk.gateBlockedCount}`,
      helperText: dto.risk.riskHint,
      tone: dto.risk.gateBlockedCount > 0 ? 'warning' : 'positive',
      href: dashboardKpiLinkMap.gateBlockedCount,
    },
    {
      id: 'highRiskPositionsCount',
      label: '高风险持仓',
      value: `${dto.risk.highRiskPositionsCount}`,
      helperText: dto.risk.highestRiskName ? `最高风险 ${dto.risk.highestRiskName}` : '当前无高风险持仓',
      tone: dto.risk.highRiskPositionsCount > 0 ? 'danger' : 'positive',
      href: dashboardKpiLinkMap.highRiskPositionsCount,
    },
    {
      id: 'positionsCount',
      label: '持仓总览',
      value: `${dto.portfolio.positionsCount}`,
      helperText: `${dto.portfolio.positionType} · 总市值 ${formatMoney(dto.portfolio.totalMarketValue)}`,
      tone: dto.portfolio.positionsCount > 0 ? 'info' : 'neutral',
      href: dashboardKpiLinkMap.positionsCount,
    },
    {
      id: 'sellSignalsCount',
      label: '卖点提示',
      value: `${dto.portfolio.sellSignalsCount}`,
      helperText: dto.portfolio.actionHint,
      tone: dto.portfolio.sellSignalsCount > 0 ? 'warning' : 'neutral',
      href: dashboardKpiLinkMap.sellSignalsCount,
    },
    {
      id: 'failedStepsCount',
      label: '系统异常',
      value: `${dto.systemHealth.failedStepsCount}`,
      helperText: `最近成功 ${formatDateTime(dto.systemHealth.latestSuccessTime)}`,
      tone: dto.systemHealth.failedStepsCount > 0 ? 'danger' : 'positive',
      href: dashboardKpiLinkMap.failedStepsCount,
    },
    {
      id: 'versionLabel',
      label: '版本摘要',
      value: dto.systemHealth.versionLabel,
      helperText: dto.versionSnapshot,
      tone: toneFromHealth(dto.systemHealth.pipelineStatus),
      href: dashboardKpiLinkMap.versionLabel,
    },
  ];
}

function buildOpportunityCards(dto: DashboardSummaryDto): OpportunityCardVm[] {
  return dto.opportunity.topOpportunities.map(item => ({
    id: item.tsCode,
    name: item.name,
    strategyLabel: `${item.strategyLabel} / ${item.sectorLabel}`,
    scoreLabel: `${item.score.toFixed(2)}分`,
    helperText: item.hint,
    tone: item.score >= 85 ? 'positive' : item.score >= 75 ? 'info' : 'warning',
    href: `/signals?tab=buy&source=dashboard&focus=${encodeURIComponent(item.tsCode)}`,
  }));
}

function buildRiskEvents(dto: DashboardSummaryDto): RiskEventVm[] {
  if (dto.risk.gateBlockedCount === 0 && dto.risk.newRiskEventsCount === 0) return [];

  return [
    {
      id: 'gate-blocked',
      name: '风控拦截',
      summary: dto.risk.riskHint,
      scoreLabel: `${dto.risk.gateBlockedCount}`,
      helperText: dto.risk.highestRiskName
        ? `最高风险 ${dto.risk.highestRiskName} ${dto.risk.highestRiskScore.toFixed(2)}`
        : '当前无高风险持仓',
      tone: dto.risk.gateBlockedCount > 0 ? 'warning' : 'neutral',
      href: '/risk?source=dashboard',
    },
  ];
}

function buildSystemIssues(dto: DashboardSummaryDto): SystemIssueVm[] {
  if (dto.systemHealth.failedStepsCount === 0) return [];

  return [
    {
      id: 'failed-steps',
      name: '系统异常',
      summary: dto.systemHealth.systemHint,
      statusLabel: dto.systemHealth.pipelineStatus === 'healthy' ? '正常' : '异常',
      helperText: `失败步骤 ${dto.systemHealth.failedStepsCount}`,
      tone: dto.systemHealth.failedStepsCount > 0 ? 'danger' : 'positive',
      href: '/system?source=dashboard&tab=pipeline',
    },
  ];
}

function buildOpportunitySection(dto: DashboardSummaryDto): OpportunitySectionVm {
  const topOpportunities = buildOpportunityCards(dto);

  return {
    title: '机会',
    summary: `今天有 ${dto.opportunity.actionableCount} 个可执行机会，最强策略为 ${dto.opportunity.strongestStrategyLabel}。`,
    state: buildSectionState(topOpportunities.length > 0, dto.opportunity.buySignalsCount > 0),
    metrics: [
      {
        id: 'opp-buy',
        label: '买点信号',
        value: `${dto.opportunity.buySignalsCount}`,
        helperText: '今日可读买点数',
        tone: dto.opportunity.buySignalsCount > 0 ? 'positive' : 'neutral',
      },
      {
        id: 'opp-resonance',
        label: '共振机会',
        value: `${dto.opportunity.resonanceCount}`,
        helperText: '当前活跃交叉股数',
        tone: dto.opportunity.resonanceCount > 0 ? 'info' : 'neutral',
      },
      {
        id: 'opp-watchlist',
        label: '观察池候选',
        value: `${dto.opportunity.watchlistCandidates}`,
        helperText: '待进一步确认',
        tone: dto.opportunity.watchlistCandidates > 0 ? 'info' : 'neutral',
      },
      {
        id: 'opp-actionable',
        label: '可执行数',
        value: `${dto.opportunity.actionableCount}`,
        helperText: `热点方向 ${dto.opportunity.hottestSectorLabel}`,
        tone: dto.opportunity.actionableCount > 0 ? 'positive' : 'neutral',
      },
    ],
    topOpportunities,
  };
}

function buildRiskSection(dto: DashboardSummaryDto): RiskSectionVm {
  const events = buildRiskEvents(dto);

  return {
    title: '风控',
    summary: dto.risk.riskHint,
    state: buildSectionState(events.length > 0, dto.risk.gateBlockedCount > 0 || dto.risk.highRiskPositionsCount > 0),
    metrics: [
      {
        id: 'risk-gate',
        label: '风控拦截',
        value: `${dto.risk.gateBlockedCount}`,
        helperText: '被 gate 阻断的动作',
        tone: dto.risk.gateBlockedCount > 0 ? 'warning' : 'positive',
      },
      {
        id: 'risk-watchlist',
        label: '高风险观察池',
        value: `${dto.risk.highRiskWatchlistCount}`,
        helperText: '待重点复核',
        tone: dto.risk.highRiskWatchlistCount > 0 ? 'warning' : 'neutral',
      },
      {
        id: 'risk-positions',
        label: '高风险持仓',
        value: `${dto.risk.highRiskPositionsCount}`,
        helperText: '需关注仓位暴露',
        tone: dto.risk.highRiskPositionsCount > 0 ? 'danger' : 'positive',
      },
      {
        id: 'risk-highest',
        label: '最高风险分',
        value: dto.risk.highestRiskScore > 0 ? dto.risk.highestRiskScore.toFixed(2) : '--',
        helperText: dto.risk.highestRiskName || '无',
        tone: dto.risk.highestRiskScore >= 85 ? 'danger' : dto.risk.highestRiskScore > 0 ? 'warning' : 'neutral',
      },
    ],
    events,
  };
}

function buildPortfolioSection(dto: DashboardSummaryDto): PortfolioSectionVm {
  return {
    title: '组合',
    summary: dto.portfolio.actionHint,
    state: buildSectionState(dto.portfolio.positionsCount > 0, dto.portfolio.totalMarketValue > 0),
    metrics: [
      {
        id: 'portfolio-positions',
        label: '持仓数量',
        value: `${dto.portfolio.positionsCount}`,
        helperText: `类型 ${dto.portfolio.positionType}`,
        tone: dto.portfolio.positionsCount > 0 ? 'info' : 'neutral',
      },
      {
        id: 'portfolio-value',
        label: '总市值',
        value: formatMoney(dto.portfolio.totalMarketValue),
        helperText: '组合当前市值',
        tone: 'info',
      },
      {
        id: 'portfolio-pnl',
        label: '日内盈亏',
        value: `${formatSignedMoney(dto.portfolio.dailyPnl)} / ${formatSignedPercent(dto.portfolio.dailyPnlPct)}`,
        helperText: `累计收益 ${formatSignedPercent(dto.portfolio.cumulativePnlPct)}`,
        tone: dto.portfolio.dailyPnl > 0 ? 'positive' : dto.portfolio.dailyPnl < 0 ? 'danger' : 'neutral',
      },
      {
        id: 'portfolio-cash',
        label: '现金占比',
        value: formatPercent(dto.portfolio.cashRatio),
        helperText: `Top1 集中度 ${formatPercent(dto.portfolio.concentrationTop1)}`,
        tone: dto.portfolio.cashRatio >= 0.3 ? 'positive' : 'warning',
      },
    ],
    actionHint: dto.portfolio.actionHint,
  };
}

function buildSystemHealthSection(dto: DashboardSummaryDto): SystemHealthSectionVm {
  const issues = buildSystemIssues(dto);

  return {
    title: '系统健康',
    summary: dto.systemHealth.systemHint,
    state: buildSectionState(issues.length > 0, dto.systemHealth.failedStepsCount > 0),
    metrics: [
      {
        id: 'system-pipeline',
        label: 'Pipeline',
        value: dto.systemHealth.pipelineStatus === 'healthy' ? '正常' : dto.systemHealth.pipelineStatus === 'warning' ? '预警' : '异常',
        helperText: `最近成功 ${formatDateTime(dto.systemHealth.latestSuccessTime)}`,
        tone: toneFromHealth(dto.systemHealth.pipelineStatus),
      },
      {
        id: 'system-failed',
        label: '失败步骤',
        value: `${dto.systemHealth.failedStepsCount}`,
        helperText: '今日失败步骤数',
        tone: dto.systemHealth.failedStepsCount > 0 ? 'danger' : 'positive',
      },
      {
        id: 'system-coverage',
        label: '数据覆盖',
        value: formatPercent(dto.systemHealth.dataCoveragePct),
        helperText: `DQ ${dto.systemHealth.dqStatus === 'healthy' ? '正常' : dto.systemHealth.dqStatus === 'warning' ? '预警' : '异常'}`,
        tone: toneFromHealth(dto.systemHealth.dqStatus),
      },
      {
        id: 'system-api',
        label: 'API 健康',
        value: dto.systemHealth.apiHealthStatus === 'healthy' ? '正常' : dto.systemHealth.apiHealthStatus === 'warning' ? '预警' : '异常',
        helperText: `版本 ${dto.systemHealth.versionLabel}`,
        tone: toneFromHealth(dto.systemHealth.apiHealthStatus),
      },
    ],
    issues,
  };
}

export function isDashboardSummaryEmpty(dto: DashboardSummaryDto): boolean {
  return (
    dto.opportunity.buySignalsCount === 0 &&
    dto.opportunity.resonanceCount === 0 &&
    dto.opportunity.watchlistCandidates === 0 &&
    dto.risk.gateBlockedCount === 0 &&
    dto.risk.highRiskWatchlistCount === 0 &&
    dto.risk.highRiskPositionsCount === 0 &&
    dto.portfolio.positionsCount === 0 &&
    dto.systemHealth.failedStepsCount === 0
  );
}

export function buildDashboardRuntimeSnapshot(
  dto: DashboardSummaryDto,
  source: 'mock' | 'real',
): DashboardRuntimeSnapshot {
  return {
    source,
    tradeDate: dto.tradeDate,
    generatedAt: formatDateTime(dto.generatedAt),
    systemStatusLabel:
      dto.systemHealth.pipelineStatus === 'healthy'
        ? '正常'
        : dto.systemHealth.pipelineStatus === 'warning'
          ? '预警'
          : '异常',
    systemTone: toneFromHealth(dto.systemHealth.pipelineStatus),
    versionText: dto.systemHealth.versionLabel,
  };
}

export function mapDashboardSummaryToViewModel(dto: DashboardSummaryDto): DashboardViewModel {
  return {
    tradeDateText: dto.tradeDate,
    generatedAtText: formatDateTime(dto.generatedAt),
    versionText: dto.systemHealth.versionLabel,
    summaryText: dto.todayChanges.summaryText,
    kpis: buildDashboardKpis(dto),
    todaySummary: buildTodaySummary(dto),
    opportunity: buildOpportunitySection(dto),
    risk: buildRiskSection(dto),
    portfolio: buildPortfolioSection(dto),
    systemHealth: buildSystemHealthSection(dto),
  };
}
