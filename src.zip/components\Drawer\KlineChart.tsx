import { useRef, useEffect, useState, useCallback } from 'react';
import {
  createChart,
  CandlestickSeries,
  LineSeries,
  HistogramSeries,
} from 'lightweight-charts';
import type { IChartApi, ISeriesApi, Time } from 'lightweight-charts';
import { fetchKline, type KlineItem } from '../../api';

/* ── Theme helpers ── */
function isDarkMode() {
  return document.documentElement.getAttribute('data-theme') !== 'light';
}

function chartTheme(dark: boolean) {
  return {
    layout: {
      background: { color: dark ? '#0F1923' : '#FFFFFF' },
      textColor:  dark ? '#94A3B8' : '#5A6272',
    },
    grid: {
      vertLines: { color: dark ? '#1a2436' : '#F0F2F5' },
      horzLines: { color: dark ? '#1a2436' : '#F0F2F5' },
    },
    rightPriceScale: { borderColor: dark ? '#2d3f5e' : '#E2E6EC' },
    timeScale:       { borderColor: dark ? '#2d3f5e' : '#E2E6EC', timeVisible: false },
  };
}

function candleColors(dark: boolean) {
  const up   = dark ? '#FF4D4F' : '#CF1322';
  const down = dark ? '#00B96B' : '#389E0D';
  return { upColor: up, downColor: down, borderUpColor: up, borderDownColor: down, wickUpColor: up, wickDownColor: down };
}

function volColor(item: KlineItem, dark: boolean): string {
  const up = item.close >= item.open;
  return up
    ? (dark ? 'rgba(255,77,79,0.45)'   : 'rgba(207,19,34,0.40)')
    : (dark ? 'rgba(0,185,107,0.45)'   : 'rgba(56,158,13,0.40)');
}

/* ── Period button ── */
function PeriodBtn({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      style={{
        fontSize: 11, padding: '2px 8px', borderRadius: 4, cursor: 'pointer',
        fontFamily: 'inherit', fontWeight: active ? 700 : 400,
        background: active ? 'var(--bg-active)' : 'transparent',
        color:      active ? 'var(--text-primary)' : 'var(--text-muted)',
        border:     `1px solid ${active ? 'var(--border-light)' : 'var(--border)'}`,
        transition: 'all 0.1s',
      }}
    >
      {label}
    </button>
  );
}

/* ── Main component ── */
interface Props {
  tsCode: string;
}

export default function KlineChart({ tsCode }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef     = useRef<IChartApi | null>(null);
  const candleRef    = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const ma5Ref       = useRef<ISeriesApi<'Line'> | null>(null);
  const ma10Ref      = useRef<ISeriesApi<'Line'> | null>(null);
  const ma20Ref      = useRef<ISeriesApi<'Line'> | null>(null);
  const volRef       = useRef<ISeriesApi<'Histogram'> | null>(null);

  const [days,     setDays]     = useState(60);
  const [loading,  setLoading]  = useState(true);
  const [hasError, setHasError] = useState(false);

  /* ── Apply data to chart series ── */
  const applyData = useCallback((items: KlineItem[]) => {
    if (!candleRef.current || !items.length) return;
    const dark = isDarkMode();

    candleRef.current.applyOptions(candleColors(dark));
    candleRef.current.setData(items.map(d => ({
      time:  d.date as Time,
      open:  d.open,
      high:  d.high,
      low:   d.low,
      close: d.close,
    })));

    const ma5Data  = items.filter(d => d.ma5  != null).map(d => ({ time: d.date as Time, value: d.ma5!  }));
    const ma10Data = items.filter(d => d.ma10 != null).map(d => ({ time: d.date as Time, value: d.ma10! }));
    const ma20Data = items.filter(d => d.ma20 != null).map(d => ({ time: d.date as Time, value: d.ma20! }));

    ma5Ref.current?.setData(ma5Data);
    ma10Ref.current?.setData(ma10Data);
    ma20Ref.current?.setData(ma20Data);

    volRef.current?.setData(items.map(d => ({
      time:  d.date as Time,
      value: d.volume,
      color: volColor(d, dark),
    })));

    chartRef.current?.timeScale().fitContent();
  }, []);

  /* ── Create chart (once on mount) ── */
  useEffect(() => {
    if (!containerRef.current) return;
    const dark  = isDarkMode();
    const chart = createChart(containerRef.current, {
      ...chartTheme(dark),
      width:      containerRef.current.clientWidth || 600,
      height:     300,
      crosshair:  { mode: 1 },
      localization: { locale: 'zh-CN' },
    });
    chartRef.current = chart;

    /* Candlestick */
    candleRef.current = chart.addSeries(CandlestickSeries, candleColors(dark));

    /* MA lines */
    const lineBase = { lineWidth: 1 as const, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false };
    ma5Ref.current  = chart.addSeries(LineSeries, { ...lineBase, color: '#3B82F6' });
    ma10Ref.current = chart.addSeries(LineSeries, { ...lineBase, color: '#F59E0B' });
    ma20Ref.current = chart.addSeries(LineSeries, { ...lineBase, color: '#A855F7' });

    /* Volume histogram — overlaid at bottom 22% of chart */
    volRef.current = chart.addSeries(HistogramSeries, {
      priceScaleId: 'vol',
      priceFormat:  { type: 'volume' },
    });
    chart.priceScale('vol').applyOptions({
      scaleMargins: { top: 0.78, bottom: 0 },
    });

    /* Resize observer */
    const ro = new ResizeObserver(() => {
      if (containerRef.current) {
        chart.applyOptions({ width: containerRef.current.clientWidth });
      }
    });
    ro.observe(containerRef.current);

    /* Theme observer */
    const mo = new MutationObserver(() => {
      const d = isDarkMode();
      chart.applyOptions(chartTheme(d));
      candleRef.current?.applyOptions(candleColors(d));
    });
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

    return () => {
      ro.disconnect();
      mo.disconnect();
      chart.remove();
      chartRef.current = null;
    };
  }, []);

  /* ── Fetch data when tsCode or days changes ── */
  useEffect(() => {
    if (!tsCode) return;
    setLoading(true);
    setHasError(false);
    fetchKline(tsCode, days)
      .then(items => {
        applyData(items);
        setLoading(false);
      })
      .catch(() => {
        setHasError(true);
        setLoading(false);
      });
  }, [tsCode, days, applyData]);

  return (
    <div>
      {/* Header row: title + period buttons */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <span className="drawer-section-title" style={{ marginBottom: 0 }}>
          K线图
          <span style={{ fontSize: 9, color: 'var(--text-muted)', marginLeft: 6, fontWeight: 400, letterSpacing: 0 }}>
            MA5&nbsp;<span style={{ color: '#3B82F6' }}>■</span>&nbsp;
            MA10&nbsp;<span style={{ color: '#F59E0B' }}>■</span>&nbsp;
            MA20&nbsp;<span style={{ color: '#A855F7' }}>■</span>
          </span>
        </span>
        <div style={{ display: 'flex', gap: 4 }}>
          {([30, 60, 120] as const).map(d => (
            <PeriodBtn key={d} label={`${d}日`} active={days === d} onClick={() => setDays(d)} />
          ))}
        </div>
      </div>

      <div className="drawer-card" style={{ padding: 0, overflow: 'hidden', position: 'relative' }}>
        {/* Loading skeleton */}
        {loading && (
          <div style={{
            position: 'absolute', inset: 0, zIndex: 2,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            background: 'var(--drawer-section-bg)', height: 300,
            fontSize: 12, color: 'var(--text-muted)',
          }}>
            <div className="spinner" style={{ width: 14, height: 14 }} />加载K线数据…
          </div>
        )}

        {/* Error state */}
        {hasError && !loading && (
          <div style={{
            height: 300, display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 12, color: 'var(--text-muted)',
          }}>
            K线数据暂不可用
          </div>
        )}

        {/* Chart container — always rendered so the chart can attach */}
        <div
          ref={containerRef}
          style={{ height: 300, visibility: loading || hasError ? 'hidden' : 'visible' }}
        />
      </div>
    </div>
  );
}
