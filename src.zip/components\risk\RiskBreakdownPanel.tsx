import type { RiskBreakdownRow } from '../../types/risk';

interface RiskBreakdownPanelProps {
  row: RiskBreakdownRow | null;
  emptyTitle: string;
  emptyText: string;
}

export default function RiskBreakdownPanel({ row, emptyTitle, emptyText }: RiskBreakdownPanelProps) {
  if (!row) {
    return (
      <div className="risk-breakdown-empty">
        <div className="risk-empty-title">{emptyTitle}</div>
        <div className="risk-empty-text">{emptyText}</div>
      </div>
    );
  }

  return (
    <div className="risk-breakdown-shell">
      <div className="risk-breakdown-head">
        <div className="risk-cell-title">{row.name}</div>
        <div className="risk-inline-meta">{row.tsCode}</div>
      </div>

      <div className="risk-breakdown-grid">
        <div className="risk-breakdown-card">
          <div className="risk-breakdown-title">交易结论</div>
          <div className="risk-breakdown-value">{row.tradeAllowedLabel}</div>
          <div className="risk-breakdown-sub">{row.blockReason}</div>
        </div>
        <div className="risk-breakdown-card">
          <div className="risk-breakdown-title">风险总分</div>
          <div className="risk-breakdown-value">{row.riskScoreTotal}</div>
          <div className="risk-breakdown-sub">来源策略：{row.sourceStrategy ?? '未记录'}</div>
        </div>
        <div className="risk-breakdown-card">
          <div className="risk-breakdown-title">最终仓位上限</div>
          <div className="risk-breakdown-value">{row.positionCapMultiplierFinal.toFixed(2)}</div>
          <div className="risk-breakdown-sub">{row.recommendedPositionText}</div>
        </div>
      </div>

      <div className="risk-breakdown-dimension">
        <div className="risk-breakdown-section-title">四维分数</div>
        <div className="risk-breakdown-list">
          <div>财务：{row.riskScoreFinancial}</div>
          <div>市场：{row.riskScoreMarket}</div>
          <div>事件：{row.riskScoreEvent}</div>
          <div>合规：{row.riskScoreCompliance}</div>
        </div>
      </div>

      <div className="risk-breakdown-dimension">
        <div className="risk-breakdown-section-title">四维上限</div>
        <div className="risk-breakdown-list">
          <div>财务上限：{row.capFinancial.toFixed(2)}</div>
          <div>市场上限：{row.capMarket.toFixed(2)}</div>
          <div>事件上限：{row.capEvent.toFixed(2)}</div>
          <div>合规上限：{row.capCompliance.toFixed(2)}</div>
          <div>最小上限：{row.dimCap.toFixed(2)}</div>
        </div>
      </div>

      <div className="risk-breakdown-dimension">
        <div className="risk-breakdown-section-title">判断说明</div>
        <div className="risk-empty-text">{row.explanation}</div>
      </div>
    </div>
  );
}
