import {
  fetchCrossStrategies,
  fetchPortfolio,
  fetchWatchlist,
  type PortfolioItem,
  type WatchlistItem,
} from '../api';
import { getQuickStats } from '../utils/score';
import type {
  WatchlistActionVm,
  WatchlistFilterOptionVm,
  WatchlistFilterVm,
  WatchlistGroupBy,
  WatchlistGroupVm,
  WatchlistLifecycleStatus,
  WatchlistMetricVm,
  WatchlistQueryState,
  WatchlistRowVm,
  WatchlistSignalFilter,
  WatchlistWorkspaceVm,
} from '../types/watchlist';

function settle<T>(promise: Promise<T>): Promise<{ ok: true; data: T } | { ok: false; error: unknown }> {
  return promise.then(data => ({ ok: true as const, data })).catch(error => ({ ok: false as const, error }));
}

function normalizeStatusFilter(status: string | null): WatchlistLifecycleStatus | 'all' {
  if (status === 'candidate' || status === 'signaled' || status === 'handed_off' || status === 'blocked') return status;
  return 'all';
}

function normalizeSignalFilter(signal: string | null): WatchlistSignalFilter {
  if (signal === 'buy' || signal === 'sell' || signal === 'any' || signal === 'none') return signal;
  return 'all';
}

function normalizeGroupBy(groupBy: string | null): WatchlistGroupBy {
  return groupBy === 'strategy' ? 'strategy' : 'lifecycle';
}

function getSourceLabel(strategy: string): string {
  if (strategy.includes('VOL')) return '来源：能量蓄势';
  if (strategy.includes('RETOC2')) return '来源：异动策略';
  if (strategy.includes('PATTERN')) return '来源：形态策略';
  return '来源：观察池';
}

function getStrategyTarget(strategy: string, tsCode: string): string | null {
  const strategyUpper = strategy.toUpperCase();
  if (strategyUpper.includes('VOL')) {
    return `/dashboard?ts_code=${encodeURIComponent(tsCode)}&focus=${encodeURIComponent(tsCode)}&source=watchlist&strategy=VOL_SURGE`;
  }
  if (strategyUpper.includes('RETOC2')) {
    return `/retoc2?ts_code=${encodeURIComponent(tsCode)}&focus=${encodeURIComponent(tsCode)}&source=watchlist&strategy=RETOC2`;
  }
  if (strategyUpper.includes('T2UP9')) {
    return `/pattern?ts_code=${encodeURIComponent(tsCode)}&focus=${encodeURIComponent(tsCode)}&source=watchlist&strategy=PATTERN_T2UP9`;
  }
  if (strategyUpper.includes('GREEN10')) {
    return `/pattern?ts_code=${encodeURIComponent(tsCode)}&focus=${encodeURIComponent(tsCode)}&source=watchlist&strategy=PATTERN_GREEN10`;
  }
  if (strategyUpper.includes('PATTERN')) {
    return `/pattern?ts_code=${encodeURIComponent(tsCode)}&focus=${encodeURIComponent(tsCode)}&source=watchlist&strategy=${encodeURIComponent(strategyUpper)}`;
  }
  return null;
}

function getSignalState(item: WatchlistItem): WatchlistSignalFilter {
  if (item.buy_signal && item.sell_signal) return 'any';
  if (item.buy_signal) return 'buy';
  if (item.sell_signal) return 'sell';
  return 'none';
}

function getSignalLabel(signalState: WatchlistSignalFilter): string {
  if (signalState === 'buy') return '买点信号';
  if (signalState === 'sell') return '卖点信号';
  if (signalState === 'any') return '买卖点并存';
  if (signalState === 'none') return '无信号';
  return '全部';
}

function mapLifecycleStatus(item: WatchlistItem, inPortfolio: boolean): WatchlistLifecycleStatus {
  if (inPortfolio) return 'handed_off';
  if (item.buy_signal || item.sell_signal) return 'signaled';
  return 'candidate';
}

function getLifecycleLabel(status: WatchlistLifecycleStatus): string {
  if (status === 'handed_off') return '已移交';
  if (status === 'signaled') return '已出信号';
  if (status === 'blocked') return '已阻断';
  return '候选';
}

function buildActions(row: {
  tsCode: string;
  strategy: string;
  inPortfolio: boolean;
}): WatchlistActionVm[] {
  const strategyHref = getStrategyTarget(row.strategy, row.tsCode);
  return [
    {
      key: 'detail',
      label: '查看详情',
      kind: 'detail',
      note: '打开详情抽屉，并保持当前选中项不变。',
      summaryType: 'detail',
    },
    {
      key: 'strategy',
      label: '查看来源策略',
      kind: strategyHref ? 'strategy' : 'placeholder',
      href: strategyHref,
      note: strategyHref
        ? '跳转到对应策略页，并保留观察池来源与聚焦上下文。'
        : '当前来源策略尚未映射到正式目标页，先保留入口。',
      summaryType: 'jump',
    },
    {
      key: 'portfolio',
      label: row.inPortfolio ? '查看持仓' : '转持仓',
      kind: 'portfolio',
      href: row.inPortfolio
        ? `/portfolio?source=watchlist&focus=${encodeURIComponent(row.tsCode)}&ts_code=${encodeURIComponent(row.tsCode)}`
        : null,
      note: row.inPortfolio
        ? '该股票已移交到持仓工作域，可直接查看。'
        : '当前仅保留前端工作流入口，正式落库动作待后端接口接入。',
      summaryType: 'handoff',
    },
    {
      key: 'more',
      label: '更多操作',
      kind: 'placeholder',
      note: '置顶、忽略、加入模拟盘仍为占位操作，当前不会写回后端。',
      summaryType: 'placeholder',
    },
  ];
}

function buildRows(
  items: WatchlistItem[],
  portfolioMap: Map<string, PortfolioItem>,
  crossMap: Record<string, string[]>,
): WatchlistRowVm[] {
  return items.map(item => {
    const portfolioItem = portfolioMap.get(item.ts_code) ?? null;
    const quickStats = getQuickStats(item.ts_code);
    const inPortfolio = Boolean(portfolioItem);
    const lifecycleStatus = mapLifecycleStatus(item, inPortfolio);
    const rawCrossTags = crossMap[item.ts_code] ?? [];
    const crossTags = rawCrossTags.filter(strategy => strategy !== item.strategy);
    const signalState = getSignalState(item);

    return {
      id: `${item.ts_code}-${item.strategy}`,
      tsCode: item.ts_code,
      name: item.name,
      strategy: item.strategy,
      entryDate: item.entry_date,
      poolDay: item.pool_day,
      latestPctChg: item.latest_pct_chg,
      gainSinceEntry: item.gain_since_entry,
      buySignal: item.buy_signal,
      sellSignal: item.sell_signal,
      vrToday: quickStats.turnoverRate,
      lifecycleStatus,
      lifecycleStatusLabel: getLifecycleLabel(lifecycleStatus),
      lifecycleStatusOrigin: 'derived',
      inPortfolio,
      portfolioStatus: portfolioItem?.status ?? null,
      portfolioId: portfolioItem?.id ?? null,
      crossTags,
      signalState,
      signalLabel: getSignalLabel(signalState),
      sourceLabel: getSourceLabel(item.strategy),
      sourceOrigin: 'derived',
      availableActions: buildActions({
        tsCode: item.ts_code,
        strategy: item.strategy,
        inPortfolio,
      }),
    };
  });
}

function applyFilters(rows: WatchlistRowVm[], query: WatchlistQueryState): WatchlistRowVm[] {
  const normalizedStrategy = query.strategy?.trim().toUpperCase() ?? '';
  const normalizedStatus = normalizeStatusFilter(query.status);
  const normalizedSignal = normalizeSignalFilter(query.signal);
  const normalizedQuery = query.query?.trim().toUpperCase() ?? '';

  return rows.filter(row => {
    if (normalizedStrategy && row.strategy.toUpperCase() !== normalizedStrategy) return false;
    if (normalizedStatus !== 'all' && row.lifecycleStatus !== normalizedStatus) return false;
    if (normalizedSignal !== 'all') {
      if (normalizedSignal === 'any' && row.signalState === 'none') return false;
      if (normalizedSignal === 'none' && row.signalState !== 'none') return false;
      if ((normalizedSignal === 'buy' || normalizedSignal === 'sell') && row.signalState !== normalizedSignal) return false;
    }
    if (normalizedQuery) {
      const haystack = `${row.tsCode} ${row.name}`.toUpperCase();
      if (!haystack.includes(normalizedQuery)) return false;
    }
    return true;
  });
}

function buildMetrics(rows: WatchlistRowVm[]): WatchlistMetricVm[] {
  const signaledCount = rows.filter(row => row.lifecycleStatus === 'signaled').length;
  const handedOffCount = rows.filter(row => row.lifecycleStatus === 'handed_off').length;
  const candidateCount = rows.filter(row => row.lifecycleStatus === 'candidate').length;
  const avgPoolDay = rows.length
    ? (rows.reduce((sum, row) => sum + row.poolDay, 0) / rows.length).toFixed(1)
    : '--';

  return [
    { label: '当前观察股票', value: String(rows.length), helper: '基于当前筛选结果' },
    { label: '候选股票', value: String(candidateCount), helper: '仍处于观察阶段' },
    { label: '已出信号', value: String(signaledCount), helper: '已出现买点或卖点' },
    { label: '已移交持仓', value: String(handedOffCount), helper: '已进入持仓跟踪' },
    { label: '平均观察天数', value: String(avgPoolDay), helper: '基于当前筛选结果' },
  ];
}

function buildFilters(query: WatchlistQueryState): WatchlistFilterVm[] {
  return [
    { label: 'Source', value: query.source ?? 'direct' },
    { label: 'Focus', value: query.focus ?? 'none' },
    { label: 'Strategy', value: query.strategy ?? 'all' },
    { label: 'Status', value: normalizeStatusFilter(query.status) },
    { label: 'Signal', value: normalizeSignalFilter(query.signal) },
    { label: 'Query', value: query.query ?? 'none' },
    { label: 'View', value: query.view },
    { label: 'Group by', value: normalizeGroupBy(query.groupBy) },
  ];
}

function buildUniqueOptions(values: string[], includeAllLabel: string): WatchlistFilterOptionVm[] {
  const unique = Array.from(new Set(values)).sort((a, b) => a.localeCompare(b));
  return [{ label: includeAllLabel, value: 'all' }, ...unique.map(value => ({ label: value, value }))];
}

function buildGroups(rows: WatchlistRowVm[], groupBy: WatchlistGroupBy): WatchlistGroupVm[] {
  if (groupBy === 'strategy') {
    const strategyMap = new Map<string, WatchlistRowVm[]>();
    rows.forEach(row => {
      const next = strategyMap.get(row.strategy) ?? [];
      next.push(row);
      strategyMap.set(row.strategy, next);
    });
    return Array.from(strategyMap.entries()).map(([strategy, groupRows]) => ({
      key: `strategy-${strategy}`,
      label: strategy,
      helper: `同一策略来源共 ${groupRows.length} 只股票`,
      count: groupRows.length,
      rows: groupRows,
    }));
  }

  const order: WatchlistLifecycleStatus[] = ['candidate', 'signaled', 'handed_off', 'blocked'];
  return order.map(status => {
    const groupRows = rows.filter(row => row.lifecycleStatus === status);
    return {
      key: `lifecycle-${status}`,
      label: getLifecycleLabel(status),
      helper: status === 'blocked'
        ? '当前暂无可靠阻断来源，先保留状态分组。'
        : `当前分组共 ${groupRows.length} 只股票`,
      count: groupRows.length,
      rows: groupRows,
    };
  });
}

export async function loadWatchlistWorkspace(query: WatchlistQueryState, tradeDate: string): Promise<WatchlistWorkspaceVm> {
  const [watchlistResult, portfolioResult, crossResult] = await Promise.all([
    settle(fetchWatchlist()),
    settle(fetchPortfolio('open')),
    settle(fetchCrossStrategies()),
  ]);

  if (!watchlistResult.ok) {
    throw watchlistResult.error;
  }

  const portfolioMap = new Map<string, PortfolioItem>();
  if (portfolioResult.ok) {
    portfolioResult.data.data.forEach(item => {
      portfolioMap.set(item.ts_code, item);
    });
  }

  const crossMap = crossResult.ok ? crossResult.data : {};
  const allRows = buildRows(watchlistResult.data, portfolioMap, crossMap);
  const filteredRows = applyFilters(allRows, query);

  return {
    tradeDate,
    totalCount: filteredRows.length,
    rows: filteredRows,
    metrics: buildMetrics(filteredRows),
    filters: buildFilters(query),
    filterOptions: {
      statusOptions: [
        { label: '全部', value: 'all' },
        { label: '候选', value: 'candidate' },
        { label: '已出信号', value: 'signaled' },
        { label: '已移交', value: 'handed_off' },
        { label: '已阻断', value: 'blocked' },
      ],
      strategyOptions: buildUniqueOptions(allRows.map(row => row.strategy), '全部策略'),
      signalOptions: [
        { label: '全部', value: 'all' },
        { label: '买点', value: 'buy' },
        { label: '卖点', value: 'sell' },
        { label: '任一信号', value: 'any' },
        { label: '无信号', value: 'none' },
      ],
    },
    viewOptions: [
      { key: 'table', label: '表格', helper: '按列表查看观察对象', enabled: true },
      { key: 'group', label: '分组', helper: '按状态或策略分组查看', enabled: true },
      { key: 'heat', label: '热度', helper: '用于展示优先级的热度视图', enabled: false },
    ],
    groupByOptions: [
      { label: '按状态', value: 'lifecycle' },
      { label: '按策略', value: 'strategy' },
    ],
    groups: buildGroups(filteredRows, normalizeGroupBy(query.groupBy)),
    emptyTitle: '当前筛选下暂无观察对象',
    emptyText: '请调整状态、策略、信号或搜索条件后再查看。',
    sourceNotes: [
      '当前页面已接入观察池、持仓与交叉策略数据。',
      '状态与动作中仍包含前端兼容态表达，但不影响当前工作流浏览与跳转。',
      '阻断状态仍为保留口径，后续等待更可靠的数据来源。',
    ],
  };
}
