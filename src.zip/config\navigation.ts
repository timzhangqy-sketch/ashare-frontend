export type AppRouteKey =
  | 'dashboard'
  | 'signals'
  | 'watchlist'
  | 'portfolio'
  | 'execution'
  | 'risk'
  | 'research'
  | 'system'
  | 'ignition'
  | 'retoc2'
  | 'pattern'
  | 'holdings'
  | 'backtest';

export type NavIconKey =
  | 'dashboard'
  | 'signals'
  | 'watchlist'
  | 'portfolio'
  | 'execution'
  | 'risk'
  | 'research'
  | 'system'
  | 'legacy';

export interface AppRouteDefinition {
  key: AppRouteKey;
  path: string;
  label: string;
  title: string;
  description: string;
  showInMainNav: boolean;
  isLegacy: boolean;
  icon?: NavIconKey;
  handoffPaths?: string[];
}

export const appRouteDefinitions: AppRouteDefinition[] = [
  {
    key: 'dashboard',
    path: '/dashboard',
    label: 'Dashboard',
    title: 'Dashboard',
    description: '正式首页入口，承接全局总览、状态摘要与主要工作流分发。',
    showInMainNav: true,
    isLegacy: false,
    icon: 'dashboard',
    handoffPaths: ['/ignition', '/holdings', '/backtest'],
  },
  {
    key: 'signals',
    path: '/signals',
    label: 'Signals',
    title: 'Signals',
    description: '正式信号工作域入口，承接信号列表、筛选、研究跳转与样本上下文。',
    showInMainNav: true,
    isLegacy: false,
    icon: 'signals',
    handoffPaths: ['/ignition', '/retoc2', '/pattern'],
  },
  {
    key: 'watchlist',
    path: '/watchlist',
    label: 'Watchlist',
    title: 'Watchlist',
    description: '正式观察池工作域入口，承接关注分组、焦点样本、热度视图与后续 handoff。',
    showInMainNav: true,
    isLegacy: false,
    icon: 'watchlist',
    handoffPaths: ['/ignition', '/retoc2', '/pattern'],
  },
  {
    key: 'portfolio',
    path: '/portfolio',
    label: 'Portfolio',
    title: 'Portfolio',
    description: '正式持仓工作域入口，承接组合、持仓明细、分段视图与关联研究跳转。',
    showInMainNav: true,
    isLegacy: false,
    icon: 'portfolio',
    handoffPaths: ['/holdings'],
  },
  {
    key: 'execution',
    path: '/execution',
    label: 'Execution',
    title: 'Execution',
    description: '正式执行工作域入口，承接执行状态、异常、策略来源与系统链路联动。',
    showInMainNav: true,
    isLegacy: false,
    icon: 'execution',
    handoffPaths: ['/portfolio', '/watchlist', '/signals', '/risk'],
  },
  {
    key: 'risk',
    path: '/risk',
    label: 'Risk',
    title: 'Risk',
    description: '正式风险工作域入口，承接风险视图、范围切换、来源恢复与研究联动。',
    showInMainNav: true,
    isLegacy: false,
    icon: 'risk',
    handoffPaths: ['/holdings', '/backtest'],
  },
  {
    key: 'research',
    path: '/research',
    label: 'Research',
    title: 'Research',
    description: '正式研究工作域入口，承接研究总览、四类详情路由与来源页 handoff。',
    showInMainNav: true,
    isLegacy: false,
    icon: 'research',
    handoffPaths: ['/backtest'],
  },
  {
    key: 'system',
    path: '/system',
    label: 'System',
    title: 'System',
    description: '正式系统工作域入口，承接 API、数据集、步骤恢复与系统级降级态。',
    showInMainNav: true,
    isLegacy: false,
    icon: 'system',
    handoffPaths: ['/dashboard'],
  },
  {
    key: 'ignition',
    path: '/ignition',
    label: '能量蓄势',
    title: '能量蓄势',
    description: '保留中的 legacy 策略页入口，仅在兼容入口分组中展示，不承担正式首页语义。',
    showInMainNav: false,
    isLegacy: true,
    icon: 'legacy',
  },
  {
    key: 'retoc2',
    path: '/retoc2',
    label: '异动策略',
    title: '异动策略',
    description: '保留中的 legacy 页面入口，本轮不调整其语义与暴露策略。',
    showInMainNav: false,
    isLegacy: true,
    icon: 'legacy',
  },
  {
    key: 'pattern',
    path: '/pattern',
    label: '形态策略',
    title: '形态策略',
    description: '保留中的 legacy 页面入口，本轮不调整其语义与暴露策略。',
    showInMainNav: false,
    isLegacy: true,
    icon: 'legacy',
  },
  {
    key: 'holdings',
    path: '/holdings',
    label: '持仓中心',
    title: '持仓中心',
    description: '旧 /holdings 路由仅保留兼容跳转语义，正式持仓入口为持仓中心。',
    showInMainNav: false,
    isLegacy: true,
    icon: 'legacy',
  },
  {
    key: 'backtest',
    path: '/backtest',
    label: '回测中心',
    title: '回测中心',
    description: '旧 /backtest 路由仅保留兼容跳转语义，正式研究入口为回测中心所在研究域。',
    showInMainNav: false,
    isLegacy: true,
    icon: 'legacy',
  },
];

export const mainNavigation = appRouteDefinitions.filter(route => route.showInMainNav);
export const legacyNavigation = appRouteDefinitions.filter(route => route.isLegacy);
