import type { WatchlistActionVm } from '../types/watchlist';

export default function WatchlistActionMenu({
  actions,
  onAction,
}: {
  actions: WatchlistActionVm[];
  onAction: (action: WatchlistActionVm) => void;
}) {
  const primaryActions = actions.filter(action => action.key !== 'more');
  const moreAction = actions.find(action => action.key === 'more') ?? null;

  return (
    <div className="watchlist-action-menu">
      {primaryActions.map(action => (
        <button
          key={action.key}
          type="button"
          className={`watchlist-action-chip ${action.kind}`}
          onClick={event => {
            event.stopPropagation();
            onAction(action);
          }}
          disabled={action.disabled}
        >
          {action.label}
        </button>
      ))}
      {moreAction ? (
        <details
          className="watchlist-more-menu"
          onClick={event => event.stopPropagation()}
        >
          <summary className="watchlist-action-chip placeholder">更多操作</summary>
          <div className="watchlist-more-panel">
            <button type="button" onClick={() => onAction({ ...moreAction, key: 'pin', label: '置顶' })}>置顶</button>
            <button type="button" onClick={() => onAction({ ...moreAction, key: 'ignore', label: '忽略' })}>忽略</button>
            <button type="button" onClick={() => onAction({ ...moreAction, key: 'paper', label: '加入模拟盘' })}>加入模拟盘</button>
          </div>
        </details>
      ) : null}
    </div>
  );
}
