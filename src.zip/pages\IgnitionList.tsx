import { useState } from 'react';
import { useDate } from '../context/DateContext';
import StockDrawer from '../components/Drawer/StockDrawer';
import WatchlistTab from '../components/WatchlistTab';
import { getMockDetail } from '../utils/score';
import { useApiData } from '../hooks/useApiData';
import { fetchIgnite, type IgniteItem } from '../api';
import type { StockDetail } from '../types/stock';
import { CrossTags } from '../components/CrossTags';

type MainTab = 'today' | 'watchlist';

const fmt = (v: number | null | undefined, d = 2) => v != null ? v.toFixed(d) : '--';
const pctFmt = (v: number | null | undefined, d = 2) => v != null ? `${v >= 0 ? '+' : ''}${v.toFixed(d)}%` : '--';
const pnlColor = (v: number | null | undefined) =>
  v == null ? 'var(--text-muted)' : v > 0 ? 'var(--red)' : v < 0 ? 'var(--green)' : 'var(--text-muted)';

const SCORE_CFG: Record<string, { color: string; bg: string; border: string }> = {
  S: { color: '#FF4D4F', bg: 'rgba(255,77,79,.16)', border: 'rgba(255,77,79,.36)' },
  A: { color: '#F5A623', bg: 'rgba(245,166,35,.16)', border: 'rgba(245,166,35,.36)' },
  B: { color: '#4FA3FF', bg: 'rgba(79,163,255,.16)', border: 'rgba(79,163,255,.36)' },
};

function getScoreTier(score: number) {
  if (score >= 85) return 'S';
  if (score >= 75) return 'A';
  return 'B';
}

function ScoreBadge({ score }: { score: number }) {
  const tier = getScoreTier(score);
  const cfg = SCORE_CFG[tier] ?? SCORE_CFG.B;
  return (
    <span
      style={{
        fontSize: 12,
        fontWeight: 700,
        padding: '2px 10px',
        borderRadius: 10,
        background: cfg.bg,
        color: cfg.color,
        border: `1px solid ${cfg.border}`,
      }}
    >
      {tier}
    </span>
  );
}

export default function IgnitionList() {
  const { selectedDate } = useDate();
  const { data, loading, error, refetch } = useApiData(
    () => fetchIgnite(selectedDate),
    [selectedDate],
  );
  const [selected, setSelected] = useState<StockDetail | null>(null);
  const [buyMode, setBuyMode] = useState(false);
  const [mainTab, setMainTab] = useState<MainTab>('today');

  const rows = data ?? [];
  const highScoreCount = rows.filter((item) => item.ignite_score >= 80).length;
  const avgScore = rows.length ? rows.reduce((sum, item) => sum + item.ignite_score, 0) / rows.length : 0;
  const topRank = rows.length ? rows.reduce((best, item) => item.ignite_score > best.ignite_score ? item : best, rows[0]) : null;

  return (
    <div data-testid="ignition-page">
      <div className="page-header">
        <div>
          <div className="page-title">
            能量蓄势
            <span className="page-badge badge-red">能量蓄势</span>
          </div>
          <div className="page-desc">基于能量蓄势兼容口径承接旧策略页，聚焦量价蓄势与点火分数筛选 · {selectedDate}</div>
        </div>
      </div>

      <div className="page-tabs">
        <button className={`page-tab-btn${mainTab === 'today' ? ' active' : ''}`} onClick={() => setMainTab('today')}>
          今日入选
        </button>
        <button className={`page-tab-btn${mainTab === 'watchlist' ? ' active' : ''}`} onClick={() => setMainTab('watchlist')}>
          持续观察池
        </button>
      </div>

      {mainTab === 'watchlist' ? (
        <WatchlistTab
          strategy="VOL_SURGE"
          onOpen={(stock) => { setBuyMode(false); setSelected(stock); }}
          onBuy={(stock) => { setBuyMode(true); setSelected(stock); }}
        />
      ) : (
        <>
          <div className="stat-grid">
            <div className="stat-card">
              <div className="stat-label">今日入选</div>
              <div className={`stat-value c-red${loading ? ' loading' : ''}`}>{loading ? '--' : rows.length}</div>
              <div className="stat-sub">点火候选</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">高分样本</div>
              <div className={`stat-value c-gold${loading ? ' loading' : ''}`}>{loading ? '--' : highScoreCount}</div>
              <div className="stat-sub">ignite_score ≥ 80</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">平均点火分</div>
              <div className="stat-value" style={{ color: loading ? 'var(--text-muted)' : 'var(--cyan)' }}>
                {loading ? '--' : fmt(avgScore, 1)}
              </div>
              <div className="stat-sub">当日样本均值</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">当前最高分</div>
              <div className="stat-value" style={{ fontSize: topRank ? 16 : 24, color: 'var(--red)' }}>
                {loading ? '--' : topRank ? topRank.name : '--'}
              </div>
              <div className="stat-sub">{loading || !topRank ? '' : `${fmt(topRank.ignite_score, 1)} 分`}</div>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <span className="card-title">能量蓄势候选列表</span>
              <span className="c-muted" style={{ fontSize: 12 }}>点击行查看详情与买点上下文</span>
            </div>

            {loading && <div className="page-loading"><div className="spinner" />加载中...</div>}
            {!loading && error && (
              <div className="page-error">
                <div className="page-error-msg">数据加载失败</div>
                <div className="page-error-detail">{error}</div>
                <button className="retry-btn" onClick={refetch}>重试</button>
              </div>
            )}
            {!loading && !error && rows.length === 0 && (
              <div className="empty-state">
                <div className="empty-icon">空</div>
                <div className="empty-text">该日期暂无能量蓄势数据</div>
              </div>
            )}
            {!loading && !error && rows.length > 0 && (
              <table className="data-table">
                <thead>
                  <tr>
                    <th className="center">等级</th>
                    <th className="right">排名</th>
                    <th>代码</th>
                    <th>名称</th>
                    <th className="right">点火分</th>
                    <th className="right">VR</th>
                    <th className="right">换手%</th>
                    <th className="right">涨幅%</th>
                    <th className="right">收盘</th>
                    <th className="right">成交(亿)</th>
                    <th className="right">MA5斜率</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((item: IgniteItem) => (
                    <tr
                      key={`${item.ts_code}-${item.rank}`}
                      onClick={() => setSelected(getMockDetail(item.ts_code, item.name, ['能量蓄势'], item.close ?? 0, item.pct_chg ?? 0))}
                    >
                      <td className="center"><ScoreBadge score={item.ignite_score} /></td>
                      <td className="right c-sec">{item.rank}</td>
                      <td className="c-sec">{item.ts_code}</td>
                      <td style={{ fontWeight: 500 }}>
                        {item.name}<CrossTags tsCode={item.ts_code} currentStrategy="VOL_SURGE" />
                      </td>
                      <td className="right" style={{ color: 'var(--red)', fontWeight: 700 }}>{fmt(item.ignite_score, 1)}</td>
                      <td className="right c-muted">{fmt(item.vr, 2)}</td>
                      <td className="right c-muted">{fmt(item.turnover_rate, 2)}%</td>
                      <td className="right" style={{ color: pnlColor(item.pct_chg), fontWeight: 600 }}>{pctFmt(item.pct_chg, 2)}</td>
                      <td className="right" style={{ fontVariantNumeric: 'tabular-nums' }}>{fmt(item.close, 2)}</td>
                      <td className="right c-muted">{fmt(item.amount_yi, 2)}</td>
                      <td className="right c-muted">{fmt(item.s_ma5, 1)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}

      <StockDrawer
        stock={selected}
        autoOpenBuyForm={buyMode}
        onClose={() => { setSelected(null); setBuyMode(false); }}
      />
    </div>
  );
}
