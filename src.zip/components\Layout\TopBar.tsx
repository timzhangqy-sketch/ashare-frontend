import { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { fetchPipeline, type PipelineStepResp } from '../../api';
import { getRouteMeta } from '../../config/routeMeta';
import { useDashboardRuntime } from '../../context/DashboardRuntimeContext';
import { useDate } from '../../context/DateContext';

const WEEKDAYS = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

const STEP_NAMES: Record<string, string> = {
  daily_price: '日线行情',
  daily_basic: '日线基础',
  adj_factor: '复权因子',
  factor_merge: '因子合并',
  index_daily: '指数日线',
  intraday_5m: '5分钟数据',
  scan_snapshot: '扫描快照',
  pool_runner: '池子计算',
  ignite_strict3: '能量蓄势',
  cont_upsert: '连板池更新',
  cont_exit: '连板池退出',
  retoc2: '异动策略',
  pattern: '形态策略',
  pool_export: '池子导出',
  pool_mailer: '邮件发送',
  notify_push: '推送通知',
  dq_gate: '交易日门控',
  healthcheck: '健康检查',
};

function fmtDur(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  const seconds = Math.round(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  return `${Math.floor(seconds / 60)}m${seconds % 60}s`;
}

function fmtTime(value: string): string {
  const part = value.includes('T') ? value.split('T')[1] : value;
  return (part ?? value).slice(0, 5);
}

const ChevronLeft = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
    strokeLinecap="round" strokeLinejoin="round" width="14" height="14">
    <polyline points="15 18 9 12 15 6" />
  </svg>
);

const ChevronRight = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
    strokeLinecap="round" strokeLinejoin="round" width="14" height="14">
    <polyline points="9 18 15 12 9 6" />
  </svg>
);

const CloseXIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
    strokeLinecap="round" width="13" height="13">
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

type StepStatus = 'ok' | 'warn' | 'fail';

function StepIcon({ status }: { status: StepStatus }) {
  if (status === 'ok') {
    return (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
        stroke="#52c41a" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="20 6 9 17 4 12" />
      </svg>
    );
  }

  if (status === 'warn') {
    return (
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
        stroke="#f5a623" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
        <line x1="12" y1="9" x2="12" y2="13" />
        <line x1="12" y1="17" x2="12.01" y2="17" />
      </svg>
    );
  }

  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
      stroke="#ff4d4f" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}

const STATUS_COLOR: Record<StepStatus, string> = {
  ok: '#52c41a',
  warn: '#f5a623',
  fail: '#ff4d4f',
};

const STATUS_LABEL: Record<StepStatus, string> = {
  ok: '正常',
  warn: '告警',
  fail: '失败',
};

export default function TopBar() {
  const { pathname } = useLocation();
  const { selectedDate, setSelectedDate, prevTradingDay, nextTradingDay, isToday } = useDate();
  const { snapshot } = useDashboardRuntime();
  const meta = getRouteMeta(pathname);
  const displayMeta = pathname.startsWith('/research') || pathname.startsWith('/backtest')
    ? {
        title: '研究中心',
        description: '研究工作域。承接回测总结、因子表现、归因分析与共振研究。',
      }
    : pathname.startsWith('/holdings')
        ? {
            title: '持仓中心',
            description: '旧 /holdings 路由当前仅作为兼容入口，正式持仓工作域入口为持仓中心。',
          }
    : pathname.startsWith('/system')
      ? {
          title: '系统运行中心',
          description: '系统运行工作域。承接 Pipeline、数据覆盖、接口健康与运行快照。',
        }
      : meta;

  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('ashare-theme') as 'dark' | 'light') ?? 'dark';
  });
  const [showPipeline, setShowPipeline] = useState(false);
  const [steps, setSteps] = useState<PipelineStepResp[]>([]);
  const [pipeLoading, setPipeLoading] = useState(false);
  const [pipeError, setPipeError] = useState<string | null>(null);
  const pipelineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.setAttribute('data-theme', 'light');
    } else {
      document.documentElement.removeAttribute('data-theme');
    }
    localStorage.setItem('ashare-theme', theme);
  }, [theme]);

  useEffect(() => {
    const saved = localStorage.getItem('ashare-theme');
    if (saved === 'light') document.documentElement.setAttribute('data-theme', 'light');
  }, []);

  useEffect(() => {
    let cancelled = false;
    setPipeLoading(true);
    setPipeError(null);

    fetchPipeline(selectedDate)
      .then(data => {
        if (!cancelled) {
          setSteps(data);
          setPipeLoading(false);
        }
      })
      .catch(err => {
        if (!cancelled) {
          setPipeError(err.message);
          setSteps([]);
          setPipeLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [selectedDate]);

  useEffect(() => {
    if (!showPipeline) return;

    const handler = (event: MouseEvent) => {
      if (pipelineRef.current && !pipelineRef.current.contains(event.target as Node)) {
        setShowPipeline(false);
      }
    };

    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [showPipeline]);

  const [year, month, day] = selectedDate.split('-').map(Number);
  const currentDate = new Date(year, month - 1, day);
  const weekday = WEEKDAYS[currentDate.getDay()];
  const isWeekend = [0, 6].includes(currentDate.getDay());

  const safeSteps = Array.isArray(steps) ? steps : [];
  const hasWarn = safeSteps.some(step => step.status === 'warn');
  const hasFail = safeSteps.some(step => step.status === 'fail');
  const dotColor = pipeLoading ? 'var(--text-muted)' : hasFail ? '#ff4d4f' : hasWarn ? '#f5a623' : '#52c41a';
  const dotGlow = pipeLoading ? 'none' : hasFail ? '0 0 6px #ff4d4f90' : hasWarn ? '0 0 6px #f5a62390' : '0 0 6px #52c41a90';
  const pipelineLabel = pipeLoading ? 'Pipeline 加载中' : hasFail ? 'Pipeline 失败' : hasWarn ? 'Pipeline 告警' : 'Pipeline 正常';

  const dashboardHint = pathname === '/dashboard' && snapshot
    ? `交易日 ${snapshot.tradeDate} · 更新 ${snapshot.generatedAt} · 系统 ${snapshot.systemStatusLabel} · ${snapshot.source === 'real' ? '真实接口' : 'Mock'}`
    : '';

  return (
    <header className="topbar">
      <div className="topbar-title">
        {displayMeta.title}
        <span style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 400, marginLeft: 8 }}>
          {displayMeta.description}
        </span>
        {dashboardHint ? (
          <span
            style={{ fontSize: 11, color: 'var(--text-secondary)', fontWeight: 500, marginLeft: 12 }}
          >
            {dashboardHint}
          </span>
        ) : null}
      </div>

      <div className="date-nav">
        <button className="date-arrow-btn" onClick={prevTradingDay} title="上一交易日">
          <ChevronLeft />
        </button>
        <div className="date-display">
          <input
            type="date"
            className="date-input"
            value={selectedDate}
            onChange={event => event.target.value && setSelectedDate(event.target.value)}
          />
          <span className="date-weekday" style={isWeekend ? { color: 'var(--text-muted)' } : {}}>
            {weekday}
            {isWeekend && <span style={{ marginLeft: 4, fontSize: 10, color: 'var(--text-muted)' }}>周末</span>}
          </span>
        </div>
        <button
          className="date-arrow-btn"
          onClick={nextTradingDay}
          disabled={isToday}
          title="下一交易日"
          style={isToday ? { opacity: 0.35, cursor: 'not-allowed' } : {}}
        >
          <ChevronRight />
        </button>
        {!isToday && (
          <button
            className="date-today-btn"
            onClick={() => {
              const today = new Date();
              setSelectedDate(`${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`);
            }}
          >
            今天
          </button>
        )}
      </div>

      <div className="topbar-sep" />

      <button
        className="theme-btn"
        onClick={() => setTheme(current => current === 'dark' ? 'light' : 'dark')}
        aria-label={theme === 'dark' ? '切换到浅色模式' : '切换到深色模式'}
        title={theme === 'dark' ? '切换浅色模式' : '切换深色模式'}
      >
        {theme === 'dark' ? '浅色' : '深色'}
      </button>

      <div ref={pipelineRef}>
        <button
          className="pipeline-btn"
          onClick={() => setShowPipeline(current => !current)}
          style={showPipeline ? { borderColor: 'var(--border-light)', background: 'var(--bg-hover)', color: 'var(--text-primary)' } : {}}
        >
          <span className="pipeline-btn-dot" style={{ background: dotColor, boxShadow: dotGlow }} />
          {pipelineLabel}
        </button>

        {showPipeline && (
          <div className="pipeline-popup">
            <div className="pipeline-popup-header">
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ width: 7, height: 7, borderRadius: '50%', display: 'inline-block', background: dotColor, boxShadow: dotGlow }} />
                  Pipeline 状态
                </div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 3 }}>
                  {selectedDate} · {safeSteps.length > 0 ? `${safeSteps.filter(step => step.status === 'ok').length}/${safeSteps.length} 已完成` : pipeError ? '请求失败' : '等待数据'}
                </div>
              </div>
              <button
                onClick={() => setShowPipeline(false)}
                style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', padding: 4, display: 'flex', alignItems: 'center', flexShrink: 0 }}
              >
                <CloseXIcon />
              </button>
            </div>

            <div className="pipeline-popup-body">
              {pipeLoading && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '20px 16px', color: 'var(--text-muted)', fontSize: 12 }}>
                  <div className="spinner" />
                  正在加载 Pipeline 详情...
                </div>
              )}
              {!pipeLoading && pipeError && (
                <div style={{ padding: '16px', fontSize: 12, color: 'var(--text-muted)' }}>
                  <span style={{ color: 'var(--red)' }}>请求失败：</span>{pipeError}
                </div>
              )}
              {!pipeLoading && !pipeError && safeSteps.map((step, index) => (
                <div key={index} className="pipeline-step">
                  <div style={{ marginTop: 1, flexShrink: 0 }}>
                    <StepIcon status={step.status} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 0 }}>
                        <span style={{ fontSize: 12, fontWeight: 500, color: 'var(--text-primary)', whiteSpace: 'nowrap' }}>
                          {STEP_NAMES[step.step] ?? step.step}
                        </span>
                        <span style={{ fontSize: 10, color: 'var(--text-muted)', fontFamily: 'monospace', opacity: 0.65 }}>
                          {step.step}
                        </span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
                        <span style={{ fontSize: 11, color: 'var(--text-muted)', fontVariantNumeric: 'tabular-nums' }}>
                          {fmtTime(step.started_at)}
                        </span>
                        <span style={{ fontSize: 10, color: 'var(--text-muted)', fontVariantNumeric: 'tabular-nums' }}>
                          {fmtDur(step.duration_ms)}
                        </span>
                        <span style={{ fontSize: 10, fontWeight: 700, color: STATUS_COLOR[step.status] }}>
                          {STATUS_LABEL[step.status]}
                        </span>
                      </div>
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
                      {step.message}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
