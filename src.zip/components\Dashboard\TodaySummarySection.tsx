import type { TodaySummaryViewModel } from '../../types/dashboard';
import MetricStrip from './MetricStrip';
import SectionCard from './SectionCard';
import StatusState from './StatusState';

interface TodaySummarySectionProps {
  data?: TodaySummaryViewModel;
  status: 'loading' | 'empty' | 'error' | 'normal';
  onRetry: () => void;
}

export default function TodaySummarySection({
  data,
  status,
  onRetry,
}: TodaySummarySectionProps) {
  return (
    <SectionCard
      title="今日摘要"
      badge="作战室"
      description="汇总今天的信号、观察池、组合和系统变化，先给出可判断的一屏摘要。"
    >
      {status === 'loading' ? (
        <StatusState
          type="loading"
          title="正在整理今日摘要"
          description="Dashboard mock 正在装载，摘要区先保留结构位。"
        />
      ) : null}
      {status === 'error' ? (
        <StatusState
          type="error"
          title="今日摘要加载失败"
          description="当前无法生成今日变化概览，请重试。"
          actionLabel="重新加载"
          onAction={onRetry}
        />
      ) : null}
      {status === 'empty' ? (
        <StatusState
          type="empty"
          title="今日暂无摘要数据"
          description="当前交易日尚未生成摘要，或暂无需要提示的变化。"
          actionLabel="重新加载"
          onAction={onRetry}
        />
      ) : null}
      {status === 'normal' && data ? (
        <div className="dashboard-summary-layout">
          <div className="dashboard-summary-copy">
            <div className="dashboard-summary-headline">{data.headline}</div>
            <p className="dashboard-summary-note">{data.summaryText}</p>
          </div>
          <MetricStrip items={data.metrics} />
        </div>
      ) : null}
    </SectionCard>
  );
}
